`%p%` <-
function(a, b)
1/(1/a + 1/b)

`E12` <-
c(1, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2)
`E24` <-
c(1, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2, 2.2, 2.4, 2.7, 3, 3.3, 
3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1)
`E6` <-
c(1, 1.5, 2.2, 3.3, 4.7, 6.8)
`Ig` <-
function(p, Ep, Eg)
{
    # �O�Ɋǂ̃O���b�h�d����Ԃ�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��

    Ip.sub(p, Ep, Eg)$ig
}

`Ig2` <-
function (p, Ep, Eg, Eg2) 
{
    # �܋Ɋǂ̃X�N���[���O���b�h�d����Ԃ�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��
    # Eg2: �X�N���[���O���b�h�d��

    Ipp.sub(p, Ep, Eg, Eg2)$ig2
}

`Igp` <-
function(p, Ep, Eg, Eg2)
{
    # �܋Ɋǂ̃O���b�h�d����Ԃ�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��
    # Eg2: �X�N���[���O���b�h�d��

    Ipp.sub(p, Ep, Eg, Eg2)$ig
}

`Ip` <-
function(p, Ep, Eg)
{
    # �O�Ɋǂ̃v���[�g�d����Ԃ�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��

    Ip.sub(p, Ep, Eg)$ip
}

`Ip.cal` <-
function(fn, name, gfn, G.lim=NULL, Ig.ratio=NULL, verbose=FALSE, Ego.lim=c(-1, 1), ...)
{
    # ���f���̃p�����[�^�����߂�
    # fn: �f�[�^�t�@�C����
    # name: �p�����[�^�I�u�W�F�N�g��
    # gfn: �L�����u���[�V�����̏󋵂������v���[�g�����̃O���t�t�@�C����.
    #   �w�肳��Ă��Ȃ���΃O���t����ʂɕ\������.
    # G.lim: Ep=Eg �̃p�[�r�A���X(�ȗ���)
    # Ig.ratio: Ep=Eg �̂Ƃ��̃J�\�[�h�d���ɑ΂���O���b�h�d���̔䗦(�ȗ���)
    # verbose: �r���o�߂̕\��
    # ...: �d�Ɋԗe�ʂ���ё��̃p�����[�^
    #   Cgp, Cgk Cpk, Ci, Co: �d�Ɋԗe��
    #   ig=(Ep,Ip,Ig): �O���b�h�d���f�[�^
    #   pentode.chara=(Ep,Eg2,Eg,Ip,Ig2,rp): �܋ɊǓ����

    Ego.min <- Ego.lim[1]
    Ego.max <- Ego.lim[2]
    Ego.range <- Ego.max - Ego.min

    sig <- function(x) signif(x, 8)
    print.level <- 1        # �f�f�o�͂̃��x��

    # �L�����u���[�V����
    x <- scan(fn, sep=",", what="")     # �f�[�^�t�@�C����ǂ�
    egepip <- matrix(as.numeric(x[-(1:3)]), ncol=3, byrow=TRUE)
    eg <- egepip[,1]        # �O���b�h�d��
    ep <- egepip[,2]        # �v���[�g�d��
    ip <- egepip[,3]        # �v���[�g�d��
    n <- length(eg)         # �L�����u���[�V�����f�[�^�̃|�C���g��

    if (!missing(gfn))
        psi(file=gfn, wh=c(103.9, 68.8))
    
    # �O���t��`���͈͂����肷��
    xlim <- c(0, max(ep)*1.04)
    ylim <- c(0, max(ip)*1.04)
    xlab <- eunit1(pretty(xlim, 8), "V")
    ylab <- eunit1(pretty(ylim), "A")

    # �L�����u���[�V�����|�C���g���O���t�ɕ`��(�����ł͂܂��`���Ȃ�)
    plot(ep, ip, type="n", xlim=xlim, ylim=ylim,
        xaxs="i", yaxs="i", xaxt="n", yaxt="n",
        xlab=paste("Ep", xlab$unit),
        ylab=paste("Ip", ylab$unit))

    # �����O���b�h�d���̃|�C���g�𓯂��F�ŕ`��
    ueg <- unique(eg)               # ��ӂ̃O���b�h�d��
    for (i in 1:length(ueg)) {
        ok <- eg == ueg[i]
        points(ep[ok], ip[ok], pch="+", col=(i-1)%%4+3)
    }

    # ����`��
    axis(1, at=xlab$at, lab=xlab$lab)
    axis(1, at=xlab$at, lab=FALSE, tck=1, lty=2, lwd=0.3)
    axis(2, at=ylab$at, lab=ylab$lab)
    axis(2, at=ylab$at, lab=FALSE, tck=1, lty=2, lwd=0.3)

    if (is.null(G.lim)) {
        # �œK���̕ϐ����烂�f���̕ϐ��ւ̕ϊ��֐�
        decode <- function(x) {
            z <- exp(x)
            z[3] <- z[3] / (z[3] + 1) * 0.65 + 0.35
#           z[3] <- z[3] / (z[3] + 1) * 0.45 + 0.35
            z[4] <- z[4] / (z[4] + 1) * Ego.range + Ego.min 
            list(G=z[1], muc=z[2], alpha=z[3], Ego=z[4])
        }
    } else {
        # �œK���̕ϐ����烂�f���̕ϐ��ւ̕ϊ��֐�
        decode <- function(x) {
            z <- exp(x)
            z[3] <- z[3] / (z[3] + 1) * 0.65 + 0.35
#           z[3] <- z[3] / (z[3] + 1) * 0.45 + 0.35
            z[4] <- z[4] / (z[4] + 1) * Ego.range - Ego.min
            list(G=z[1], muc=z[2], alpha=z[3], Ego=z[4], G.lim=G.lim, Ig.ratio=Ig.ratio)
        }
    }

    # ���f���̕ϐ�����œK���̕ϐ��ւ̕ϊ��֐�
    encode <- function(x) {
        x[3] <- (x[3] - 0.35) / 0.65
        x[3] <- x[3] / (1 - x[3])
#       x[3] <- (x[3] - 0.35) / 0.45
#       x[3] <- x[3] / (1 - x[3])
        x[4] <- (x[4] - Ego.min) / Ego.range
        x[4] <- x[4] / (1 - x[4])
        log(x)
    }

    # �œK������֐�
    f <- function(x) {
        p <- decode(x)                  # ���f���̕ϐ��֕ϊ�
        if (print.level == 2)
            str(p)
        ipe <- Ip(p, Eg=eg, Ep=ep)      # ���f���ɂ��v���[�g�d��
        if (any(is.na(ipe))) {          # ���f������NA���o�Ă������̏��u
            print(egepip[, 1:2])        # (�����ɂ���͂��͂Ȃ�?)
            print(ipe)
            str(p)
            stop()
        }
        ipd <- ipe^(2/3) - ip^(2/3)         # ���f���Ǝ��ۂ̒l�̍�
        sqrt(mean(ipd^2))/mean(ip^(2/3))    # �v���[�g�d���̕��ϒl�ɑ΂���
                                            # RMS�΍��̑傫��
    }

    # �p�����[�^�����l�̐���
    # �������̐���
    mineg <- min(eg)                    # �f�[�^�ōł��[���O���b�h�d��
    if (mineg < 0) {
        minep <- min(ep[eg == mineg])   # ���̒��ōł��v���[�g�d�����Ⴂ����
        if (minep == 0)
            muhat <- 30
        else
            muhat <- minep / -mineg     # ������J�b�g�I�t�Ƃ݂Ȃ��� mu_c �𐄒�
    } else
        muhat <- 30                     # B���A�|�W�e�B�u�O���b�h�Ǘp

    # �p�[�r�A���X�̐���
    mu0 <- 5/3 * muhat                  # Eg=0�� mu
    ep0 <- ifelse(eg == max(eg), ep, 0)
    idx <- ep0 == max(ep0)              # Eg=0�ōł��v���[�g�d�����������̂ɂ��
    Ghat <- 2/3 * ip[idx] / (0.6 + ep[idx]/mu0)^1.5     # �p�[�r�A���X�𐄒�
    if (verbose) {
        cat("muhat=", muhat, "\n", sep=" ")
        cat("Ghat=", Ghat, "\n", sep=" ")
    }

    ini <- encode(c(Ghat, muhat, 0.6, 0.6))     # ���̃p�����[�^�̏����l��0.6

    # �œK��
    optim.out <- optim(ini, f,
                    control=list(parscale=ini, maxit=5000, reltol=1e-10))
    cat("code=", optim.out$convergence, " err=", optim.out$value, "\n", sep="")

    # �p�����[�^�I�u�W�F�N�g�̍쐬�ƕۑ�
    est <- decode(optim.out$par)            # ���肳�ꂽ���f���̃p�����[�^
    for (i in 1:length(est))                # �L��������8���ɂ���
        est[[i]] <- sig(est[[i]])
    est <- c(est, list(...))
    est$err <- optim.out$value
    est$code <- optim.out$convergence
    if (!is.null(est$pentode.chara)) {
        pen.Ep <- est$pentode.chara[1]
        pen.Eg2 <- est$pentode.chara[2]
        pen.Eg <- est$pentode.chara[3]
        pen.Ip <- est$pentode.chara[4]
        pen.Ig2 <- est$pentode.chara[5]
        pen.rp <- est$pentode.chara[6]
        g2r <- pen.Ig2/(pen.Ip + pen.Ig2)
        a <- (1-pen.Ep/(pen.Ep+10))^1.5
        r <- (g2r - a)/(1 - a)              # (1.41)
        est$g2.r <- sig(r)
        est$Ea <- sig(pen.Eg2 - pen.Ip * pen.rp * 1.5)
    }
    if (!missing(name))                     # �I�u�W�F�N�g�����w�肳��Ă����
        assign(name, est, env=.GlobalEnv)   # ���I�u�W�F�N�g�Ƃ���

    # ���f���ɂ��v���[�g�������O���t�ɏ���������
    g.plate.cal(est, ueg, xlim, ylim)

    if (!missing(gfn))
        dev.off()
    invisible()
}

`Ip.diode` <-
function(p=t5AR4, Ep)
{
    p$G * pmax(Ep, 0)^1.5
}

`Ip.pp` <-
function (p, ep1, eg1, Ebb, Eg0) 
{
    # �v�b�V���v���o�͒i�̍����v���[�g����
    # p: �p�����[�^
    # ep1: �v���[�g�d��
    # eg1: �O���b�h�d��
    # Ebb: �d���d��
    # Eg0: �O���b�h�o�C�A�X�d��

    ep2 <- 2*Ebb - ep1
    eg2 <- 2*Eg0 - eg1
    Ip(p, ep1, eg1) - Ip(p, ep2, eg2)
}

`Ip.pp.comp` <-
function (p, Ebb, Eg0, Eg.step, Eg.max=0)
{
    # �v�b�V���v���o�͒i�̍����v���[�g����
    # p: �p�����[�^
    # Ebb: �v���[�g�����d��
    # Eg0: �O���b�h�o�C�A�X�d��
    # Eg.step: �O���b�h�d���̂�����
    # Eg.max: �ő�O���b�h�d��

    Ep1 <- seq(0, 2*Ebb, by=2)
    Eg1 <- seq(Eg.max, by=-Eg.step, len=ceiling(2*(Eg.max-Eg0)/Eg.step)+1)
    Ip1 <- touter(Ip, p, Ep1, Eg1)
    Ep2 <- 2*Ebb - Ep1
    Eg2 <- rev(Eg1)
    Ip2 <- -touter(Ip, p, Ep2, Eg2)
    x <- c(seq(Eg0, 2*Eg0-Eg.max, by=-Eg.step), 2*Eg0-Eg.max)
    Egc <- unique(c(-rev(x-Eg0)+Eg0, x))
    Ipc <- touter(Ip, p, Ep1, Egc) - touter(Ip, p, Ep2, rev(Egc))
    list(Ep1=Ep1, Eg1=Eg1, Ip1=Ip1, Ep2=Ep2, Eg2=Eg2, Ip2=Ip2, Egc=Egc, Ipc=Ipc)
}

`Ip.sub` <-
function(p, Ep, Eg)
{
    # �O�Ɋǂ̃v���[�g�d���A�O���b�h�d������Ԃ�
    #   p: �p�����[�^
    #   Ep: �v���[�g�d��
    #   Eg: �O���b�h�d��
    # �Ԓl
    #   $ip: �v���[�g�d��
    #   $ig: �O���b�h�d��
    #   $mum: �ő�� mu
    #   $Egg: �����O���b�h�d��

    Egg <- Eg + p$Ego           # (B.23)
    Ep <- pmax(Ep, 0)
    ik <- 0 * Ep                # �J�\�[�h�d��
    ig <- 0 * Ep                # (Ep >> Eg �̂Ƃ���)�O���b�h�d��
    a <- if (p$alpha == 1) Inf else 1/(1 - p$alpha)     # (B.24)
    b <- 1.5 - a                # (B.25)
    c <- 3 * p$alpha - 1        # (B.26)
    G.p <- p$G * (c * a / 3)^b  # (B.27)
    mum <- a / 1.5 * p$muc      # (B.6)

    # �O���b�h�d���̃p�����[�^�����݂��Ȃ��ꍇ�͐���l��p����
    G.lim <- if (is.null(p$G.lim)) G.p * (1 + 1/mum)^1.5 else p$G.lim   # (B.21)
    Ig.ratio <- if (is.null(p$Ig.ratio)) 0.5/(1 + 1/mum)^1.5 else p$Ig.ratio    # (B.20)

    # �J�\�[�h�d��
    gm <- Egg <= 0      # Egg �����̏ꍇ
    estm <- pmax(Egg + Ep/p$muc, 0)
    ik[gm] <- p$G * (ifelse(Ep == 0, 0, (c / 2 / p$muc * Ep)^b) *
                    (1.5 / a * estm)^a)[gm]     # (B.28)

    gp <- Egg > 0       # Egg �����̏ꍇ
    estp <- pmax(Egg + Ep/mum, 0)
    ik[gp] <- (G.p * estp^1.5)[gp]              # (B.28)

    # �O���b�h�d��
    Eg <- pmax(Eg, 0)
    ig <- Ig.ratio * G.lim * Eg^1.5 * (Eg / ifelse(Eg > 0, (Ep + Eg), 1) * 1.2 + 0.4)   # (B.29)

    # �v���[�g�d���̏��
    iplim <- (1 - Ig.ratio) * G.lim * Ep^1.5    # (B.30)
    # �v���[�g�d��
    ip <- pmax(pmin(ik - ig, iplim), 0)         # (B.31)

    list(ip=ip, ig=ig, mum=mum, Egg=Egg)
}

`Ipp` <-
function (p, Ep, Eg, Eg2) 
{
    # �܋Ɋǂ̃X�N���[���O���b�h�d����Ԃ�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��
    # Eg2: �X�N���[���O���b�h�d��

    Ipp.sub(p, Ep, Eg, Eg2)$ip
}

`Ipp.pp` <-
function (p, ep1, eg1, Ebb, Eg0, Eg2=Ebb, r=0)
{
    # �v�b�V���v���o�͒i�̍����v���[�g����
    # p: �p�����[�^
    # ep1: �v���[�g�d��
    # eg1: �O���b�h�d��
    # Ebb: �d���d��
    # Eg0: �O���b�h�o�C�A�X�d��

    ep2 <- 2*Ebb - ep1
    eg12 <- 2*Eg0 - eg1
    eg21 <- Eg2 + (ep1 - Ebb)*r
    eg22 <- Eg2 + (ep2 - Ebb)*r
    v1 <- Ipp.sub(p, ep1, eg1, eg21)
    v2 <- Ipp.sub(p, ep2, eg12, eg22)
    v1$ip + v1$ig2*r - v2$ip - v2$ig2*r
}

`Ipp.pp.comp` <-
function (p, Ebb, Eg0, Eg.step, Eg2=Ebb, r=0)
{
    # �v�b�V���v���o�͒i�̍����v���[�g����
    # p: �p�����[�^
    # Ebb: �v���[�g�����d��
    # Eg0: �O���b�h�o�C�A�X�d��
    # Eg.step: �O���b�h�d���̂�����

    Ep1 <- seq(0, 2*Ebb, by=2)
    Eg11 <- seq(0, by=-Eg.step, len=ceiling(-2*Eg0/Eg.step)+1)
    Eg21 <- Eg2 + (Ep1-Ebb) * r
    Ip1 <- touter(Ipp, p, Ep1, Eg11, Eg21)

    Ep2 <- 2*Ebb - Ep1
    Eg12 <- rev(Eg11)
    Eg22 <- Eg2 + (Ep2-Ebb) * r
    Ip2 <- -touter(Ipp, p, Ep2, Eg12, Eg22)
    x <- c(seq(Eg0, 2*Eg0, by=-Eg.step), 2*Eg0)
    Egs <- unique(c(-rev(x-Eg0)+Eg0, x))
    Ipc <- touter(Ipp, p, Ep1, Egs, Eg21) +
            touter(Ig2, p, Ep1, Egs, Eg21)*r -
            touter(Ipp, p, Ep2, rev(Egs), Eg22) -
            touter(Ig2, p, Ep2, rev(Egs), Eg22)*r
    list(Ep1=Ep1, Eg11=Eg11, Ip1=Ip1, Ep2=Ep2, Eg12=Eg12, Ip2=Ip2, Egs=Egs, Ipc=Ipc)
}

`Ipp.sub` <-
function(p, Ep, Eg, Eg2)
{
    # �܋Ɋǂ̃v���[�g�d����Ԃ�
    #   p: �p�����[�^
    #   Ep: �v���[�g�d��
    #   Eg: �O���b�h�d��
    #   Eg2: �X�N���[���O���b�h�d��
    # �Ԓl
    #   $ip: �v���[�g�d��
    #   $ig: �O���b�h�d��
    #   $ig2: �X�N���[���O���b�h�d��

    # �v���[�g�d���̃x�N�g���̒�����
    # �X�N���[���O���b�h�d���̃x�N�g���̒����𑵂���
    Eg2 <- Eg2 + 0*Ep
    Ep <- Ep + 0*Eg2

    Egg <- Eg + p$Ego           # (B.23)
    Ep <- pmax(Ep, 0)
    Eg2 <- pmax(Eg2, 0)
    ik <- 0 * Ep                # �J�\�[�h�d���i�[�̈�
    ig <- 0 * Ep                # �O���b�h�d���i�[�̈�
    a <- 1/(1 - p$alpha)        # (B.24)
    b <- 1.5 - a                # (B.25)
    c <- 3 * p$alpha - 1        # (B.26)
    G.p <- p$G * (c * a / 3)^b  # (B.27)
    mum <- a / 1.5 * p$muc      # (B.6)

    # �O���b�h�d���̃p�����[�^�����݂��Ȃ��ꍇ�͐���l��p����
    Ig.ratio <- if (is.null(p$Ig.ratio)) 0.5/(1 + 1/mum)^1.5 else p$Ig.ratio    # (B.20)
    G.lim <- if (is.null(p$G.lim)) G.p * (1 + 1/mum)^1.5 else p$G.lim   # (B.21)

    # �J�\�[�h�d��
    gm <- Egg <= 0      # Egg �����̏ꍇ
    estm <- pmax(Egg + Eg2/p$muc, 0)
    ik[gm] <- p$G * (ifelse(Eg2 == 0, 0, (c / 2 / p$muc * Eg2)^b) *
                    (1.5 / a * estm)^a)[gm]     # (B.32)

    gp <- Egg > 0       # Egg �����̏ꍇ
    estp <- pmax(Egg + Eg2/mum, 0)
    ik[gp] <- (G.p * estp^1.5)[gp]              # (B.32)

    # �O���b�h�d��
    Eg <- pmax(Eg, 0)
    ig <- Ig.ratio * G.lim * Eg^1.5 * (Eg / ifelse(Eg > 0, (Ep + Eg), 1) * 1.2 + 0.4)   # (B.33)

    # ��2�O���b�h�d�����v���[�g�d�����Ⴂ�ꍇ�̃J�\�[�h�d���̌���
    f <- ifelse(Ep==0 & Eg2==0, 1, 1 - 0.4 * (exp(-Ep/Eg2*15)-exp(-15)))    # (B.34)
    ik2 <- f * (ik - ig)                        # (B.37)

    # �X�N���[���O���b�h�d���̕��z�䗦
    g <- (1 - p$g2.r) * (1 - Ep/(Ep+10))^1.5 + p$g2.r   # (B.38)
    ig2.th <- g * ik2                           # (B.39)

    # �v���[�g��R�����������J�\�[�h�d��
    h <- (Ep - p$Ea) / (Eg2 - p$Ea)             # (B.42)
    ik3 <- h * ik2                              # (B.43)
    # �J�\�[�h�G�~�b�V�����̐���
    iklim <- (1 - Ig.ratio) * G.lim * pmax(Ep, Eg2)^1.5     # (B.46)
    ik4 <- pmin(ik3, iklim)                     # (B.47)

    # �v���[�g�d���̐���
    iplim <- (1 - Ig.ratio) * G.lim * Ep^1.5    # (B.30)
    # �v���[�g�d��
    ip <- pmax(pmin(ik4 - ig2.th, iplim), 0)    # (B.48)
    # �X�N���[���O���b�h�d��
    ig2 <- pmax(ik4 - ip, 0)                    # (B.49)

    list(ip=ip, ig=ig, ig2=ig2, ik=ik4,
        mum=mum, Egg=Egg, a=a, b=b, c=c, f=f, g=g, h=h)
}

`annotation` <-
function(x, y, angle=30, len=0.5, gap=0.025, col=par("fg"), lty=par("lty"), lwd=par("lwd")/2, arrowwid=0.025, arrowht=0.05, ...) 
{
    usr <- par("usr")
    pin <- par("pin")
    # ���[�U�[���W���畨�����W(�C���`)�ւ̕ϊ�
    usr2ph <- function(x, y)
            c((x - usr[1])/(usr[2] - usr[1]) * pin[1],
                (y - usr[3])/(usr[4] - usr[3]) * pin[2])
    # �������W(�C���`)���烆�[�U�[���W�ւ̕ϊ�
    ph2usr <- function(v)
            c(v[1]/pin[1] * (usr[2] - usr[1]) + usr[1],
                v[2]/pin[2] * (usr[4] - usr[3]) + usr[3])

    vec <- c(cos(angle/180*pi), sin(angle/180*pi))

    z <- usr2ph(x, y)       # �������W
    z0 <- z + (len - gap) * vec
    z1 <- z + gap * vec
    xy0 <- ph2usr(z0)       # ���[�U�[���W
    xy1 <- ph2usr(z1)
    segments(xy0[1], xy0[2], xy1[1], xy1[2], col=col, lty=lty, lwd=lwd, ...)

    vec2 <- c(vec[2], -vec[1]) # �����x�N�g���ɐ����ȃx�N�g��
    z4 <- z1 + arrowht * vec
    z2 <- z4 + (arrowwid * vec2)/2
    z3 <- z4 - (arrowwid * vec2)/2
    polygon(rbind(xy1, ph2usr(z2), ph2usr(z3)), col=col, border=FALSE)
    ph2usr(z + len * vec)
}

`arrow` <-
function(x0, y0, x1, y1, col=par("fg"), lty=par("lty"), lwd=par("lwd"), arrowwid=0.05, arrowht=0.1, ...) 
{
    segments(x0, y0, x1, y1, col=col, lty=lty, lwd=lwd, ...)

    usr <- par("usr")
    pin <- par("pin")
    # ���[�U�[���W���畨�����W(�C���`)�ւ̕ϊ�
    usr2ph <- function(x, y)
            c((x - usr[1])/(usr[2] - usr[1]) * pin[1],
                (y - usr[3])/(usr[4] - usr[3]) * pin[2])
    # �������W(�C���`)���烆�[�U�[���W�ւ̕ϊ�
    ph2usr <- function(v)
            c(v[1]/pin[1] * (usr[2] - usr[1]) + usr[1],
                v[2]/pin[2] * (usr[4] - usr[3]) + usr[3])

    z0 <- usr2ph(x0, y0)
    z1 <- usr2ph(x1, y1)
    dx <- z1[1] - z0[1]
    dy <- z1[2] - z0[2]
    vec <- c(dx, dy)/sqrt(dx^2 + dy^2) # �����x�N�g��
    vec2 <- c(vec[2], -vec[1]) # �����x�N�g���ɐ����ȃx�N�g��
    z4 <- z1 - arrowht * vec
    z2 <- z4 + (arrowwid * vec2)/2
    z3 <- z4 - (arrowwid * vec2)/2
    polygon(rbind(ph2usr(z1), ph2usr(z2), ph2usr(z3)), col=col, border=FALSE)
}

`bode.gain` <-
function(x, col="red", xlab="Frequency (Hz)", ylab="Gain (dB)", ...) {
    semilogplot(x$f, dB(x$A), type="l", col=col,
        xlab=xlab, ylab=ylab, ...)
}

`bode.phase` <-
function(x, ylim=NULL, col="blue", xlab="Frequency (Hz)", ylab="Phase (deg)", ...) {
    if (is.null(ylim))
        ylim <- range(x$arg)

    phase.axis <- function() {
        at <- (floor(ylim[1]/45):ceiling(ylim[2]/45)) * 45
        axis(2, at=at)
        axis(2, at=at, lab=FALSE, tck=1, lty=2, lwd=0.3)
    }

    semilogplot(x$f, x$arg, type="l", col=col,
        xlab=xlab, ylab=ylab, yaxt="n", ylim=ylim, ...)
    phase.axis()
}

`cap` <-
function(tubetype="triode", ...)
{
    dots <- list(...)
    Cgp <- dots$Cgp
    Cgk <- dots$Cgk
    Cpk <- dots$Cpk
    Ci <- dots$Ci
    Co <- dots$Co
    if (is.null(Cgp)) {
        Cgp <- 1e-12
        Cgk <- 1e-12
        Cpk <- 1e-12
    } else {
        if (is.null(Cgk)) {
            if (is.null(Ci) || is.null(Co)) {
                Cgk <- 1e-12
            } else {
                if (tubetype == "triode")
                    Cgk <- Ci
                else {
                    a <- Co
                    b <- 2*Co*Cgp - Ci*Co
                    c <- Cgp*((Co - Ci)*Cgp - Ci*Co)
                    Cgk <- (-b + sqrt(b^2 - 4*a*c)) / (2*a)
                }
            }
        }
        if (is.null(Cpk)) {
            if (is.null(Ci) || is.null(Co)) {
                Cpk <- 1e-12
            } else {
                if (tubetype == "triode")
                    Cpk <- Co
                else
                    Cpk <- Co - Cgp*Cgk/(Cgp + Cgk)
            }
        }
    }
    if (Cgp <= 0 || Cgk <= 0 || Cpk <= 0) {
        cat("Cgk=", Cgk, ", Cpk=", Cpk, "\n", sep="")
        Cgk <- Ci
        Cpk <- Co
    }
    if (tubetype == "triode") {
        list(Cgpt=Cgp, Cgkt=Cgk, Cpkt=Cpk)
    } else {
        Cg1g2 <- 0.4 * Cgk
        Cgk <- 0.6 * Cgk
        list(Cgp=Cgp, Cgk=Cgk, Cg1g2=Cg1g2, Cpk=Cpk, Cgkt=Cgk, Cgpt=Cgp+Cg1g2, Cpkt=Cpk)
    }
}

`cbind.irregular` <-
function(...) 
{
    # �������s�����̃x�N�g���� cbind ����

    x <- list(...)
    n <- length(x)              # �����ŗ^����ꂽ�x�N�g���̐�(�n��)
    l <- max(unlist(lapply(x, length)))     # �ł������x�N�g���̒���
    z <- matrix(NA, l, n)       # ���ʂ��i�[����s��
    for (i in 1:n) {            # �e�x�N�g���ɂ��ă��[�v����
        xi <- x[[i]]            # i �Ԗڂ̃x�N�g�������o����
        idx <- seq(along=xi)    # �����𒲂�
        z[idx, i] <- xi         # �s��Ɋi�[
    }
    z
}

`combr` <-
function (r, n=10, series=E24, mult=0:6, func="%p%", comp="=")
{
    # �w�肳�ꂽ�l r �ɍł��߂������l�����߂�B
    # ��ɒ�R�̕��񍇐��l��T�����邽�߂̊֐��Ȃ̂ŁA���̖��O�ƂȂ��Ă���B
    # r: �ڕW�Ƃ���l
    # n: ���ʂ��o�͂����
    # series: �g�p����f�q�̒l�̉������̃x�N�g��(�ʏ�AE6, E12, E24��p����)
    # mult: �T������w���͈̔�
    # func: �����l���Z�o����֐�
    #   ("%p%" �Ȃ��R�̕��񍇐��l�A"+" �Ȃ��R�̒��񍇐��l�A
    #   "/" �Ȃ��R�̔䓙)
    # comp: "=" �Ȃ�ł� r �ɋ߂��l�A
    #   ">" �Ȃ� r �ȏ�̒l�A
    #   "<" �Ȃ� r �ȉ��̒l�A���덷�̏��������ɏo�͂���B
    # �Ԓl: 4��̍s��
    #   1���: 1�ڂ̑f�q�̒l
    #   2���: 2�ڂ̑f�q�̒l
    #   3���: �����l
    #   4���: �덷(%)

    x <- series * rep(10^mult, rep(length(series), length(mult)))
    compr <- outer(x, x, func)      # ���ׂĂ̑g�ݍ��킹�ɂ��č����l���v�Z
    err <- (compr - r)/r * 100      # �ڕW�l�ɑ΂���덷
    row <- row(compr)
    col <- col(compr)
    o <- order(abs(err))            # ���������ɕ��וς��邽�߂̓Y����
    rc <- cbind(row[o], col[o])     # ���������ɕ��וς��邽�߂̍s�A��ԍ�
    if (all(compr == t(compr))) {   # �����l���Ώ̂Ȃ�
        ok <- rc[, 1] <= rc[, 2]    # �E��O�p�����݂̂��̗p����
        rc <- rc[ok, , drop=F]
    }
    if (comp == ">") {
        ok <- err[rc] >= 0          # �덷�����̂��݂̂̂�ΏۂƂ���
        rc <- rc[ok, , drop=F]
    }
    else if (comp == "<") {
        ok <- err[rc] <= 0          # �덷�����̂��݂̂̂�ΏۂƂ���
        rc <- rc[ok, , drop=F]
    }
    if (nrow(rc) > n)
        rc <- rc[1:n, , drop=F]     # �K�v�Ȑ��Ɍ��炷
    R1 <- x[rc[, 1]]
    R2 <- x[rc[, 2]]
    cbind(R1=R1, R2=R2, R=compr[rc], err=err[rc])
}

`dB` <-
function(x) 
{
    20*log10(abs(x))
}

`dec` <-
function(start, stop, ndiv) 
{
    start <- log10(start)
    stop <- log10(stop)
    10^round(seq(start, stop, by=1/ndiv), 8)
}

`diffp` <-
function (p=t6BM8PT, RL=c(3.5e3, 5e3, 6.6e3, 8e3, 10e3), Epmax=500, Pp=p$Pp)
{
    z <- matrix(NA, nrow=length(RL), ncol=4)
    dimnames(z) <- list(RL, c("Ep0", "Ip0", "Eg0", "Po"))
    for (i in seq(along=RL)) {
        RLi <- RL[i] / 2
        Ep0 <- uniroot(function(Ep) {
            Ip0 <- p$Pp / Ep
            Epmin <- uniroot(function(x) {
                Ip1 <- Ip0 + (Ep - x) / RLi
                Ip2 <- Ip(p, x, 0)
                Ip1 - Ip2
            }, c(0, Epmax))$root
            Ip(p, Epmin, 0) - Ip0 * 2
        }, c(50, Epmax))$root
        z[i, 1] <- Ep0
        Ip0 <- p$Pp / Ep0
        z[i, 2] <- Ip0
        z[i, 3] <- uniroot(function(Eg) {
            Ip(p, Ep0, Eg) - Ip0
        }, c(-100, 0))$root
        z[i, 4] <- Ip0^2 * RLi
    }
    z
}

`distortion` <-
function(wave, component=FALSE)
{
    # FFT�ɂ��c�������߂�
    # wave: �g�`
    # component: �c�ݔg�`�����߂邩?
    # �Ԓl
    #   $wave: �^����ꂽ�g�`
    #   $power: �p���[�X�y�N�g��
    #   $distortion: �c��
    #   $wave.component: �c�ݔg�`

    n <- length(wave)
    wave.fft <- fft(wave)/n

    # �p���[�X�y�N�g��
    power.c <- wave.fft[1:(n/2)] * c(1, rep(2, n/2-1))
    power <- abs(power.c)
    names(power) <- c("DC", paste("H", 1:(n/2-1), sep=""))

    # �c��
    dist <- c(sqrt(sum(power[-c(1,2)]^2)), power[-c(1,2)]) / power[2]
    names(dist) <- c("THD", paste("H", 2:(n/2-1), sep=""))

    # �c����(�g�`)
    if(component) {
        wave.comp <- matrix(NA, n, 4)
        wave.comp[, 1] <- Re(fft(wave.fft * c(0, 1, rep(0, n-3), 1), inv=TRUE))
        wave.comp[, 2] <- Re(fft(wave.fft * c(0, 0, 1, rep(0, n-5), 1, 0), inv=TRUE))
        wave.comp[, 3] <- Re(fft(wave.fft * c(0, 0, 0, 1, rep(0, n-7), 1, 0, 0), inv=TRUE))
        wave.fft[c(1, 2, n)] <- 0       # DC �Ɗ�{�g������
        wave.comp[, 4] <- Re(fft(wave.fft, inv=TRUE))
        wave.comp <- rbind(wave.comp, wave.comp[1, ])
        dimnames(wave.comp) <- list(NULL, c(paste("H", 1:3, sep=""), "Total"))
    } else
        wave.comp <- NULL
    list(wave=wave, power=power, power.c=power.c, distortion=dist,
        wave.component=wave.comp)
}

`eunit` <-
function(x)
{
    # �H�w�P�ʂŕ\������
    not.zero <- x != 0
    lx <- log10(x[not.zero])/3
    sign <- ifelse(lx > 0, 1, -1)
    d <- 0
    d[not.zero] <- floor(abs(lx) + 0.001) * sign
    x <- x/10^(d * 3)
    paste(x, c("y", "z", "a", "f", "p", "n", "u", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y")[d + 9], sep = "")
}

`eunit1` <-
function(x, unit)
{
    # ���j�A���̕⏕�P�ʂƃ��x�������߂�
    mx <- max(abs(x))
    d <- floor(log10(ifelse(mx == 0, 1, mx))/3+1e-8)
    scale <- 10^(-d * 3)
    list(scale=scale,
        unit=paste("(",
                c("p","n","u","m","","k","M","G")[d + 5],
                unit, ")", sep=""),
        at=x,
        lab=signif(x*scale))
}

`eunit2` <-
function(x)
{
    # �H�w�P�ʂŕ\������
    not.zero <- x != 0
    d <- 0
    d[not.zero] <- floor(log10(x[not.zero])/3+1e-8)
    x <- x/10^(d * 3)
    paste(x, c("y", "z", "a", "f", "p", "n", "u", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y")[d + 9], sep = "")
}

`filltext` <-
function (x, y, text, adj=0.5, cex=1, w=3, h=1, col=1) 
{
    x <- x + y * 0
    y <- y + x * 0
    w <- w + x * 0
    cxy <- par("cxy")
    for (i in seq(along=x)) {
        la <- -cxy[1] * w[i] * cex * ((adj - 0.5) * 0.95 + 0.5)
        ra <- cxy[1] * w[i] * cex * (1 - ((adj - 0.5) * 0.95 + 0.5))
        ta <- cxy[2] * h * cex * 0.45
        ba <- -cxy[2] * h * cex * 0.45
        xx <- x[i] + c(la, la, ra, ra, la)
        yy <- y[i] + c(ba, ta, ta, ba, ba)
        polygon(xx, yy, col="white", border=FALSE)
        text(x[i], y[i], text[i], col=col, adj=adj)
    }
}

`find.Ll` <-
function(x, r, L, col, legend.Ll, legend.K) {
    # �R��C���_�N�^���X�̒l�����߁A�����W����Ԃ�
    # x: ���g���ƃC���s�[�_���X�̃��X�g
    # r: ��R�l
    # L: �ꎟ�C���_�N�^���X
    # col: �C���s�[�_���X������`���F
    # legend.Ll: �R��C���_�N�^���X��ʕ\���p�̕�����
    # legend.K: �����W���\���p�̕�����

    lines(log10(x$f), log10(x$z), col=col)      # �C���s�[�_���X������`��
    Zd <- diff(log10(x$z)) / diff(log10(x$f))   # �C���s�[�_���X�����̌X��
    idx <- which(Zd < -0.2)[1]                  # �X�����ŏ��ɕ��ɂȂ�Y��
    cat("idx=", idx, "\n", sep="")
    ii <- which(Zd[1:idx] >= 1.0)               # 
    if (length(ii) == 0) {                      # ������Ȃ�������
        i <- which(max(Zd[1:idx]) == Zd)[1]     # �X�����ł��}�ȓY�����g��
    } else {
        i <- ii[1]                              # �ŏ��ɌX����45�x�𒴂�������
    }
    cat("f=", x$f[i], "\n", sep="")             # �̗p�����_�̎��g��
    points(log10(x$f[i]), log10(x$z[i]), col=col)       # �_��\��
    # throughline(log10(x$f[i]), log10(x$z[i]), 1)
    if (x$z[i]^2 <= r^2)    # �C���s�[�_���X����R��菬�����ꍇ��
        r <- 0              # ��R�������O���Čv�Z����
    Ll <- sqrt(x$z[i]^2 - r^2) / (2 * pi * x$f[i])      # �R��C���_�N�^���X
    cat("�R��C���_�N�^���X=", Ll, "\n", sep="")
    cat(legend.Ll, Ll, "\n", sep="")
    K <- sqrt(1 - Ll / L)                       # �����W��
    cat(legend.K, K, "\n", sep="")
    K
}

`finite.only` <-
function(x) 
{
    x[is.finite(x)]
}

`g.dynamic` <-
function(Eg, Ip, Ipmax=max(Ip)*1.04, col=2, xlabel="Eg")
{
    if (!is.matrix(Ip))
        Ip <- as.matrix(Ip)
    xlim <- range(Eg)
    ylim <- c(0, Ipmax)
    xlab <- eunit1(pretty(xlim, 8), "V")
    ylab <- eunit1(pretty(ylim), "A")
    matplot(Eg, Ip, type="l", col=col, lty=1, ylim=ylim,
            xaxs="i", yaxs="i",
            xaxt="n", yaxt="n",
            xlab=paste(xlabel, xlab$unit),
            ylab=paste("Ip", ylab$unit))
    axis(1, at=xlab$at, lab=xlab$lab)
    axis(1, at=xlab$at, lab=FALSE, tck=1, lty=2, lwd=0.3)
    axis(2, at=ylab$at, lab=ylab$lab)
    axis(2, at=ylab$at, lab=FALSE, tck=1, lty=2, lwd=0.3)
}

`g.gm` <-
function (col=2)
{
    Ep <- c(50, 100, 150, 200, 250, 300)
    Eg <- seq(0, -20, len=201)

    ip <- touter(Ip, t12AU7, Ep, Eg)
    gm <- touter(gm, t12AU7, Ep, Eg)
    rp <- touter(rp, t12AU7, Ep, Eg)
    mu <- touter(mu, t12AU7, Ep, Eg)
    print(rp)
    matplot(t(ip), t(gm) * 1e6, type="l", col=col, lty=1,
        xaxs="i", yaxs="i",
        xlim=c(0, 0.028), ylim=c(0, 4000),
        xlab="Ip (A)", ylab="Transconductance (mmS)")
    axis(1, tck=1, lty=2, lwd=0.3)
    axis(2, tck=1, lty=2, lwd=0.3)
    par(new=T)
    matplot(t(ip), t(rp), type="l", col=col+1, lty=1,
        xaxs="i", yaxs="i",
        xaxt="n", yaxt="n",
        xlim=c(0, 0.028), ylim=c(0, 20000),
        xlab="", ylab="")
    axis(4)
    par(new=T)
    matplot(t(ip), t(mu), type="l", col=col+2, lty=1,
        xaxs="i", yaxs="i",
        xaxt="n", yaxt="n",
        xlim=c(0, 0.028), ylim=c(2, 22),
        xlab="", ylab="")
    invisible()
}

`g.grid` <-
function(Ip, Egmin, Ipmax, drawEp=TRUE, col=2)
{
    Ep <- as.numeric(dimnames(Ip)[[1]])
    Eg <- as.numeric(dimnames(Ip)[[2]])
    if (missing(Egmin))
        Egmin <- min(Eg)
    if (missing(Ipmax))
        Ipmax <- max(Ip)

    # �O���t��`��
    xlim <- c(Egmin, 0)
    ylim <- c(0, Ipmax)
    xlab <- eunit1(pretty(xlim), "V")
    ylab <- eunit1(pretty(ylim, 8), "A")
    matplot(Eg, t(Ip), type="l", col=col, lty=1,
        xlim=xlim, ylim=ylim,
        xaxs="i", yaxs="i",
        xaxt="n", yaxt="n",
        xlab=paste("Eg", xlab$unit),
        ylab=paste("Ip", ylab$unit))
    axis(1, at=xlab$at, lab=xlab$lab)
    axis(1, lab=FALSE, at=xlab$at, tck=1, lty=2, lwd=0.3)
    axis(2, at=ylab$at, lab=ylab$lab)
    axis(2, lab=FALSE, at=ylab$at, tck=1, lty=2, lwd=0.3)

    # Ep ������
    if (drawEp) {
        maxi <- apply(Ip, 1, function(i) {
            i[i > Ipmax] <- NA
            min(seq(along=i)[is.finite(i)])
        })
        x <- pmin(Eg[maxi], max(Eg) * 0.97)
        y <- pmin(Ip[cbind(1:nrow(Ip), maxi)], Ipmax * 0.97)
        lab <- as.character(Ep)
        lab[length(lab)] <- paste("Ep=", lab[length(lab)], "V", sep="")
        text(x, y, lab, adj=1)
    }
    invisible()
}

`g.plate` <-
function(Ip, Ebb, RL, Ipmax, drawEg=TRUE, col=2, Ipmin=0, xlim,
    xname="Ep", yname="Ip", zname="Eg")
{
    # �v���[�g�����̃O���t��`��
    # Ip: touter �ō쐬�����v���[�g�d���̍s��(Ep x Eg)
    # Ebb: �O���t�̉E����������߂̉��z�I��B�d��
    # RL: �O���t�̉E����������߂̉��z�I�ȕ��ג�R
    # Ipmax: y���̍ő�l
    # drawEg: �O���b�h�d����\�����邩�ǂ���
    # col: �O���t�̐F
    # Ipmin: y���̍ŏ��l
    # xlim: x���͈̔�
    # xname: x���̖��O(�P�ʂ� V, kV �ŌŒ�)
    # yname: y���̖��O(�P�ʂ� mA, A �ŌŒ�)
    # zname: �O���b�h�d���̖��O(�P�ʂ� V �ŌŒ�)

    Ep <- as.numeric(dimnames(Ip)[[1]])
    Eg <- as.numeric(dimnames(Ip)[[2]])

    # �O���t�̉E��̃f�[�^������
    ilim <- matrix((Ebb - Ep)/RL, nrow=length(Ep), ncol=length(Eg))
    Ip[Ip > ilim] <- NA

    # �O���t��`��
    if (missing(xlim))
        xlim <- range(Ep)
    ylim <- c(Ipmin, Ipmax)
    xlab <- eunit1(pretty(xlim, 8), "V")
    ylab <- eunit1(pretty(ylim), "A")
    matplot(Ep, Ip, type="l", col=col, lty=1, ylim=ylim,
        xaxs="i", yaxs="i",
        xaxt="n", yaxt="n",
        xlab=paste(xname, xlab$unit),
        ylab=paste(yname, ylab$unit))
    axis(1, at=xlab$at, lab=xlab$lab)
    axis(1, at=xlab$at, lab=FALSE, tck=1, lty=2, lwd=0.3)
    axis(2, at=ylab$at, lab=ylab$lab)
    axis(2, at=ylab$at, lab=FALSE, tck=1, lty=2, lwd=0.3)

    # Eg ������
    if(drawEg) {
        maxi <- apply(Ip, 2, function(i) {
            i[i > Ipmax] <- NA
            max(seq(along=i)[is.finite(i)])
        })
        x <- pmin(Ep[maxi], (max(Ep) - min(Ep))* 0.97 + min(Ep))
        y <- pmin(Ip[cbind(maxi, 1:ncol(Ip))], (Ipmax - Ipmin) * 0.97 + Ipmin)
        lab <- as.character(Eg)
        lab[1] <- paste(zname, "=", lab[1], "V", sep="")
        text(x, y, lab)
    }
    invisible()
}

`g.plate.UL` <-
function(p=t6GW8PT, Ebb=250, r=c(0, 0.43, 1), Ipmax=0.15, Eg2=Ebb)
{
    Ep <- seq(0, 400, by=5)
    Eg <- seq(0, -14, by=-2)
    for (i in seq(along=r)) {
        ip <- outer(Ep, Eg, function(x, y) {
            eg2 <- Eg2 - (Ebb - x)*r[i]
            Ipp.sub(p, x, y, eg2)$ip
        })
        ig2 <- outer(Ep, Eg, function(x, y) {
            eg2 <- Eg2 - (Ebb - x)*r[i]
            Ipp.sub(p, x, y, eg2)$ig2
        })
        if (i == 1)
            matplot(Ep, ip, type="l", col=2, lty=2, xaxs="i", yaxs="i",
                ylim=c(0, Ipmax))
        else
            matlines(Ep, ip, type="l", col=i+1, lty=2)
#       matlines(Ep, ig2, type="l", col=i+1, lty=3)
        matlines(Ep, ip+r[i]*ig2, type="l", col=i+1, lty=1)
    }
    x <- Ep
    y <- p$Pp / x
    lines(x, y, lty=2, col=1)
    Ip0 <- Ipp.sub(p, Ebb, -7.14, Ebb)$ip
    points(Ebb, Ip0)
    throughline(Ebb, Ip0, -1/7e3)
}

`g.plate.cal` <-
function(p, eg, xlim, ylim) 
{
    ep <- seq(0, ceiling(xlim[2]), by=1)
    ip <- touter(Ip, p, ep, eg)
    matlines(ep, ip, col=2, lty=1)
    # Eg ������
    maxi <- apply(ip, 2, function(i) {
        i[i > ylim[2]] <- NA
        max(seq(along=i)[is.finite(i)])
    })
    x <- pmin(ep[maxi], max(ep) * 0.97)
    y <- pmin(ip[cbind(maxi, 1:ncol(ip))], ylim[2] * 0.97)
    lab <- as.character(eg)
    lab[1] <- paste("Eg=", lab[1], "V", sep="")
    text(x, y, lab)
    if (!is.null(p$Pp)) {
        epmin <- p$Pp/ylim[2]
        if (epmin < max(ep)) {
            ep <- seq(epmin, max(ep), by=2)
            ip <- p$Pp / ep
            lines(ep, ip, lty=2, col="blue")
            text(ep[1], ip[1] * 0.97, paste("Pp=", p$Pp, "W", sep=""))
        }
    }
}

`g.plate.pp` <-
function(Ip, Ipmax, drawEg=TRUE, col=c("red", "darkgreen", "orange"),
    xname="Ep", yname="Ip", zname="Eg", ...)
{
    # �O���t��`��
    xlim <- range(Ip$Ep1)
    ylim <- c(-Ipmax, Ipmax)
    xlab <- eunit1(pretty(xlim, 8), "V")
    ylab <- eunit1(pretty(ylim), "A")
    matplot(Ip$Ep1, Ip$Ip1, type="l", col=col[1], lty=1, ylim=ylim,
        xaxs="i", yaxs="i",
        xaxt="n", yaxt="n",
        xlab=paste(xname, "2 ", xlab$unit, sep=""),
        ylab=paste(yname, ylab$unit), ...)
    matlines(Ip$Ep1, Ip$Ip2, col=col[1], lty=1, ...)

    matlines(Ip$Ep1, Ip$Ipc, col=col[2], lty=1, ...)    # �����v���[�g����
    axis(1, at=xlab$at, lab=rev(xlab$lab))
    axis(1, lab=FALSE, tck=1, lty=2, lwd=0.3)
    axis(2, at=ylab$at, lab=ylab$lab)
    axis(2, lab=FALSE, tck=1, lty=2, lwd=0.3)
    axis(3, at=xlab$at, lab=xlab$lab)
    mtext(paste(xname, "1 ", xlab$unit, sep=""), line=3)

    maxi <- apply(Ip$Ipc, 2, function(i) {
        i[i > Ipmax] <- NA
        max(seq(along=i)[is.finite(i)])
    })
    x <- pmin(Ip$Ep1[maxi], max(Ip$Ep1) * 0.99)
    y <- pmin(Ip$Ipc[cbind(maxi, 1:ncol(Ip$Ipc))], Ipmax * 0.97)
    lab <- format(round(Ip$Egc,1))
    lab[1] <- paste(zname, "1=", lab[1], "V", sep="")
    text(x, y, lab, adj=1)

    mini <- apply(Ip$Ipc, 2, function(i) {
        i[i < -Ipmax] <- NA
        min(seq(along=i)[is.finite(i)])
    })
    x <- pmax(Ip$Ep1[mini], max(Ip$Ep1) * 0.01)
    y <- pmax(Ip$Ipc[cbind(mini, 1:ncol(Ip$Ipc))], -Ipmax * 0.97)
    lab <- format(round(rev(Ip$Egc), 1))
    lab[1] <- paste(zname, "2=", lab[1], "V", sep="")
    text(x, y, lab, adj=0)
}

`gen.sin` <-
function(a=1, n=128) 
{
    # �����g�𐶐�����.
    # a: �U��(�듪�l)
    # n: 1�����̕�����

    if (n %% 4 != 0)
        stop("n must be a multiple of 4.")
    n2 <- n / 2
    n4 <- n / 4
    half <- a * sin((-n4:n4) / n * 2 * pi)
    idx <- c((n4+1):(n2+1), n2:2, 1:n4)
    x <- half[idx]
    attr(x, "idx") <- idx
    attr(x, "uniq") <- half
    x
}

`gm` <-
function(p, Ep, Eg)
{
    # �O�Ɋǂ̑��݃R���_�N�^���X�����߂�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��

    i <- Ip.sub(p, Ep, Eg)
    ifelse(i$ip <= 0, NA,
        ifelse(i$Egg <= 0, i$ip / (1 - p$alpha) / (i$Egg + Ep/p$muc),
                        i$ip * 1.5 / (i$Egg + Ep/i$mum)))
}

`gmg2` <-
function(p, Ep, Eg, Eg2)
{
    # �܋Ɋǂ̃X�N���[���O���b�h���݃R���_�N�^���X�����߂�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��
    # Eg2: ��2�O���b�h�d��

    i <- Ipp.sub(p, Ep, Eg, Eg2)
    ifelse(i$ig2 <= 0, NA,
        ifelse(i$Egg <= 0, i$ig2 * i$a / (i$Egg + Eg2/p$muc),
                        i$ig2 * 1.5 / (i$Egg + Eg2/i$mum)))
}

`gmp` <-
function(p, Ep, Eg, Eg2)
{
    # �܋Ɋǂ̑��݃R���_�N�^���X�����߂�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��
    # Eg2: �X�N���[���O���b�h�d��

    i <- Ipp.sub(p, Ep, Eg, Eg2)
    ifelse(i$ip <= 0, NA,
        ifelse(i$Egg <= 0, i$ip * i$a / (i$Egg + Eg2/p$muc),
                        i$ip * 1.5 / (i$Egg + Eg2/i$mum)))
}

`invsemilogplot` <-
function (x, y, ylim, xlab=deparse(substitute(x)), ylab=deparse(substitute(y)),
    xaxt="s", type="p", ylabfunc=eunit, ...)
{
    ly <- log10(y)
    if (missing(ylim)) {
        yax <- logaxis(ly)
        ylim <- yax$lim
    } else {
        ylim <- log10(ylim)
        yax <- logaxis(ylim)
    }
    if (!is.matrix(ly))
        ly <- as.matrix(ly)
    matplot(x, ly, type=type, xlab=xlab, ylab=ylab,
            yaxt="n", yaxs="i", ylim=ylim, xaxt=xaxt, ...)
    abline(h=log10(yax$tick), lwd=0.3)
    abline(h=ceiling(ylim[1]):floor(ylim[2]), lwd=0.6)
    if (!is.null(ylabfunc))
        labstr <- ylabfunc(yax$at)
    else
        labstr <- yax$at
    axis(2, at=log10(yax$at), lab=labstr, lwd=0.6)
    if (xaxt != "n")
        axis(1, tck=1, lwd=0.6)
    invisible()
}

`logaxis` <-
function(lx)
{
    lx <- round(lx[!is.na(lx)], 8)
    xmini <- floor(min(lx))
    xminf <- min(lx) - xmini
    xminf <- ifelse(xminf <= log10(2)-1e-5, 0,
             ifelse(xminf <= log10(5)-1e-5, log10(2), log10(5)))
    xmin <- xmini + xminf
    xmaxi <- floor(max(lx))
    xmaxf <- max(lx) - xmaxi
    xmaxf <- ifelse(xmaxf >= log10(5)+1e-5, 1,
             ifelse(xmaxf >= log10(2)+1e-5, log10(5),
             ifelse(xmaxf > 1e-5, log10(2), 0)))
    xmax <- xmaxi + xmaxf

    # xmin ���� xmax �̑ΐ��ڐ���`���_�����߂�
    subtick <- 1:9
    lo <- floor(xmin)
    hi <- ceiling(xmax)
    n <- hi - lo
    tick <- c(rep(10^(lo:(hi - 1)), rep(9, n)) * subtick, 10^hi)
    tick <- tick[tick >= 10^xmin*0.99999 & tick <= 10^xmax*1.00001]
    ok <- abs(log10(tick) - floor(log10(tick)+1e-10)) < 2e-5
    ok[c(1, length(ok))] <- TRUE
    at <- tick[ok]
    list(tick = tick, at=at, lim=c(xmin, xmax))
}

`logplot` <-
function (x, y, xlim, ylim, xlab=deparse(substitute(x)), ylab=deparse(substitute(y)), xlabfunc=eunit, ylabfunc=eunit, ...)
{
    lx <- log10(x)
    if (missing(xlim)) {
        xax <- logaxis(lx)
        xlim <- xax$lim
    } else {
        xlim <- log10(xlim)
        xax <- logaxis(xlim)
    }
    ly <- log10(y)
    if (missing(ylim)) {
        yax <- logaxis(ly)
        ylim <- yax$lim
    } else {
        ylim <- log10(ylim)
        yax <- logaxis(ylim)
    }
    if (!is.matrix(ly))
        ly <- as.matrix(ly)
    matplot(lx, ly, xlab=xlab, ylab=ylab,
        xaxt="n", yaxt="n", xaxs="i", yaxs="i",
        xlim=xlim, ylim=ylim, ...)
    abline(v=log10(xax$tick), lwd=0.3)
    abline(v=ceiling(xlim[1]):floor(xlim[2]), lwd=0.6)
    if (!is.null(xlabfunc))
        labstr <- xlabfunc(xax$at)
    else
        labstr <- xax$at
    axis(1, at=log10(xax$at), lab=labstr, lwd=0.6)
    abline(h=log10(yax$tick), lwd=0.3)
    abline(h=ceiling(ylim[1]):floor(ylim[2]), lwd=0.6)
    if (!is.null(ylabfunc))
        labstr <- ylabfunc(yax$at)
    else
        labstr <- yax$at
    axis(2, at=log10(yax$at), lab=labstr, lwd=0.6)
    invisible()
}

`lpfparam` <-
function (w0, Q, K=1, type="SK", Rrange=c(5e3, 100e3), Cseries=E6)
{
    # LPF�̒萔�����߂�
    # w0: �Ւf�p���g��
    # Q: Q
    # K: �ʉ߈�̃Q�C��(�T�����L�[�^�̏ꍇ�͖��������)
    # type: "SK" (�T�����L�[�^) �܂��� "MF" (���d�A�Ҍ^)
    # Rrange: �g�p�����R�l�͈̔�(�����肢���炩�O��邱�Ƃ�����)
    # Cseries: �g�p����R���f���T�̌n��̒l
    # �Ԓl:
    #   type == "SK" �̏ꍇ�A6��̍s��
    #   �e��̒l�́AR1, C2, R3, C4, mr, mc
    #   type == "MF" �̏ꍇ�A7��̍s��
    #   �e��̒l�́AR1, R2, C3, R4, C5, mr, mc

    if (type == "SK")
        K <- 0
    mc.min <- 2 * Q * sqrt(1 + K)
    cat("mc.min=", mc.min, "\n", sep="")
    z <- combr(mc.min^2, series=Cseries, func="/", mult=0:3, n=100, comp=">")
    if (nrow(z) == 0)
        stop("�w�肳�ꂽ�d�l�͖������܂���. Q��K�����������Ă�������.")
    res <- NULL
    for (i in seq(1:nrow(z))) {
        Cm <- sqrt(z[i, 1] * z[i, 2])       # �R���f���T�̒l�̉�����
        mc <- sqrt(z[i, 1] / z[i, 2])       # �R���f���T�́A��l����̔䗦
        Ce <- log10(1 / (w0 * Rrange * Cm)) # ��R�l���͈͂Ɏ��܂�
        Ce <- ceiling(Ce[2]):floor(Ce[1])   # �R���f���T�̎w�������߂�
        C <- Cm * 10^Ce                     # �R���f���T�̒l
        R <- 1 / (w0 * C)                   # �Ή������R�̒l

        # �w�肳�ꂽQ�ƂȂ��R�̔�����߂�
        b <- -mc / Q                        # 2���������̈ꎟ��
        c <- 1 + K                          # 2���������̒萔��
        if (type == "SK") {
            mr <- (-b + sqrt(b^2 - 4 * c)) / 2  # 2���������̉�
            for (j in seq(along=C)) {
                R1 <- R[j] * mr
                R3 <- R[j] / mr
                C2 <- C[j] * mc
                C4 <- C[j] / mc
                res1 <- c(R1, C2, R3, C4, mr, mc)
                if (is.null(res))
                    res <- matrix(res1, nrow=1,
                        dimnames=list(NULL, c("R1", "C2", "R3", "C4", "mr", "mc")))
                else if (match(signif(C2, 3), signif(res[, 2], 3), nomatch=0) == 0)
                    res <- rbind(res, res1)
            }
        } else if (type == "MF") {
            mr <- (-b - sqrt(b^2 - 4 * c)) / 2  # 2���������̉�
            for (j in seq(along=C)) {
                R2 <- R[j] * mr
                R4 <- R[j] / mr
                R1 <- R2 / K
                C3 <- C[j] * mc
                C5 <- C[j] / mc
                res1 <- c(R1, R2, C3, R4, C5, mr, mc)
                if (is.null(res))
                    res <- matrix(res1, nrow=1,
                        dimnames=list(NULL, c("R1", "R2", "C3", "R4", "C5", "mr", "mc")))
                else if (match(signif(C3, 3), signif(res[, 3], 3), nomatch=0) == 0)
                    res <- rbind(res, res1)
            }
        }
    }
    dimnames(res)[[1]] <- 1:nrow(res)
    res
}

`matscan` <-
function(filename, sep = " ", what = 0)
{
    if(exists("is.R") && is.R()) {
        if(sep == " ")
            sep <- ""
        line <- scan(filename, sep = sep, nlines = 1, what = "")
        n <- length(line)
    }
    else {
        cmd <- if(sep == " ")
            Paste("gawk '{ print NF; exit }' ", filename)
        else
            Paste("gawk -F", sep, " '{ print NF; exit }' ", filename)
        n <- as.numeric(unix(cmd))
    }
    z <- if(sep == " " || sep == "")
            matrix(scan(filename, what = ""), byrow = TRUE, ncol = n)
        else
            matrix(scan(filename, what = "", sep = sep), byrow = TRUE, ncol = n)
    x <- z[-1, -1, drop = F]
    mode(x) <- mode(what)
    dimnames(x) <- list(z[, 1][-1], z[1,  ][-1])
    x
}

`matwrite` <-
function(x, filename, name = "-", sep = " ")
{
    z <- x
    if(!is.matrix(x)) {
        mode(z) <- "character"
        if(!is.null(names(z)))
            z <- cbind(names(z), z)
    }
    else {
        lab <- dimnames(x)
        if(is.null(lab))
            lab <- list(NULL, NULL)
        mode(z) <- "character"
        if(length(lab[[1]]) == 0) {
            if(length(lab[[2]]) > 0)
                z <- rbind(lab[[2]], z)
        }
        else {
            z <- cbind(lab[[1]], x)
            if(length(lab[[2]]) > 0)
                z <- rbind(c(name, lab[[2]]), z)
        }
    }
    cat(t(z), sep = c(rep(sep, ncol(z) - 1), "\n"), file = filename)
}

`mu` <-
function(p, Ep, Eg)
{
    # �O�Ɋǂ̑����������߂�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��

    i <- Ip.sub(p, Ep, Eg)
    ifelse(i$ip <= 0, NA,
        ifelse(i$Egg <= 0, 1/((3-3*p$alpha)/2/p$muc + (1-3*p$alpha)/2 * i$Egg/Ep), i$mum))
}

`mug12` <-
function(p, Ep, Eg, Eg2)
{
    # g1-g2�����������߂�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��
    # Eg2: �X�N���[���O���b�h�d��
    # �Ԓl
    #   [1]: �v���[�g�d�������� g1-g2 ������
    #   [2]: �X�N���[���O���b�h�d�������� g1-g2 ������

    i <- Ipp.sub(p, Ep, Eg, Eg2)
    df <- -6 * Ep/Eg2^2 * exp(-15*Ep/Eg2)
    dg <- -15 * (1 - p$g2.r) * (1 - Ep/(Ep + 10))^0.5 / (Ep^2 + 20*Ep + 100)
    dh <- -(Ep - p$Ea) / (Eg2 - p$Ea)^2
    u <- i$a / (i$Egg + Eg2/p$muc)
    l <- df/i$f + dh/(i$h - i$g) + i$b/Eg2 + i$a/(p$muc * i$Egg + Eg2)
    m <- ifelse(i$ig2 <= 0, NA, ifelse(i$Egg <= 0, u / l, NA))
    m2 <- gmg2(p, Ep, Eg, Eg2)[1] * rg2(p, Ep, Eg, Eg2)[1]
    c(m, m2)
}

`mup` <-
function(p, Ep, Eg, Eg2)
{
    # �܋Ɋǂ̑����������߂�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��
    # Eg2: �X�N���[���O���b�h�d��

    i <- Ipp.sub(p, Ep, Eg, Eg2)
    df <- 6/Eg2*exp(-15*Ep/Eg2)
    dg <- -15 * (1 - p$g2.r) * (1 - Ep/(Ep + 10))^0.5 / (Ep^2 + 20*Ep + 100)
    dh <- 1/(Eg2 - p$Ea)
    ifelse(i$ip <= 0, NA,
        ifelse(i$Egg <= 0, i$a / (i$Egg + Eg2/p$muc),
                        1.5 / (i$Egg + Eg2/i$mum)) / (df/i$f + (dh - dg)/(i$h - i$g)))
}

`near` <-
function(x, y) 
{
    z <- (x - y)^2
    which(z == min(z))[1]
}

`nichols` <-
function(x, col=3, lty=1) {
    px <- x$arg
    py <- dB(x$A)
    lf <- log10(x$f)
    ok <- abs(round(lf)-lf) < 0.001
    matlines(px, py, col=col, lty=lty)
    if (!is.matrix(px))
        px <- matrix(px)
    if (!is.matrix(py))
        py <- matrix(py)
    text(px[ok, ], py[ok, ], eunit(x$f[ok]))
}

`nichols.grid` <-
function(Ad=c(-30, -20, -10, -6, -3, -2, -1, -0.4, -0.2, 0,
        0.2, 0.4, 1, 2, 3, 6, 10),
    phi=c(1, 2, 4, 10, 20, 30, 60, 90, 120, 150),
    xlim=c(-180, 180), ylim=c(-36, 36), npt=80) {
    j <- 0+1i
    xlimi <- c(floor(xlim[1]/180), ceiling(xlim[2]/180))
    off <- function(x, y) {
        if (x <= y)
            x:y
        else
            NULL
    }
    pn <- off((xlimi[1]+1) %/%2, (xlimi[2]-1) %/% 2)
    mn <- off((xlimi[1]+2) %/%2, xlimi[2] %/% 2)
    f <- function(x) {
        r <- 10^(yi/20)
        a <- x / 180 * pi
        Ab <- r * cos(a) + r * sin(a) * j
        abs(Ab)/abs(1+Ab) - 10^(Adk/20)
    }
    y <- x <- matrix(NA, npt, length(Ad))
    xrange <- c(0, 180)                 # ����T������͈�
    for (k in seq(along=Ad)) {
        Adk <- Ad[k]
        A <- 10^(Adk/20)
        if (Adk == 0)
            y[, k] <- seq(dB(A/(A+1))+1e-6, ylim[2], len=npt)
        else
            y[, k] <- seq(dB(A/(A+1))+1e-6, dB(A/(A-1))-1e-6, len=npt)
        for (i in 1:npt) {
            yi <- y[i, k]
            if (f(xrange[1]) * f(xrange[2]) < 0)
                x[i, k] <- uniroot(f, xrange)$root
        }
    }
    plot(NA, NA, type="l", col="red", lty=1,
        xlim=xlim, ylim=ylim, xaxs="i", yaxs="i", xaxt="n",
        xlab="Phase (deg)", ylab="Loop Gain (dB)")
    idx <- floor(npt*0.85)
    if (!is.null(pn)) {
        for (n in pn) {
            matlines(x+360*n, y, type="l", col="red", lty=1)
            text(x[idx, ]+360*n, y[idx, ], Ad)
        }
    }
    if (!is.null(mn)) {
        for (n in mn) {
            matlines(-x+360*n, y, type="l", col="red", lty=1)
            text(-x[idx, ]+360*n, y[idx, ], Ad)
        }
    }

    g <- function(y) {
        r <- 10^(y/20)
        a <- xi / 180 * pi
        Ab <- r * cos(a) + r * sin(a) * j
        Arg(Ab) - Arg(1+Ab) - phik/180*pi
    }
    y <- x <- matrix(NA, npt, length(phi))
    yrange <- c(-200, ylim[2])          # ����T������͈�(�P��: dB)
    phx <- function(lo, hi, n) {
        x <- seq(0, 1, len=n/2)
        f <- c(x^2/2, 1-(1-x)^2/2)
        (hi-lo) * f + lo
    }
    for (k in seq(along=phi)) {
        phik <- phi[k]
        x[, k] <- phx(phik+0.01, 180, npt)
        for (i in 1:npt) {
            xi <- x[i, k]
            if (g(yrange[1]) * g(yrange[2]) < 0)
                y[i, k] <- uniroot(g, yrange)$root
        }
    }
    idx <- floor(npt*0.2)
    if (!is.null(pn)) {
        for (n in pn) {
            matlines(x+360*n, y, type="l", col="blue", lty=1)
            text(x[idx, ]+360*n, y[idx, ], phi)
        }
    }
    if (!is.null(mn)) {
        for (n in mn) {
            matlines(-x+360*n, y, type="l", col="blue", lty=1)
            text(-x[idx, ]+360*n, y[idx, ], -phi)
        }
    }
    at <- seq(xlimi[1]*180, xlimi[2]*180, by = 45)
    axis(1, at=at)
    axis(1, at=at, tck=1, lwd=0.3)
    axis(2, tck=1, lwd=0.3)
    invisible()
}

`nyquist` <-
function(x, col=3, lty=1) {
    px <- Re(x$A)
    py <- Im(x$A)
    lf <- log10(x$f)
    ok <- abs(round(lf)-lf) < 0.001
    matlines(px, py, col=col, lty=lty)
    if (!is.matrix(px))
        px <- matrix(px)
    if (!is.matrix(py))
        py <- matrix(py)
    text(px[ok, ], py[ok, ], eunit(x$f[ok]))
}

`nyquist.grid` <-
function(Ad=c(2, 1.78, 1.41, 1.33, 1.19, 1.15, 1.09, 1.07,
        1/1.07, 1/1.09, 1/1.15, 1/1.19, 1/1.33, 1/1.41, 1/1.78, 1/2),
    phi=c(27, 14, 10, 7, 6, 4+45/60, 3+35/60,
        -3-35/60, -4-45/60, -6, -7, -10, -14, -27),
    npt=80, xlim=c(-11, 10), ylim=c(-10.5, 10.5)) {
    j <- 0+1i
    f <- function(y) {
        Ab <- xi + j*y
        abs(Ab)/abs(1+Ab) - Adk
    }
    y <- x <- matrix(NA, npt, length(Ad))
    for (k in seq(along=Ad)) {
        Adk <- Ad[k]
        if (Adk < 1)
            x[, k] <- seq(-Adk/(1+Adk), min(Adk/(1-Adk), xlim[2]), len=npt)
        else
            x[, k] <- seq(-Adk/(1+Adk), max(xlim[1], Adk/(1-Adk)), len=npt)
        yrange <- c(0, ylim[2])
        for (i in 2:npt) {
            xi <- x[i, k]
            if (f(yrange[1]) * f(yrange[2]) < 0)
                y[i, k] <- uniroot(f, yrange)$root
            else
                y[i, k] <- 0
        }
    }
    par(pty="s")
    matplot(x, y, type="l", col="red", lty=1,
        xlim=xlim, ylim=ylim, xaxs="i", yaxs="i",
        xlab="Re(Ab)", ylab="Im(Ab)")
    matlines(x, -y, type="l", col="red", lty=1)
    idx <- floor(npt*0.85)
    lab <- paste(format(signif(Ad, 3)), " (",
            format(round(dB(Ad), 1)), "dB)", sep="")
    text(x[idx, ], y[idx, ], lab)
    text(x[idx, ], -y[idx, ], lab)

    g <- function(x) {
        Ab <- x + j*yi
        Arg(Ab) - Arg(1+Ab) - phik
    }
    y <- x <- matrix(NA, npt, length(phi))
    for (k in seq(along=phi)) {
        phik <- phi[k] / 180 * pi
        if (phik > 0)
            y[, k] <- seq(0, min(0.5/tan(phik/2), ylim[2]), len=npt)
        else
            y[, k] <- seq(0, max(0.5/tan(phik/2), ylim[1]), len=npt)
        xrange <- c(-0.5, 0.5/tan(phik/2))
        for (i in 2:npt) {
            yi <- y[i, k]
            if (abs(g(xrange[1])) < 1e-4)
                x[i, k] <- -0.5
            else if (g(xrange[1]) * g(xrange[2]) < 0)
                x[i, k] <- uniroot(g, xrange)$root
        }
    }
    matlines(x, y, type="l", col="blue", lty=1)
    matlines(-x - 1, y, type="l", col="blue", lty=1)
    idx <- floor(npt*0.9)
    aphi <- abs(phi)
    lab <- paste(ifelse(phi < 0, "-", ""),
            floor(aphi), ifelse(aphi %% 1 > 0,
            paste(".", round(aphi %% 1 * 60), "'", sep=""), ""), sep="")
    text(x[idx, ], y[idx, ], lab)
    text(-x[idx, ]-1, y[idx, ], lab)
    invisible()
}

`op.diff` <-
function(p, Ebb, Eg0, RL1, RL2=RL1, Ik, Rk)
{
    # ����������H�̓���_�����߂�
    # p: �^��ǃ��f���p�����[�^
    # Ebb: �d���d��
    # Eg0: �O���b�h�o�C�A�X�d��
    # RL1: V1���ג�R(DC)
    # RL2: V2���ג�R(DC)
    # Ik: ���ʃJ�\�[�h�d��
    # Rk: �J�\�[�h��R

    # �K�v�ȃp�����[�^���w�肳��Ă��邩�`�F�b�N����
    if (missing(Ik) && missing(Rk))
        stop("Ik or Rk must be specified.")
    if (missing(Ik))
        mode <- 1       # mullard
    else
        mode <- 0       # diff

    # eg, ek ����܂����Ƃ���(�������ׂɑ΂���)�΃A�[�X�v���[�g�d�������߂�
    get.ep.dc <- function(eg, ek, RL) {
        # eg: �΃A�[�X�O���b�h�d��
        # ek: �΃A�[�X�J�\�[�h�d��
        # RL: ���ג�R
        ip <- Ip(p, Ebb-ek, eg-ek)      # ���̓d���d���ɂ��ő�v���[�g�d��
        if (ip <= 0 || RL <= 0)         # �J�b�g�I�t�܂��͕��ׂ��Ȃ��ꍇ��
            return(list(ep=Ebb, ip=ip, ik=ip))  # �v���[�g�d���� Ebb
        ep <- uniroot(function(ep) {
            ip2 <- (Ebb - ep)/RL        # ���[�h���C�����狁�߂��v���[�g�d��
            ip1 <- Ip(p, ep-ek, eg-ek)  # �^��ǂ̓����ɂ��v���[�g�d��
            ip1 - ip2                   # ���҂̍����Ȃ��Ȃ�悤�� ep �����߂�
        }, c(ek, Ebb))$root
        z <- Ip.sub(p, ep-ek, eg-ek)
        list(ep=ep, ip=z$ip, ik=z$ip+z$ig)
    }

    # ����J�\�[�h�d����^�����Ƃ���
    # V1, V2�̍��v�d���ƃJ�\�[�h�d���̐H���Ⴂ��Ԃ��֐�(����_�T���p)
    f.dc <- function(ek) {
        v1 <- get.ep.dc(Eg0, ek, RL1)
        v2 <- get.ep.dc(Eg0, ek, RL2)
        v1$ik + v2$ik - (if (mode == 1) ek/Rk else Ik)
    }

    # ����̋��̓d���~�����Ȃ��Ȃ����Ɖ��肵���ꍇ�̃J�\�[�h�d�����ő�l�Ƃ���
    if (mode == 1)
        ekmax <- Ebb * Rk / (Rk + min(c(RL1, RL2)))
    else
        ekmax <- Ebb - Ik * min(c(RL1, RL2))

    # ����_�����߂�
    ek <- uniroot(f.dc, c(Eg0, ekmax), tol=1e-6)$root   # ����_�̃J�\�[�h�d��
    v1 <- get.ep.dc(Eg0, ek, RL1)
    Eo10 <- v1$ep
    Ip10 <- v1$ip
    v2 <- get.ep.dc(Eg0, ek, RL2)
    Eo20 <- v2$ep
    Ip20 <- v2$ip
    list(ek=ek, eo1=v1$ep, eo2=v2$ep, ip1=v1$ip, ep1=v1$ep-ek, ip2=v2$ip, ep2=v2$ep-ek, ekmax=ekmax)
}

`op.vol` <-
function (p, Ebb, Eg0, Rp, Rk)
{
    # �d�������i�̓���_�����߂�
    # p: �^��ǂ̃p�����[�^
    # Ebb: �d���d��
    # Eg0: �O���b�h�d��
    # Rp: �v���[�g�����ג�R
    # Rk: �J�\�[�h�����ג�R

    RL <- Rp + Rk                   # ���ג�R
    f <- function(ep) {
        # ep: �΃J�\�[�h�v���[�g�d��
        ip2 <- (Ebb - ep)/RL        # ���[�h���C���ɂ��d��
        ek <- ip2 * Rk              # �J�\�[�h�d��
        ip1 <- Ip(p, ep, Eg0-ek)        # �v���[�g�d���ɑ΂���v���[�g�d��
        ip1 - ip2                   # ����0�ɂȂ�v���[�g�d�������߂�
    }
    ep <- if (Ip(p, Ebb, Eg0) == 0) Ebb # �J�b�g�I�t
            else uniroot(f, c(0, Ebb))$root
    ip <- (Ebb - ep)/RL             # �v���[�g�d��
    ek <- ip * Rk                   # �J�\�[�h�d��
    eo <- ep + ek
    list(ip=ip, eo=eo, ep=ep, ek=ek)
}

`opt.cal` <-
function (Lp=392.5, Rp=0, Zp=3.2e3, rs=3.2e3, f=300e3, target=c(-3, -90, 1800))
{
    j <- 0 + 1i
    func <- function(x) {
        Lsp <- exp(x[1])
        Cp <- exp(x[2])
        # cat("Lsp=", Lsp, ", Cp=", Cp, "\n", sep="")
        jw <- j * 2 * pi * c(f, 1e3)
        ZLp <- jw * Lp
        ZLsp <- jw * Lsp
        ZCp <- 1 / (jw * Cp)
        X <- ZLp %p% Zp
        Y <- ZCp %p% (ZLsp + Rp + X)
        A <- 2 * Y / (rs + Y) * X / (ZLsp + Rp + X)
        eA <- dB(A[1]) - dB(A[2])
        eP <- Arg(A[1])/pi * 180
        eZ <- abs(Y[1])
        e <- c(eA, eP, eZ)
        # print(e)
        sum(((e - target)/target)^2)
    }
    o <- optim(log(c(Lp/10000, 500e-12)), func)
    exp(o$par)
}

`opt.cal.all` <-
function(Zst=8)
{
    # Zst: target Zs
    z <- matscan("opt.dat", sep=",", what="")
    model <- dimnames(z)[[1]]
    rs <- as.numeric(z[, 1])
    Zp <- as.numeric(z[, 2])
    type <- z[, 3]
    Ipmax <- as.numeric(z[, 4])
    freq.range <- z[, 5]
    Pomax <- as.numeric(z[, 6])
    Rp <- as.numeric(z[, 7])
    Rs <- as.numeric(z[, 8])
    Lp <- as.numeric(z[, 9])
    Lpmax <- as.numeric(z[, 10])
    f <- as.numeric(z[, 11])
    res <- as.numeric(z[, 12])
    ph <- as.numeric(z[, 13])
    imp <- as.numeric(z[, 14])

    na <- is.na(Lp)
    Lp[na] <- Lpmax[na] / ifelse(type[na] == "PP", 3, 2)

    n <- sqrt((Zp-Rp)/(8+Rs))       # turn ratio
    Ls <- Lp / n^2 * (Zst / 8)      # secondary inductance

    Lsp <- rep(NA, length(model))   # leakage (stray) inductance
    Cp <- rep(NA, length(model))    # stray capacitance
    for (i in seq(along=model)) {
        if (is.finite(f[i]) && is.finite(res[i])
          && is.finite(ph[i]) && is.finite(imp[i])
          && is.finite(Rp[i]) && is.finite(Rs[i])) {
            cat(model[i], "\n")
            o <- opt.cal(Lp[i], Rp[i]+Rs[i]*n[i]^2, (8+Rs[i])*n[i]^2,
                    rs[i], f[i], c(res[i], ph[i], imp[i]))
            Lsp[i] <- o[1]
            Cp[i] <- o[2]
        }
    }

    Q <- Lp / Lsp                   # quality factor
    K <- 1 - 1 / (2 * Q)            # coupling factor

    Paste <- function(...) paste(sep="", ...)

    for (i in seq(along=model)) {
        if (is.finite(K[i])) {
            s <- NULL
            s[1] <- "*"
            s[2] <- Paste("*\t", model[i])
            s[3] <- "*"
            if (type[i] == "PP") {
                s[4] <- Paste(".SUBCKT ", model[i], " P1 B1 B2 P2 S1 S0")
                s[5] <- Paste("* Primary inductance (p-p ", Zp[i], "ohm ", Lp[i], "H)")
                s[6] <- Paste("L11 P1 11 ", Lp[i]/4, "H")
                s[7] <- Paste("L12 12 P2 ", Lp[i]/4, "H")
                s[8] <- "* Primary DC resistance"
                s[9] <- Paste("R11 11 B1 ", Rp[i]/2)
                s[10] <- Paste("R12 B2 12 ", Rp[i]/2)
                s[11] <- "* Primary stray capacitance"
                s[12] <- Paste("CP P1 P2 ", Cp[i])
                s[13] <- Paste("* Secondary inductance (", Zst, "ohm)")
                s[14] <- Paste("L13 S1 21 ", Ls[i], "H")
                s[15] <- "* Secondary DC resistance"
                s[16] <- Paste("R13 S0 21 ", Rs[i]*sqrt(Zst/8))
                s[17] <- "* coupling factor"
                s[18] <- Paste("K1 L11 L13 ", K[i])
                s[19] <- Paste("K2 L12 L13 ", K[i])
                s[20] <- Paste("K3 L11 L12 ", K[i])
                s[21] <- ".ENDS"
            } else {
                s[4] <- Paste(".SUBCKT ", model[i], " P B S1 S0")
                s[5] <- Paste("* Primary inductance (", Zp[i], "ohm ", Lp[i], "H)")
                s[6] <- Paste("L1 P 1 ", Lp[i], "H")
                s[7] <- "* Primary DC resistance"
                s[8] <- Paste("R1 1 B ", Rp[i])
                s[9] <- "* Primary stray capacitance"
                s[10] <- Paste("CP P B ", Cp[i])
                s[11] <- Paste("* Secondary inductance (", Zst, "ohm)")
                s[12] <- Paste("L2 S1 2 ", Ls[i], "H")
                s[13] <- "* Secondary DC resistance"
                s[14] <- Paste("R2 2 S0 ", Rs[i]*sqrt(Zst/8))
                s[15] <- "* coupling factor"
                s[16] <- Paste("K L1 L2 ", K[i])
                s[17] <- ".ENDS"
            }
            write(s, file=Paste(model[i], ".inc"))
        }
    }

    invisible()
}

`pad` <-
function (n) 
{
    paste(rep(" ", n), collapse="")
}

`pngi` <-
function(file, wh=c(400, 300), point=12, mai=c(0.45, 0.45, 0.1, 0.1), ...)
{
    # file: �o�̓t�@�C����
    # wh: �O���t�G���A�̕��ƍ���(�P��mm)
    # point: �����̑傫��(point)
    # mai: �]��(in)

    cat("Writing: ", file, "\n", sep="")
    mai <- mai * point / 6.5 * 1.1
    w <- wh[1] + (mai[1] + mai[3]) * 75
    h <- wh[2] + (mai[2] + mai[4]) * 75
    png(file=file, point=point, width=w, height=h, ...)
    par(mai=mai)
    invisible()
}

`ps` <-
function(file, vsize = 1, hsize = 1, pointsize = 12, pty = "r",
        horizontal = FALSE)
{
    wid <- (580.5 - 16.2)/72        # S��ps�̒P�ʂ�inch�ɕϊ�
    ht <- (821.7 - 15.48)/72        # S��ps�̒P�ʂ�inch�ɕϊ�
    wid <- wid * hsize
    ht <- ht * vsize
    if(pty == "s")
        wid <- ht <- min(c(wid, ht))
    postscript(file, width = wid, height = ht, pointsize = pointsize,
            horizontal = horizontal)
}

`psi` <-
function(file, wh=c(103.9, 68.8), point=6.5, mai=c(0.45, 0.45, 0.1, 0.1), horizontal=FALSE, family=ps.options()$family)
{
    # file: �o�̓t�@�C����
    # wh: �O���t�G���A�̕��ƍ���(�P��mm)
    # point: �����̑傫��(point)
    # mai: �]��(in)

    wh <- wh / 25.4
    cat("Writing: ", file, "\n", sep="")
    postscript(file=file, point=point,
        width=wh[1] + mai[2] + mai[4], height=wh[2] + mai[1] + mai[3],
        horizontal=horizontal, family=family)
    par(mai=mai)
    invisible()
}

`psim` <-
function(file, wh=c(103.9, 68.8), point=6.5, mai=c(0.45, 0.45, 0.1, 0.1), mfrow=c(1, 1), mfcol=NULL, family=ps.options()$family) 
{
    # file: �o�̓t�@�C����
    # wh: �O���t�G���A�̕��ƍ���(�P��mm)
    # point: �����̑傫��(point)
    # mai: �]��(in)

    wh <- wh / 25.4
    if (!is.null(mfcol)) {
        nr <- mfcol[1]
        nc <- mfcol[2]
    } else {
        nr <- mfrow[1]
        nc <- mfrow[2]
    }
    cat("Writing: ", file, "\n", sep="")
    postscript(file=file, point=point,
        width=(wh[1] + mai[2] + mai[4])*nc,
        height=(wh[2] + mai[1] + mai[3])*nr,
        horizontal=FALSE)
    par(mai=mai)
    if (!is.null(mfcol))
        par(mfcol=mfcol)
    else
        par(mfrow=mfrow)
    invisible()
}

`quad` <-
function (a, b, c) 
{
    d <- b^2 - 4*a*c
    if (d >= 0)
        return((-b+c(1,-1)*sqrt(d))/(2*a))
    (-b+c(1,-1)*sqrt(-d)*(0+1i))/(2*a)
}

`r2spice` <-
function(p, mn, fn, mode="triode", ...)
{
    # R�̃p�����[�^��SPICE 3�̃T�u��H�ɕϊ�����
    # p: R�̃p�����[�^
    # mn: SPICE�̃T�u��H��
    # fn: SPICE�̃t�@�C����(�g���q���̂���)
    # mode: �o�͂��郂�f���̎��("triode" or "pentode")
    # ...: �d�Ɋԗe�ʓ�

    Paste <- function(...) paste(sep="", ...)
    sig <- function(x) signif(x,8)
    version <- Paste("* Version 3.10, Generated on ", date())
    dir.create("spice/tubemodel", showWarnings=FALSE, recursive=TRUE)
    dir.create("simetrix/tubemodel", showWarnings=FALSE, recursive=TRUE)
    dir.create("tina/tubemodel", showWarnings=FALSE, recursive=TRUE)

    a <- 1/(1 - p$alpha)
    b <- 1.5 - a
    c <- 3 * p$alpha - 1
    mum <- a / 1.5 * p$muc
    G.p <- p$G * (c * a / 3)^b
    Ig.ratio <- if (is.null(p$Ig.ratio)) 0.5/(1 + 1/mum)^1.5 else p$Ig.ratio
    G.lim <- if (is.null(p$G.lim)) G.p * (1 + 1/mum)^1.5 else p$G.lim
    tubetype <- if (is.null(p$pentode.chara)) "triode" else "pentode"
    caps <- cap(tubetype=tubetype, ...)
    Cgpt <- caps$Cgpt * 1e12
    Cgkt <- round(caps$Cgkt * 1e12, 1)
    Cpkt <- round(caps$Cpkt * 1e12, 1)
    if (tubetype == "pentode") {
        Cgpt <- round(caps$Cgpt * 1e12, 1)
        Cgp <- caps$Cgp * 1e12
        Cgk <- round(caps$Cgk * 1e12, 1)
        Cpk <- round(caps$Cpk * 1e12, 1)
        Cg1g2 <- round(caps$Cg1g2 * 1e12, 1)
    }
    pad <- paste(rep(" ", 8 + nchar(mn)), collapse="")

    # Spice 3f4 �p�̃��f�����o��
    s <- NULL
    s[1] <- "*"
    s[3] <- "* Copyright 2003--2008 by Ayumi Nakabayashi, All rights reserved."
    s[4] <- version
    if (mode == "triode") {
        s[2] <- Paste("* Generic triode model: ", mn)
        s[5] <- Paste("*", pad, "Plate")
        s[6] <- Paste("*", pad, "| Grid")
        s[7] <- Paste("*", pad, "| | Cathode")
        s[8] <- Paste("*", pad, "| | |")
        s[9] <- Paste(".SUBCKT ", mn, " A G K")
        s[10] <- Paste("BGG   GG   0 V=V(G,K)+", p$Ego)
        s[11] <- Paste("BM1   M1   0 V=(", sig(c/2/p$muc), "*(URAMP(V(A,K))+1e-10))^", sig(b))
        s[12]<- Paste("BM2   M2   0 V=(", sig(1.5/a), "*(URAMP(V(GG)+URAMP(V(A,K))/", p$muc, ")+1e-10))^", sig(a))
        s[13]<- Paste("BP    P    0 V=", sig(G.p), "*(URAMP(V(GG)+URAMP(V(A,K))/", sig(mum), ")+1e-10)^1.5")
        s[14]<- Paste("BIK   IK   0 V=U(V(GG))*V(P)+(1-U(V(GG)))*", p$G, "*V(M1)*V(M2)")
        s[15]<- Paste("BIG   IG   0 V=", sig(Ig.ratio*G.lim), "*URAMP(V(G,K))^1.5*(URAMP(V(G,K))/(URAMP(V(A,K))+URAMP(V(G,K)))*1.2+0.4)")
        s[16]<- Paste("BIAK  A    K I=URAMP(V(IK,IG)-URAMP(V(IK,IG)-(", sig((1-Ig.ratio)*G.lim), "*URAMP(V(A,K))^1.5)))+1e-10*V(A,K)")
        s[17]<- "BIGK  G    K I=V(IG)"
        s[18]<- "* CAPS"
        s[19]<- Paste("CGA   G    A ", Cgpt, "p")
        s[20]<- Paste("CGK   G    K ", Cgkt, "p")
        s[21]<- Paste("CAK   A    K ", Cpkt, "p")
        s[22]<- ".ENDS"
    } else {
        s[2] <- Paste("* Generic pentode model: ", mn)
        s[5] <- Paste("*", pad, "Plate")
        s[6] <- Paste("*", pad, "| Screen Grid")
        s[7] <- Paste("*", pad, "| | Control Grid")
        s[8] <- Paste("*", pad, "| | | Cathode")
        s[9] <- Paste("*", pad, "| | | |")
        s[10] <- Paste(".SUBCKT ", mn, " A G2 G1 K")
        s[11] <- Paste("BGG   GG   0 V=V(G1,K)+", p$Ego)
        s[12]<- Paste("BM1   M1   0 V=(", sig(c/2/p$muc), "*(URAMP(V(G2,K))+1e-10))^", sig(b))
        s[13]<- Paste("BM2   M2   0 V=(", sig(1.5/a), "*(URAMP(V(GG)+URAMP(V(G2,K))/", p$muc, ")))^", sig(a))
        s[14]<- Paste("BP    P    0 V=", sig(G.p), "*(URAMP(V(GG)+URAMP(V(G2,K))/", sig(mum), "))^1.5")
        s[15]<- Paste("BIK   IK   0 V=U(V(GG))*V(P)+(1-U(V(GG)))*", p$G, "*V(M1)*V(M2)")
        s[16]<- Paste("BIG   IG   0 V=", sig(Ig.ratio*G.lim), "*URAMP(V(G1,K))^1.5*(URAMP(V(G1,K))/(URAMP(V(A,K))+URAMP(V(G1,K)))*1.2+0.4)")
        s[17]<- "BIK2  IK2  0 V=V(IK,IG)*(1-0.4*(EXP(-URAMP(V(A,K))/URAMP(V(G2,K))*15)-EXP(-15)))"
        s[18]<- Paste("BIG2T IG2T 0 V=V(IK2)*(", 1-p$g2.r, "*(1-URAMP(V(A,K))/(URAMP(V(A,K))+10))^1.5+", p$g2.r, ")")
        s[19]<- Paste("BIK3  IK3  0 V=V(IK2)*(URAMP(V(A,K))+", -p$Ea, ")/(URAMP(V(G2,K))+", -p$Ea, ")")
        s[20]<- Paste("BIK4  IK4  0 V=V(IK3)-URAMP(V(IK3)-(", sig((1-Ig.ratio)*G.lim), "*(URAMP(V(A,K))+URAMP(URAMP(V(G2,K))-URAMP(V(A,K))))^1.5))")
        s[21]<- Paste("BIP   IP   0 V=URAMP(V(IK4,IG2T)-URAMP(V(IK4,IG2T)-(", sig((1-Ig.ratio)*G.lim), "*URAMP(V(A,K))^1.5)))")
        s[22]<- "BIAK  A    K I=V(IP)+1e-10*V(A,K)"
        s[23]<- "BIG2  G2   K I=URAMP(V(IK4,IP))"
        s[24]<- "BIGK  G1   K I=V(IG)"
        s[25]<- "* CAPS"
        s[26]<- Paste("CGA   G1  A  ", Cgp, "p")
        s[27]<- Paste("CGK   G1  K  ", Cgk, "p")
        s[28]<- Paste("C12   G1  G2 ", Cg1g2, "p")
        s[29]<- Paste("CAK   A   K  ", Cpk, "p")
        s[30]<- ".ENDS"
    }
    filename <- paste("spice/tubemodel/", fn, ".inc", sep="")
    cat("Writing", filename, "\n")
    write(s, file=filename)

    # SIMetrix�p�̃��f�����o��
    s <- NULL
    s[1] <- "*"
    s[3] <- "* Copyright 2003--2008 by Ayumi Nakabayashi, All rights reserved."
    s[4] <- "* Thanks to Tooru Kuroda."
    s[5] <- version
    if (mode == "triode") {
        s[2] <- Paste("* Generic triode model: ", mn)
        s[6] <- Paste("*", pad, "Plate")
        s[7] <- Paste("*", pad, "| Grid")
        s[8] <- Paste("*", pad, "| | Cathode")
        s[9] <- Paste("*", pad, "| | |")
        s[10] <- Paste(".SUBCKT ", mn, " A G K")
        s[11] <- Paste(".param GG {(V(G,K)+", p$Ego, ")}")
        s[12] <- ".param EP {URAMP(V(A,K))}"
        s[13] <- ".param EG {URAMP(V(G,K))}"
        s[14]<- Paste(".param M1 {((", sig(c/2/p$muc), "*EP)^", sig(b), ")}")
        s[15]<- Paste(".param M2 {((", sig(1.5/a), "*URAMP(GG+EP/", p$muc, "))^", sig(a), ")}")
        s[16]<- Paste(".param P  {(", sig(G.p), "*URAMP(GG+EP/", sig(mum), ")^1.5)}")
        s[17]<- Paste(".param IK {(U(GG)*P+(1-U(GG))*", p$G, "*M1*M2)}")
        s[18]<- Paste(".param IG {(", sig(Ig.ratio*G.lim), "*EG^1.5*(EG/(EP+EG)*1.2+0.4))}")
        s[19]<- Paste("BIAK A K I=URAMP(IK-IG-URAMP(IK-IG-", sig((1-Ig.ratio)*G.lim), "*EP^1.5))+1e-10*V(A,K)")
        s[20]<- "BIGK G K I=IG"
        s[21]<- "* CAPS"
        s[22]<- Paste("CGA G A ", Cgpt, "p")
        s[23]<- Paste("CGK G K ", Cgkt, "p")
        s[24]<- Paste("CAK A K ", Cpkt, "p")
        s[25]<- ".ENDS"
    } else {
        s[2] <- Paste("* Generic pentode model: ", mn)
        s[6] <- Paste("*", pad, "Plate")
        s[7] <- Paste("*", pad, "| Screen Grid")
        s[8] <- Paste("*", pad, "| | Control Grid")
        s[9] <- Paste("*", pad, "| | | Cathode")
        s[10] <- Paste("*", pad, "| | | |")
        s[11] <- Paste(".SUBCKT ", mn, " A G2 G1 K")
        s[12] <- Paste(".param GG  {(V(G1,K)+", p$Ego, ")}")
        s[13] <- ".param EP  {URAMP(V(A,K))}"
        s[14] <- ".param EG  {URAMP(V(G1,K))}"
        s[15]<- ".param EG2 {URAMP(V(G2,K))}"
        s[16]<- Paste(".param M1  {((", sig(c/2/p$muc), "*EG2)^", sig(b), ")}")
        s[17]<- Paste(".param M2  {((", sig(1.5/a), "*URAMP(GG+EG2/", p$muc, "))^", sig(a), ")}")
        s[18]<- Paste(".param P   {(", sig(G.p), "*URAMP(GG+EG2/", sig(mum), ")^1.5)}")
        s[19]<- Paste(".param IK  {(U(GG)*P+(1-U(GG))*", p$G, "*M1*M2)}")
        s[20]<- Paste(".param IG  {(", sig(Ig.ratio*G.lim), "*EG^1.5*(EG/(EP+EG)*1.2+0.4))}")
        s[21]<- ".param IK2 {((IK-IG)*(1-0.4*(EXP(-EP/(EG2+1e-10)*15)-EXP(-15))))}"
        s[22]<- Paste(".param IG2T {(IK2*(", 1-p$g2.r, "*(1-EP/(EP+10))^1.5+", p$g2.r, "))}")
        s[23]<- Paste(".param IK3 {(IK2*(EP+", -p$Ea, ")/(EG2+", -p$Ea, "))}")
        s[24]<- Paste(".param IK4 {(IK3-URAMP(IK3-(", sig((1-Ig.ratio)*G.lim), "*(EP+URAMP(EG2-EP))^1.5)))}")
        s[25]<- Paste(".param IP  {URAMP(IK4-IG2T-URAMP(IK4-IG2T-(", sig((1-Ig.ratio)*G.lim), "*EP^1.5)))}")
        s[26]<- "BIAK A  K I=IP+1e-10*V(A,K)"
        s[27]<- "BIG2 G2 K I=URAMP(IK4-IP)"
        s[28]<- "BIGK G1 K I=IG"
        s[29]<- "* CAPS"
        s[30]<- Paste("CGA G1 A  ", Cgp, "p")
        s[31]<- Paste("CGK G1 K  ", Cgk, "p")
        s[32]<- Paste("C12 G1 G2 ", Cg1g2, "p")
        s[33]<- Paste("CAK A  K  ", Cpk, "p")
        s[34]<- ".ENDS"
    }
    filename <- paste("simetrix/tubemodel/", fn, ".mod", sep="")
    cat("Writing", filename, "\n")
    write(s, file=filename)

    # TINA�p�̃��f�����o��
    s <- NULL
    s[1] <- "*"
    s[3] <- "* Copyright 2003--2008 by Ayumi Nakabayashi, All rights reserved."
    s[4] <- version
    if (mode == "triode") {
        s[2] <- Paste("* Generic triode model: ", mn)
        s[5] <- Paste("*", pad, "Plate")
        s[6] <- Paste("*", pad, "| Grid")
        s[7] <- Paste("*", pad, "| | Cathode")
        s[8] <- Paste("*", pad, "| | |")
        s[9] <- Paste(".SUBCKT ", mn, " A G K")
        s[10] <- Paste(".PARAM X1=", p$Ego, " X2=", sig(c/2/p$muc), " X3=", sig(b))
        s[11] <- Paste(".PARAM X4=", sig(1.5/a), " X5=", p$muc, " X6=", sig(a))
        s[12] <- Paste(".PARAM X7=", sig(G.p), " X8=", sig(mum), " X9=", p$G)
        s[13] <- Paste(".PARAM Y1=", sig(Ig.ratio*G.lim), " Y2=", sig((1-Ig.ratio)*G.lim))
        s[14] <- "BK IK 0 V=U(V(G,K)+X1)*X7*URAMP(V(G,K)+X1+URAMP(V(A,K))/X8)^1.5+(1-U(V(G,K)+X1))*X9*(X2*URAMP(V(A,K)))^X3*(X4*URAMP(V(G,K)+X1+URAMP(V(A,K))/X5))^X6"
        s[15] <- "BA A K I=URAMP((Y2*URAMP(V(A,K))^1.5)-URAMP((Y2*URAMP(V(A,K))^1.5)-V(IK)+Y1*URAMP(V(G,K))^1.5*(URAMP(V(G,K))/(URAMP(V(A,K))+URAMP(V(G,K)))*1.2+.4)))+1E-10*V(A,K)"
        s[16] <- "BG G K I=Y1*URAMP(V(G,K))^1.5*(URAMP(V(G,K))/(URAMP(V(A,K))+URAMP(V(G,K)))*1.2+.4)"
        s[17]<- "* CAPS"
        s[18]<- Paste("CGA G A ", Cgpt, "p")
        s[19]<- Paste("CGK G K ", Cgkt, "p")
        s[20]<- Paste("CAK A K ", Cpkt, "p")
        s[21]<- ".ENDS"
    } else {
        s[2] <- Paste("* Generic pentode model: ", mn)
        s[5] <- Paste("*", pad, "Plate")
        s[6] <- Paste("*", pad, "| Screen Grid")
        s[7] <- Paste("*", pad, "| | Control Grid")
        s[8] <- Paste("*", pad, "| | | Cathode")
        s[9] <- Paste("*", pad, "| | | |")
        s[10] <- Paste(".SUBCKT ", mn, " A S G K")
        s[11] <- Paste(".PARAM X1=", p$Ego, " X2=", sig(c/2/p$muc), " X3=", sig(b))
        s[12] <- Paste(".PARAM X4=", sig(1.5/a), " X5=", p$muc, " X6=", sig(a))
        s[13] <- Paste(".PARAM X7=", sig(G.p), " X8=", sig(mum), " X9=", p$G)
        s[14] <- Paste(".PARAM Y1=", sig(Ig.ratio*G.lim), " Y2=", 1-p$g2.r, " Y3=", p$g2.r)
        s[15] <- Paste(".PARAM Y4=", sig((1-Ig.ratio)*G.lim), " EA=", -p$Ea)
        s[16] <- "BK IK 0 V=U(V(G,K)+X1)*X7*URAMP(V(G,K)+X1+URAMP(V(S,K))/X8)^1.5+(1-U(V(G,K)+X1))*X9*(X2*URAMP(V(S,K)))^X3*(X4*URAMP(V(G,K)+X1+URAMP(V(S,K))/X5))^X6"
        s[17] <- "BL IL 0 V=(V(IK)-Y1*URAMP(V(G,K))^1.5*(URAMP(V(G,K))/(URAMP(V(A,K))+URAMP(V(G,K)))*1.2+.4))*(1-.4*(EXP(-URAMP(V(A,K))/URAMP(V(S,K))*15)-EXP(-15)))"
        s[18] <- "BM IM 0 V=V(IL)*(URAMP(V(A,K))+EA)/(URAMP(V(S,K))+EA)-URAMP(V(IL)*(URAMP(V(A,K))+EA)/(URAMP(V(S,K))+EA)-(Y4*(URAMP(V(A,K))+URAMP(URAMP(V(S,K))-URAMP(V(A,K))))^1.5))"
        s[19] <- "BA A K I=URAMP(Y4*URAMP(V(A,K))^1.5-URAMP(Y4*URAMP(V(A,K))^1.5-V(IM)+V(IL)*(Y2*(1-URAMP(V(A,K))/(URAMP(V(A,K))+10))^1.5+Y3)))+1E-10*V(A,K)"
        s[20] <- "BS S K I=URAMP(V(IM)-URAMP(Y4*URAMP(V(A,K))^1.5-URAMP(Y4*URAMP(V(A,K))^1.5-V(IM)+V(IL)*(Y2*(1-URAMP(V(A,K))/(URAMP(V(A,K))+10))^1.5+Y3))))"
        s[21] <- "BG G K I=Y1*URAMP(V(G,K))^1.5*(URAMP(V(G,K))/(URAMP(V(A,K))+URAMP(V(G,K)))*1.2+.4)"
        s[22]<- "* CAPS"
        s[23]<- Paste("CGA G A ", Cgp, "p")
        s[24]<- Paste("CGK G K ", Cgk, "p")
        s[25]<- Paste("CGS G S ", Cg1g2, "p")
        s[26]<- Paste("CAK A K ", Cpk, "p")
        s[27]<- ".ENDS"
    }
    filename <- paste("tina/tubemodel/", fn, ".inc", sep="")
    cat("Writing", filename, "\n")
    write(s, file=filename)

    invisible()
}

`rg2` <-
function(p, Ep, Eg, Eg2)
{
    # �܋Ɋǂ̃X�N���[���O���b�h������R�����߂�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��
    # Eg2: �X�N���[���O���b�h�d��

    i <- Ipp.sub(p, Ep, Eg, Eg2)
    df <- -6 * Ep / Eg2^2 * exp(-15*Ep/Eg2)
    ifelse(i$ig2 <= 0, NA,
        1 / (i$ig2 * (df/i$f + i$b / Eg2 + i$a / (p$muc * i$Egg + Eg2))))
}

`rowsum` <-
function(x)
    # �s�� x �̍s���̘a�����߂�(apply(x, 1, sum) �Ɠ���)
    drop(x %*% rep(1, ncol(x)))

`rp` <-
function(p, Ep, Eg)
{
    # �O�Ɋǂ̃v���[�g��R�����߂�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��

    i <- Ip.sub(p, Ep, Eg)
    ifelse(i$ip <= 0, NA,
        ifelse(i$Egg <= 0, (1-p$alpha) /
            ((1-3*p$alpha)/2/Ep + 1/p$muc/(i$Egg + Ep/p$muc)) / i$ip,
            (i$mum * i$Egg + Ep)/(1.5 * i$ip)))
}

`rpp` <-
function(p, Ep, Eg, Eg2)
{
    # �܋Ɋǃv���[�g��R�����߂�
    # p: �p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �O���b�h�d��
    # Eg2: �X�N���[���O���b�h�d��

    i <- Ipp.sub(p, Ep, Eg, Eg2)
    df <- 6 / Eg2 * exp(-15*Ep/Eg2)
    dg <- -15 * (1 - p$g2.r) * (1 - Ep/(Ep + 10))^0.5 / (Ep^2 + 20*Ep + 100)
    dh <- 1/(Eg2 - p$Ea)
    ifelse(i$ip <= 0, NA, 1/(i$ip * (df/i$f + (dh - dg)/(i$h - i$g))))
}

`semilogplot` <-
function (x, y, xlim, xlab=deparse(substitute(x)), ylab=deparse(substitute(y)),
    yaxt="s", type="p", xlabfunc=eunit, ...)
{
    lx <- log10(x)
    if (missing(xlim)) {
        xax <- logaxis(lx)
        xlim <- xax$lim
    } else {
        xlim <- log10(xlim)
        xax <- logaxis(xlim)
    }
    if (!is.matrix(y))
        y <- as.matrix(y)
    matplot(lx, y, type=type, xlab=xlab, ylab=ylab,
            xaxt="n", xaxs="i", xlim=xlim, yaxt=yaxt, ...)
    abline(v=log10(xax$tick), lwd=0.3)
    abline(v=ceiling(xlim[1]):floor(xlim[2]), lwd=0.6)
    if (!is.null(xlabfunc))
        labstr <- xlabfunc(xax$at)
    else
        labstr <- xax$at
    axis(1, at=log10(xax$at), lab=labstr, lwd=0.6)
    if (yaxt != "n")
        axis(2, tck=1, lwd=0.6)
    invisible()
}

`t10` <-
structure(list(G = 0.00020223856, muc = 7.7993226, alpha = 0.38360443, 
    Ego = -0.99999237, Cgp = 7e-12, Cgk = 4e-12, Cpk = 3e-12, 
    Vp = 425, Pp = 7.65, remark = "RCA", err = 0.0299587325718248, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`t12A` <-
structure(list(G = 0.00037491826, muc = 8.0527506, alpha = 0.44603974, 
    Ego = -0.99999998, Cgp = 8.5e-12, Cgk = 4e-12, Cpk = 2e-12, 
    Vp = 180, Pp = 1.4, remark = "RCA", err = 0.0384294921228442, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`t12AT7` <-
structure(list(G = 0.0042575005, muc = 35.090106, alpha = 0.69407322, 
    Ego = 0.67585931, Cgp = 1.5e-12, Ci = 2.2e-12, Co = 5e-13, 
    Vp = 300, Pp = 2.5, Ik = 0.015, remark = "Philips", err = 0.0436232609634453, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t12AU7` <-
structure(list(G = 0.00055330711, muc = 13.089625, alpha = 0.584886, 
    Ego = 0.89005722, Cgp = 1.5e-12, Ci = 1.6e-12, Co = 4e-13, 
    Vp = 300, Pp = 2.75, Ik = 0.02, remark = "Philips", err = 0.0262651792715577, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t12AX7` <-
structure(list(G = 0.00071211506, muc = 88.413802, alpha = 0.43455142, 
    Ego = 0.59836683, Cgp = 1.7e-12, Ci = 1.6e-12, Co = 4.6e-13, 
    Vp = 300, Pp = 1, Ik = 0.008, remark = "Philips", err = 0.0365493780072869, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t12AY7` <-
structure(list(G = 0.00054133951, muc = 33.263227, alpha = 0.54204836, 
    Ego = 0.71171435, Cgp = 1.3e-12, Ci = 1.3e-12, Co = 6e-13, 
    Vp = 300, Pp = 1.5, Ik = 0.01, remark = "RCA", err = 0.0239796120846602, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t12B4A` <-
structure(list(G = 0.0036584566, muc = 5.1134435, alpha = 0.63013576, 
    Ego = 1, Cgp = 4.8e-12, Ci = 5e-12, Co = 1.5e-12, Vp = 550, 
    Pp = 5.5, Ik = 0.03, remark = "GE", err = 0.0582651517458449, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t12BH7` <-
structure(list(G = 0.0024875937, muc = 11.754204, alpha = 0.68310039, 
    Ego = 0.99999999, G.lim = 0.00224, Ig.ratio = 0.5, Cgp = 2.6e-12, 
    Ci = 3.2e-12, Co = 5e-13, Vp = 300, Ik = 0.02, Pp = 3.5, 
    remark = "GE", ig = c(25, 0.14, 0.14), err = 0.0745816030486325, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Ci", "Co", "Vp", "Ik", "Pp", "remark", "ig", 
"err", "code"))
`t12BY7AT` <-
structure(list(G = 0.0036081888, muc = 21.860549, alpha = 0.54601771, 
    Ego = -0.02185341, Cgp = 6.3e-14, Ci = 1.02e-11, Co = 3.5e-12, 
    Vp = 300, Pp = 6.5, Pg2 = 1.1, remark = "GE", pentode.chara = c(250, 
    180, -3.175, 0.026, 0.00575, 130000), err = 0.00909441388732197, 
    code = 0L, g2.r = 0.17487853, Ea = -4890), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t12GN7AT` <-
structure(list(G = 0.018638041, muc = 35.989804, alpha = 0.50319154, 
    Ego = -0.52499611, Cgp = 1.2e-13, Ci = 1.75e-11, Co = 4e-12, 
    Vp = 400, Pp = 11.5, Pg2 = 1.5, remark = "GE", pentode.chara = c(250, 
    150, -1.932, 0.028, 0.0065, 50000), err = 0.011217478466897, 
    code = 0L, g2.r = 0.18223747, Ea = -1950), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t14AF7` <-
structure(list(G = 0.00046940316, muc = 15.384177, alpha = 0.39611163, 
    Ego = 0.77793251, g2.r = 7074773.4, Ea = -64.582547, Cgp = 2.3e-12, 
    Cgk = 2.2e-12, Cpk = 1.6e-12, Vp = 300, Pp = 2.5, err = 0.0379689755900587, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "g2.r", 
"Ea", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "err", "code"))
`t1619T` <-
structure(list(G = 0.00057412229, muc = 8.5941123, alpha = 0.45781233, 
    Ego = -0.99999999, Cgp = 3.5e-13, Ci = 1.05e-11, Co = 1.25e-11, 
    Vp = 400, Pp = 15, Pg2 = 3.5, remark = "RCA", pentode.chara = c(300, 
    250, -10, 0.044, 0.004, 75000), err = 0.0196851571979126, 
    code = 0L, g2.r = 0.077991475, Ea = -4700), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t20P1T` <-
structure(list(G = 0.0017001298, muc = 3.0024709, alpha = 0.6425999, 
    Ego = 0.99999997, Cgp = 5e-13, Ci = 2.3e-11, Co = 1.1e-11, 
    Vp = 400, Vg2 = 250, Pp = 20, Pg2 = 5, remark = "Mazda", 
    pentode.chara = c(360, 140, -22, 0.047, 0.00235, 25000), 
    err = 0.0301707981902798, code = 0L, g2.r = 0.043368527, 
    Ea = -1622.5), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Vg2", "Pp", "Pg2", "remark", "pentode.chara", 
"err", "code", "g2.r", "Ea"))
`t211` <-
structure(list(G = 0.00039351788, muc = 11.73864, alpha = 0.35000001, 
    Ego = 1, G.lim = 0.00052483067, Ig.ratio = 0.20987654, Cgp = 1.4e-11, 
    Cgk = 5.4e-12, Cpk = 4.8e-12, Vp = 1250, Pp = 75, remark = "RCA", 
    ig = c(175, 0.96, 0.255), err = 0.0189371020266342, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "G.lim", "Ig.ratio", "Cgp", "Cgk", "Cpk", 
"Vp", "Pp", "remark", "ig", "err", "code"))
`t24T` <-
structure(list(G = 0.00025402288, muc = 7.2755574, alpha = 0.60765895, 
    Ego = 0.67663821, g2.r = 0.10439332, Ea = -2237.1045, Cgp = 7e-15, 
    Ci = 5.3e-12, Co = 1.05e-11, Vp = 275, remark = "RCA", pentode.chara = c(180, 
    90, -3, 0.004, 0.0017, 4e+05), err = 0.117344264206906, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "g2.r", "Ea", "Cgp", "Ci", "Co", "Vp", 
"remark", "pentode.chara", "err", "code"))
`t25E5T` <-
structure(list(G = 0.0025511424, muc = 4.2639035, alpha = 0.56518086, 
    Ego = 1, Cgp = 1.1e-12, Ci = 1.75e-11, Co = 8e-12, Vp = 250, 
    Vg2 = 250, Pp = 12, Pg2 = 5, Ik = 0.1, remark = "Philips", 
    pentode.chara = c(100, 100, -8.2, 0.1, 0.007, 10000), err = 0.0135752945029985, 
    code = 0L, g2.r = 0.039081672, Ea = -1400), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t25HB5T` <-
structure(list(G = 0.0030838499, muc = 4.6299092, alpha = 0.4924121, 
    Ego = -0.49968094, Cgp = 4e-13, Cgk = 2.4e-11, Cgp = 9.5e-12, 
    Vp = 770, Vg2 = 220, Pp = 18, Pg2 = 3.5, Ik = 0.23, remark = "GE", 
    pentode.chara = c(130, 130, -20, 0.046, 0.0018, 34000), err = 0.0273769209412182, 
    code = 0L, g2.r = 0.018928155, Ea = -2216), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cgp", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t27` <-
structure(list(G = 0.00021306994, muc = 7.6982676, alpha = 0.54513429, 
    Ego = 0.99999994, Cgp = 3.3e-12, Cgk = 3.1e-12, Cpk = 2.3e-12, 
    Vp = 250, remark = "RCA", err = 0.0406695966930648, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "remark", "err", 
"code"))
`t2A3` <-
structure(list(G = 0.000709416, muc = 3.7366878, alpha = 0.47491658, 
    Ego = -0.47258991, Cgp = 1.65e-11, Cgk = 7.5e-12, Cpk = 5.5e-12, 
    Vp = 300, Pp = 15, remark = "RCA", err = 0.0546621884131133, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`t300B` <-
structure(list(G = 0.00071191966, muc = 3.6877954, alpha = 0.42909066, 
    Ego = 0.99996017, Cgp = 1.5e-11, Ci = 8.5e-12, Co = 4.1e-12, 
    Vp = 400, Ik = 0.1, Pp = 36, remark = "WE", err = 0.0547320239351324, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Ik", "Pp", "remark", "err", "code"))
`t31LZ6T` <-
structure(list(G = 0.0058083241, muc = 2.3341748, alpha = 0.66051935, 
    Ego = -0.11976616, Cgp = 6e-13, Ci = 2.2e-11, Co = 1.1e-11, 
    Vp = 990, Vg2 = 220, Pp = 30, Pg2 = 5, Ik = 0.35, remark = "RCA", 
    pentode.chara = c(175, 125, -25, 0.14, 0.002, 7000), err = 0.0258712331554195, 
    code = 0L, g2.r = 0.0015365045, Ea = -1345), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t350BT` <-
structure(list(G = 0.0012190211, muc = 6.1864896, alpha = 0.58406444, 
    Ego = 0.99999998, Cgp = 5e-13, Ci = 1.6e-11, Co = 8e-12, 
    Vp = 360, Pp = 27, Pg2 = 4, Ik = 0.125, remark = "WE", pentode.chara = c(250, 
    250, -14, 0.093, 0.006, 37500), err = 0.0503853950826618, 
    code = 0L, g2.r = 0.053466426, Ea = -4981.25), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"Ik", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t354V` <-
structure(list(G = 0.00098151348, muc = 32.268063, alpha = 0.47265732, 
    Ego = 0.65601816, Cgp = 2e-12, Cgk = 2e-12, Cpk = 2e-12, 
    Vp = 250, remark = "Mullard", err = 0.0143063914881771, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "remark", "err", 
"code"))
`t35C5T` <-
structure(list(G = 0.0024204769, muc = 4.1343593, alpha = 0.67909498, 
    Ego = 0.99999998, Cgp = 6e-13, Ci = 1.2e-11, Co = 9e-12, 
    Vp = 135, Vg2 = 117, Pp = 4.5, Pg2 = 1, remark = "GE", pentode.chara = c(110, 
    110, -7.5, 0.04, 0.003, 19000), err = 0.0158438844764061, 
    code = 0L, g2.r = 0.046837926, Ea = -1030), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t3A167M` <-
structure(list(G = 0.01971674, muc = 42.075214, alpha = 0.52254324, 
    Ego = 0.41219892, Cgp = 4e-12, Cgk = 1.1e-11, Cpk = 2.5e-12, 
    Vp = 350, Pp = 7, Ik = 0.045, remark = "STC", err = 0.0478452886967647, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t3C33` <-
structure(list(G = 0.0031463341, muc = 8.5517252, alpha = 0.59227339, 
    Ego = 1, Cgp = 5e-12, Cgk = 8.5e-12, Cpk = 4e-12, Pp = 15, 
    remark = "RCA", err = 0.0673211462835343, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Pp", "remark", "err", 
"code"))
`t41MXP` <-
structure(list(G = 0.089955716, muc = 3.0105584, alpha = 0.82004503, 
    Ego = 0.99999047, Cgp = 4e-12, Cgk = 4e-12, Cpk = 4e-12, 
    Vp = 200, remark = "Cossor", err = 0.0453008915055164, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "remark", "err", 
"code"))
`t45` <-
structure(list(G = 0.00027269199, muc = 3.1883948, alpha = 0.48740572, 
    Ego = -0.36938318, Cgp = 7e-12, Cgk = 4e-12, Cpk = 3e-12, 
    Vp = 300, Pp = 10, remark = "Amalgamated Wireless Valve", 
    err = 0.0268101921125238, code = 0L), .Names = c("G", "muc", 
"alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", "err", 
"code"))
`t46` <-
structure(list(G = 0.0005601202, muc = 41.214721, alpha = 0.66546593, 
    Ego = -0.6332578, G.lim = 0.0005006316, Ig.ratio = 0.3220339, 
    Cgp = 4e-12, Cgk = 4e-12, Cpk = 4e-12, Vp = 400, Pp = 10, 
    remark = "RCA", ig = c(50, 0.12, 0.057), err = 0.0235141907750221, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", "ig", 
"err", "code"))
`t50` <-
structure(list(G = 0.0001486389, muc = 3.3349055, alpha = 0.45248471, 
    Ego = 1, Cgp = 4e-12, Cgk = 4e-12, Cpk = 4e-12, Vp = 450, 
    Pp = 25, remark = "RCA", err = 0.0317818600156389, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", 
"err", "code"))
`t50HB26T` <-
structure(list(G = 0.0027704924, muc = 4.1168586, alpha = 0.58715047, 
    Ego = 0.99999978, Cgp = 1.1e-12, Ci = 1.73e-11, Co = 7.7e-12, 
    Vp = 350, Vg2 = 300, Pp = 18, Pg2 = 5, Ik = 0.22, remark = "Matsushita", 
    pentode.chara = c(130, 130, -12, 0.123, 0.0085, 10000), err = 0.0164486647483767, 
    code = 0L, g2.r = 0.046435146, Ea = -1715), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t53` <-
structure(list(G = 0.00048212799, muc = 32.465269, alpha = 0.35000002, 
    Ego = 1, G.lim = 0.0005940227, Ig.ratio = 0.28455285, Cgp = 4e-12, 
    Cgk = 4e-12, Cpk = 4e-12, Vp = 300, Pp = 10, Ik = 0.125, 
    remark = "RCA", ig = c(35, 0.088, 0.035), err = 0.0205034252560468, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", 
"ig", "err", "code"))
`t5687` <-
structure(list(G = 0.0028821468, muc = 14.539598, alpha = 0.55174638, 
    Ego = 0.35624804, Cgp = 4e-12, Ci = 4e-12, Co = 6e-13, Vp = 300, 
    Pp = 3.75, remark = "GE", err = 0.0449335846348956, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "remark", 
"err", "code"))
`t5751` <-
structure(list(G = 0.00079762831, muc = 58.807619, alpha = 0.54057571, 
    Ego = 0.5559861, Cgp = 1.4e-12, Ci = 1.4e-12, Co = 4.6e-13, 
    Vp = 300, Pp = 0.8, Ik = 0.006, remark = "Siemens", err = 0.0206084985790133, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t5842` <-
structure(list(G = 0.010632968, muc = 39.533476, alpha = 0.44639227, 
    Ego = -0.46951652, Cgp = 1.8e-12, Cgk = 9e-12, Cpk = 5.5e-13, 
    Vp = 200, Pp = 4.5, Ik = 0.038, remark = "Raytheon", err = 0.0118081694498196, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t5965` <-
structure(list(G = 0.010017704, muc = 24.272617, alpha = 0.72713555, 
    Ego = 0.61035688, Cgp = 3e-12, Ci = 4e-12, Co = 5e-13, Vp = 330, 
    Pp = 2, Ik = 0.0165, remark = "RCA", err = 0.0387946389319023, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t5998` <-
structure(list(G = 0.0094617726, muc = 3.9918111, alpha = 0.69539007, 
    Ego = 1, Cgp = 8.6e-12, Cgk = 6e-12, Cpk = 2.2e-12, Vp = 250, 
    Ik = 0.125, Pp = 13, remark = "GE", err = 0.07380098872533, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Ik", "Pp", "remark", "err", "code"))
`t59Th` <-
structure(list(G = 1.6789061, muc = 10.851403, alpha = 0.86423906, 
    Ego = 0.99979071, G.lim = 0.0005939697, Ig.ratio = 0.35714286, 
    Cgp = 4e-12, Cgk = 4e-12, Cpk = 4e-12, Vp = 400, Pp = 10, 
    remark = "RCA", ig = c(50, 0.135, 0.075), err = 0.053529142191286, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", "ig", 
"err", "code"))
`t5AR4` <-
structure(list(G = 0.0039557740264262), .Names = "G")
`t6072` <-
structure(list(G = 0.00057643098, muc = 38.292098, alpha = 0.48082137, 
    Ego = 0.75743218, Cgp = 1.4e-12, Ci = 1.4e-12, Co = 5e-13, 
    Vp = 300, Pp = 1.5, remark = "GE", err = 0.0236425565596727, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "remark", "err", "code"))
`t6080` <-
structure(list(G = 0.0030745874, muc = 1.3817523, alpha = 0.68136408, 
    Ego = 1, Cgp = 8.6e-12, Cgk = 6e-12, Cpk = 2.2e-12, Vp = 250, 
    Ik = 0.125, Pp = 13, remark = "Philips", err = 0.0561332573967154, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Ik", "Pp", "remark", "err", "code"))
`t6146BT` <-
structure(list(G = 0.0009173158, muc = 3.7146753, alpha = 0.47760774, 
    Ego = 0.99999998, Cgp = 2.2e-13, Ci = 1.3e-11, Co = 8.5e-12, 
    Vp = 600, Vg2 = 250, Pp = 27, Pg2 = 3, Ik = 0.175, remark = "RCA", 
    pentode.chara = c(200, 200, -20, 0.178, 0.01, 12000), err = 0.010564560315849, 
    code = 0L, g2.r = 0.043249582, Ea = -3004), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6197T` <-
structure(list(G = 0.0030656981, muc = 18.202083, alpha = 0.50833848, 
    Ego = 0.45955375, Cgp = 1.25e-13, Cgk = 1.15e-11, Cpk = 5e-12, 
    Vp = 300, Vg2 = 250, Pp = 7.5, Pg2 = 2.5, Ik = 0.05, remark = "RCA", 
    pentode.chara = c(250, 150, -3, 0.03, 0.007, 90000), err = 0.0118582238578388, 
    code = 0L, g2.r = 0.18302682, Ea = -3900), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6240G` <-
structure(list(G = 0.00075405166, muc = 28.097389, alpha = 0.49567012, 
    Ego = 0.72455622, Cgp = 2.6e-12, Cgk = 3.2e-12, Cpk = 1.2e-12, 
    Vp = 600, Pp = 3, Ik = 0.015, remark = "NEC", err = 0.0266113356240519, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6267T` <-
structure(list(G = 0.00078620809, muc = 29.728844, alpha = 0.54703148, 
    Ego = 0.59868749, Cgp = 5e-14, Ci = 3.8e-12, Co = 5.3e-12, 
    Vp = 300, Pp = 1, Pg2 = 0.2, Ik = 0.006, remark = "Philips", 
    pentode.chara = c(250, 140, -2, 0.003, 6e-04, 1700000), err = 0.0539503969019385, 
    code = 0L, g2.r = 0.16033312, Ea = -7510), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"Ik", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t62BTT` <-
structure(list(G = 0.0019598422, muc = 3.8802609, alpha = 0.60876877, 
    Ego = 0.99999993, Cgp = 5e-13, Ci = 2.3e-11, Co = 1.1e-11, 
    Vp = 400, Vg2 = 250, Pp = 25, Pg2 = 5, remark = "Cossor", 
    pentode.chara = c(250, 180, -18.5, 0.1, 0.0045, 15000), err = 0.0153600248103341, 
    code = 0L, g2.r = 0.035789228, Ea = -2070), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6336` <-
structure(list(G = 0.0055967398, muc = 2.0859966, alpha = 0.66834024, 
    Ego = 0.80124916, Cgp = 1.6e-11, Ci = 1.4e-11, Co = 5e-12, 
    Vp = 364, Pp = 27.3, Ik = 0.364, remark = "RCA", err = 0.0595668811255751, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6350` <-
structure(list(G = 0.0014646013, muc = 16.588714, alpha = 0.54022052, 
    Ego = 1, Cgp = 3.2e-12, Cgk = 3.6e-12, Cpk = 6e-13, Vp = 300, 
    Ik = 0.025, Pp = 3.5, remark = "RCA", err = 0.0372192359931822, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Ik", "Pp", "remark", "err", "code"))
`t6414` <-
structure(list(G = 0.01806754, muc = 22.886646, alpha = 0.74480778, 
    Ego = -0.25147459, G.lim = 0.0046485482, Ig.ratio = 0.62585034, 
    Cgp = 3.6e-12, Ci = 5e-12, Co = 5.7e-13, Vp = 200, Pp = 2, 
    remark = "Raytheon", ig = c(10, 0.055, 0.092), err = 0.0268958717266616, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Ci", "Co", "Vp", "Pp", "remark", "ig", "err", 
"code"))
`t6550AT` <-
structure(list(G = 0.0017503674, muc = 5.8346717, alpha = 0.58499636, 
    Ego = 0.1919366, Cgp = 8e-13, Ci = 1.5e-11, Co = 1e-11, Vp = 660, 
    Vg2 = 440, Pp = 42, Pg2 = 6, Ik = 0.19, remark = "GE", pentode.chara = c(250, 
    250, -14, 0.14, 0.012, 15000), err = 0.0247323603024234, 
    code = 0L, g2.r = 0.071947132, Ea = -2900), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6900` <-
structure(list(G = 0.0027693634, muc = 13.731543, alpha = 0.58862136, 
    Ego = 0.77471006, Cgp = 5.2e-12, Cgk = 8e-12, Cpk = 9.8e-13, 
    Vp = 300, Pp = 4.25, remark = "Bendix", err = 0.0376738846133531, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`t6AC5` <-
structure(list(G = 0.00048665592, muc = 54.269243, alpha = 0.65203584, 
    Ego = 0.64401885, G.lim = 0.00053123982, Ig.ratio = 0.29090909, 
    Cgp = 4e-12, Cgk = 4e-12, Cpk = 4e-12, Vp = 250, Pp = 8, 
    remark = "RCA", ig = c(35, 0.078, 0.032), err = 0.0121216696492312, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", "ig", 
"err", "code"))
`t6AF4` <-
structure(list(G = 0.0074643586, muc = 6.5866497, alpha = 0.73137617, 
    Ego = 0.77962386, G.lim = 0.0025619918, Ig.ratio = 0.50234742, 
    Cgp = 1.9e-12, Ci = 2.2e-12, Co = 1.4e-12, Vp = 150, Pp = 2.5, 
    Ik = 0.022, remark = "GE", ig = c(12, 0.053, 0.0535), err = 0.0291704094000146, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Ci", "Co", "Vp", "Pp", "Ik", "remark", "ig", 
"err", "code"))
`t6AH4` <-
structure(list(G = 0.0012880266, muc = 7.0652545, alpha = 0.54967545, 
    Ego = 1, Cgp = 4.4e-12, Ci = 7e-12, Co = 1.7e-12, Vp = 500, 
    Pp = 7.5, Ik = 0.06, remark = "?", err = 0.0239593197546188, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6AK6T` <-
structure(list(G = 0.00043043074, muc = 7.4086847, alpha = 0.56565494, 
    Ego = 1, Cgp = 1.2e-13, Ci = 3.6e-12, Co = 4.2e-12, Vp = 180, 
    Vg2 = 180, Pp = 2.75, Pg2 = 0.75, remark = "RCA", pentode.chara = c(180, 
    180, -9, 0.015, 0.0025, 2e+05), err = 0.0240161846520961, 
    code = 0L, g2.r = 0.13238107, Ea = -4320), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6AN8PT` <-
structure(list(G = 0.0052482203, muc = 18.881801, alpha = 0.64288804, 
    Ego = -1, Cgp = 4e-14, Ci = 7e-12, Co = 2.4e-12, Vp = 330, 
    Vg2 = 330, Pp = 2.3, Pg2 = 0.55, remark = "Sylvania", pentode.chara = c(125, 
    125, -0.885, 0.012, 0.0038, 4e+05), err = 0.0102673796688358, 
    code = 0L, g2.r = 0.22487958, Ea = -7075), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6AN8T` <-
structure(list(G = 0.0015634562, muc = 11.970707, alpha = 0.66169638, 
    Ego = 0.60043597, Cgp = 1.5e-12, Ci = 2e-12, Co = 2.6e-13, 
    Vp = 330, Pp = 2.8, remark = "Sylvania", err = 0.0367633435204076, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "remark", "err", "code"))
`t6AQ8` <-
structure(list(G = 0.0076348, muc = 33.468219, alpha = 0.69919807, 
    Ego = 0.46274, Cgp = 1.5e-12, Cgk = 3.1e-12, Cpk = 1.2e-12, 
    Vp = 300, Pp = 2.25, Ik = 0.015, remark = "Philips", err = 0.0240168750078434, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6AU6T` <-
structure(list(G = 0.0020681021, muc = 27.099343, alpha = 0.58944101, 
    Ego = 0.24107953, Cgp = 3.5e-15, Ci = 5.5e-12, Co = 5e-12, 
    Vp = 330, Pp = 3.5, Pg2 = 0.75, remark = "GE", pentode.chara = c(250, 
    150, -1, 0.0106, 0.0043, 1e+06), err = 0.0108858380581527, 
    code = 0L, g2.r = 0.28318371, Ea = -15750), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t6BL7` <-
structure(list(G = 0.0017970098, muc = 13.121491, alpha = 0.56407007, 
    Ego = 0.46718638, G.lim = 0.0022017358, Ig.ratio = 0.39497307, 
    Cgp = 6e-12, Ci = 4.6e-12, Co = 9e-13, Vp = 500, Pp = 10, 
    Ik = 0.06, remark = "GE", ig = c(40, 0.337, 0.22), err = 0.0419494911500993, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Ci", "Co", "Vp", "Pp", "Ik", "remark", "ig", 
"err", "code"))
`t6BL8PT` <-
structure(list(G = 0.0023332764, muc = 33.940276, alpha = 0.53943491, 
    Ego = 0.57453871, Cgp = 2.5e-14, Ci = 5.2e-12, Co = 3.4e-12, 
    Vp = 250, Vg2 = 200, Pp = 1.7, Pg2 = 0.75, Ik = 0.014, remark = "Philips", 
    pentode.chara = c(170, 170, -2, 0.01, 0.0028, 4e+05), err = 0.046076656022976, 
    code = 0L, g2.r = 0.20838413, Ea = -5830), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6BL8T` <-
structure(list(G = 0.0015151796, muc = 12.48609, alpha = 0.62334567, 
    Ego = 0.9999996, Cgp = 1.5e-12, Ci = 2.5e-12, Co = 1.8e-12, 
    Vp = 250, Pp = 1.5, Ik = 0.014, remark = "Philips", err = 0.0279340827918853, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6BM8PT` <-
structure(list(G = 0.0021448732, muc = 6.7189608, alpha = 0.5940529, 
    Ego = 0.90753334, Cgp = 3e-13, Ci = 9.3e-12, Co = 8e-12, 
    Vp = 300, Ik = 0.05, Pp = 7, Pg2 = 1.8, remark = "RCA", pentode.chara = c(200, 
    200, -16, 0.035, 0.007, 20000), err = 0.0159846755396342, 
    code = 0L, g2.r = 0.1579163, Ea = -850), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Ik", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t6BM8T` <-
structure(list(G = 0.00088337368, muc = 58.371753, alpha = 0.48665526, 
    Ego = 0.43636433, Cgp = 4e-12, Ci = 2.7e-12, Co = 4e-12, 
    Vp = 300, Pp = 1, Ik = 0.015, remark = "Philips", err = 0.0222639639570775, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6BQ5T` <-
structure(list(G = 0.0023829269, muc = 15.676066, alpha = 0.4824288, 
    Ego = 0.03372597, Cgp = 5e-13, Ci = 1.08e-11, Co = 6.5e-12, 
    Vp = 300, Pp = 12, Ik = 0.065, remark = "Philips", pentode.chara = c(250, 
    250, -7.3, 0.048, 0.0055, 38000), err = 0.0269706478296224, 
    code = 0L, g2.r = 0.095984817, Ea = -2486), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Ik", "remark", 
"pentode.chara", "err", "code", "g2.r", "Ea"))
`t6BQ6T` <-
structure(list(G = 0.0018337045, muc = 3.0739639, alpha = 0.64091712, 
    Ego = -0.12830687, Cgp = 6e-13, Ci = 1.5e-11, Co = 7e-12, 
    Vp = 600, Vg2 = 200, Pp = 11, Pg2 = 2.5, Ik = 0.11, remark = "GE", 
    pentode.chara = c(250, 150, -22.5, 0.057, 0.0021, 20000), 
    err = 0.00874329037020987, code = 0L, g2.r = 0.028202798, 
    Ea = -1560), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Vg2", "Pp", "Pg2", "Ik", "remark", "pentode.chara", 
"err", "code", "g2.r", "Ea"))
`t6BQ7A` <-
structure(list(G = 0.003987561, muc = 25.933734, alpha = 0.64598808, 
    Ego = 0.20509979, G.lim = 0.0032887688, Ig.ratio = 0.74038462, 
    Cgp = 1.2e-12, Ci = 2.6e-12, Co = 1.2e-12, Vp = 250, Ik = 0.02, 
    Pp = 2, remark = "GE", ig = c(10, 0.027, 0.077), err = 0.0356324099784051, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Ci", "Co", "Vp", "Ik", "Pp", "remark", "ig", 
"err", "code"))
`t6BR7T` <-
structure(list(G = 0.00048560243, muc = 17.706591, alpha = 0.49811929, 
    Ego = 0.48180983, Cgp = 1e-14, Ci = 4e-12, Co = 4e-12, Vp = 300, 
    Vg2 = 125, Pp = 0.75, Pg2 = 0.3, remark = "Brimar", pentode.chara = c(100, 
    100, -3, 0.002, 7e-04, 1500000), err = 0.0403228011091095, 
    code = 0L, g2.r = 0.23838325, Ea = -4400), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6BX7` <-
structure(list(G = 0.0020437592, muc = 8.253545, alpha = 0.57960229, 
    Ego = 0.99999999, Cgp = 4.2e-12, Ci = 4.8e-12, Co = 1.2e-12, 
    Vp = 500, Pp = 10, Ik = 0.06, remark = "GE", err = 0.0450569079743269, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6C19P` <-
structure(list(G = 0.0048409525, muc = 1.687323, alpha = 0.70209605, 
    Ego = 0.10684511, Cgp = 8e-12, Cgk = 6.5e-12, Cpk = 2.5e-12, 
    Vp = 200, Pp = 11, Ik = 0.14, remark = "?", err = 0.0841222864452673, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6C33CB` <-
structure(list(G = 0.026902304, muc = 1.7800853, alpha = 0.71303064, 
    Ego = 1, Cgp = 3.1e-11, Ci = 3e-11, Co = 1.05e-11, Vp = 450, 
    Pp = 60, Ik = 0.6, remark = "Ulyanov?", err = 0.140237644271016, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6C4` <-
structure(list(G = 0.00086837935, muc = 12.168865, alpha = 0.64223565, 
    Ego = 0.736372, G.lim = 0.0010589303, Ig.ratio = 0.52873563, 
    Cgp = 1.6e-12, Ci = 1.8e-12, Co = 1.3e-12, Vp = 300, Pp = 3.5, 
    Ik = 0.025, ig = c(30, 0.082, 0.092), remark = "Philips", 
    err = 0.0223721598686596, code = 0L), .Names = c("G", "muc", 
"alpha", "Ego", "G.lim", "Ig.ratio", "Cgp", "Ci", "Co", "Vp", 
"Pp", "Ik", "ig", "remark", "err", "code"))
`t6C5` <-
structure(list(G = 0.00054026317, muc = 14.167744, alpha = 0.60242233, 
    Ego = 1, Cgp = 1.8e-12, Cgk = 4e-12, Cpk = 1.3e-11, Vp = 250, 
    remark = "RCA", err = 0.0592292717659266, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "remark", "err", 
"code"))
`t6C8` <-
structure(list(G = 0.00043921307, muc = 35.300556, alpha = 0.3924503, 
    Ego = 0.83697566, Cgp = 2.6e-12, Cgk = 2.6e-12, Cpk = 2.2e-12, 
    Vp = 250, Pp = 1, remark = "RCA", err = 0.0684677380962837, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`t6CA10` <-
structure(list(G = 0.003979238, muc = 7.0532519, alpha = 0.58252895, 
    Ego = 0.85922191, Cgp = 1.6e-11, Cgk = 2.4e-11, Cpk = 1.6e-11, 
    Vp = 450, Pp = 30, Ik = 0.2, remark = "NEC", err = 0.0422093496462171, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6CB5T` <-
structure(list(G = 0.0015860374, muc = 3.1452557, alpha = 0.54139296, 
    Ego = 0.12233722, Cgp = 4e-13, Ci = 2.2e-11, Co = 1e-11, 
    Vp = 800, Vg2 = 200, Pp = 23, Pg2 = 3.6, Ik = 0.22, remark = "Sylvania", 
    pentode.chara = c(175, 175, -26.14, 0.09, 0.006, 10000), 
    err = 0.018195741430091, code = 0L, g2.r = 0.050568194, Ea = -1175), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6CB6T` <-
structure(list(G = 0.010960467, muc = 18.926098, alpha = 0.73009738, 
    Ego = 0.7350712, Cgp = 2e-14, Ci = 6.5e-12, Co = 1.9e-12, 
    Vp = 300, Vg2 = 300, Pp = 2, Pg2 = 0.5, remark = "RCA", pentode.chara = c(200, 
    150, -2.214, 0.0095, 0.0028, 1500000), err = 0.0331600796732024, 
    code = 0L, g2.r = 0.21953218, Ea = -21225), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6CD6T` <-
structure(list(G = 0.0021974746, muc = 3.1092727, alpha = 0.60742171, 
    Ego = -0.11853336, Cgp = 1.1e-12, Ci = 2.2e-11, Co = 8.5e-12, 
    Vp = 700, Vg2 = 175, Pp = 20, Pg2 = 3, Ik = 0.2, remark = "GE", 
    pentode.chara = c(175, 175, -30, 0.075, 0.0055, 23000), err = 0.00824438388349665, 
    code = 0L, g2.r = 0.056465286, Ea = -2412.5), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6CG7` <-
structure(list(G = 0.00074417047, muc = 16.448024, alpha = 0.55806385, 
    Ego = 0.54900933, G.lim = 0.0010650161, Ig.ratio = 0.36, 
    Cgp = 4e-12, Ci = 2.3e-12, Co = 2.2e-12, Vp = 300, Pp = 2.5, 
    Ik = 0.02, remark = "GE", ig = c(30, 0.112, 0.063), err = 0.0490194885870337, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Ci", "Co", "Vp", "Pp", "Ik", "remark", "ig", 
"err", "code"))
`t6CK4` <-
structure(list(G = 0.0021160382, muc = 5.8314073, alpha = 0.5887008, 
    Ego = 1, G.lim = 0.003541751, Ig.ratio = 0.41071429, Cgp = 6.5e-12, 
    Ci = 8e-12, Co = 1.8e-12, Vp = 550, Pp = 12, Ik = 0.1, remark = "GE", 
    ig = c(10, 0.066, 0.046), err = 0.0252267345024651, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "G.lim", "Ig.ratio", "Cgp", "Ci", "Co", 
"Vp", "Pp", "Ik", "remark", "ig", "err", "code"))
`t6CL6T` <-
structure(list(G = 0.0039229723, muc = 16.225658, alpha = 0.58957947, 
    Ego = 0.23313833, Cgp = 1.2e-13, Ci = 1.1e-11, Co = 5.5e-12, 
    Vp = 300, Pp = 7.5, Pg2 = 1.7, remark = "GE", pentode.chara = c(250, 
    150, -3, 0.03, 0.007, 80000), err = 0.034991936397229, code = 0L, 
    g2.r = 0.18302682, Ea = -3450), .Names = c("G", "muc", "alpha", 
"Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", "remark", "pentode.chara", 
"err", "code", "g2.r", "Ea"))
`t6CW5T` <-
structure(list(G = 0.0058898823, muc = 5.4129723, alpha = 0.67326092, 
    Ego = 0.38874904, Cgp = 6e-13, Ci = 1.2e-11, Co = 6e-12, 
    Vp = 250, Ik = 0.1, Pp = 12, Pg2 = 1.75, remark = "GE", pentode.chara = c(170, 
    170, -12.5, 0.07, 0.005, 23000), err = 0.0322285965978434, 
    code = 0L, g2.r = 0.054282908, Ea = -2245), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Ik", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t6DE71` <-
structure(list(G = 0.00054039164, muc = 16.128628, alpha = 0.47247441, 
    Ego = 0.97660212, Cgp = 4e-12, Ci = 2.2e-12, Co = 5.2e-13, 
    Vp = 330, Pp = 1.5, Ik = 0.022, remark = "Sylvania", err = 0.0385368681665222, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6DE72` <-
structure(list(G = 0.0076124257, muc = 4.2142073, alpha = 0.71526173, 
    Ego = 0.99984307, Cgp = 8.5e-12, Ci = 5.5e-12, Co = 1e-12, 
    Vp = 275, Pp = 7, Ik = 0.05, remark = "Sylvania", err = 0.0793005899758875, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6DQ5T` <-
structure(list(G = 0.001983081, muc = 2.8872786, alpha = 0.52179836, 
    Ego = 0.99999998, Cgp = 5e-13, Ci = 2.3e-11, Co = 1.1e-11, 
    Vp = 900, Vg2 = 175, Pp = 24, Pg2 = 3.2, Ik = 0.285, remark = "Sylvania", 
    pentode.chara = c(175, 125, -25, 0.11, 0.005, 7500), err = 0.0118971374405782, 
    code = 0L, g2.r = 0.03130436, Ea = -1112.5), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6DQ6T` <-
structure(list(G = 0.0040197798, muc = 2.9358797, alpha = 0.68196546, 
    Ego = -1, Cgp = 5e-13, Ci = 1.5e-11, Co = 7e-12, Vp = 770, 
    Vg2 = 220, Pp = 18, Pg2 = 3.6, Ik = 0.175, remark = "GE", 
    pentode.chara = c(250, 150, -22.5, 0.065, 0.0018, 25000), 
    err = 0.014605181881871, code = 0L, g2.r = 0.019550649, Ea = -2287.5), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6DT8` <-
structure(list(G = 0.017852785, muc = 27.212026, alpha = 0.7645525, 
    Ego = 0.65426696, Cgp = 1.6e-12, Ci = 2.7e-12, Co = 1.6e-12, 
    Vp = 300, Pp = 2.5, remark = "GE", err = 0.0308876910977974, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "remark", "err", "code"))
`t6EJ7T` <-
structure(list(G = 0.011540933, muc = 53.760436, alpha = 0.52785987, 
    Ego = 0.40321166, Cgp = 5e-15, Ci = 1e-11, Co = 3e-12, Cg1g2 = 2.8e-12, 
    Vp = 250, Pp = 2.5, Pg2 = 0.9, Ik = 0.025, remark = "Philips", 
    pentode.chara = c(200, 200, -2.5, 0.01, 0.0041, 380000), 
    err = 0.0248075691116393, code = 0L, g2.r = 0.28333302, Ea = -5500), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Cg1g2", "Vp", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6EM71` <-
structure(list(G = 0.00074054441, muc = 64.190723, alpha = 0.35, 
    Ego = 0.75136004, Cgp = 4.8e-12, Ci = 2.2e-12, Co = 6e-13, 
    Vp = 330, Pp = 1.5, Ik = 0.022, remark = "RCA", err = 0.0333125099214502, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6EM72` <-
structure(list(G = 0.0043402717, muc = 3.6018096, alpha = 0.68442578, 
    Ego = 1, Cgp = 1e-11, Ci = 7e-12, Co = 1.8e-12, Vp = 330, 
    Pp = 10, Ik = 0.05, remark = "RCA", err = 0.109647349579989, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6EW72` <-
structure(list(G = 0.0084764746, muc = 4.0551143, alpha = 0.70812283, 
    Ego = 1, Cgp = 9e-12, Ci = 7e-12, Co = 1.2e-12, Vp = 330, 
    Pp = 10, Ik = 0.05, remark = "Sylvania", err = 0.061557272214451, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6F5` <-
structure(list(G = 0.00055846113, muc = 89.68007, alpha = 0.4733854, 
    Ego = 0.58201919, Cgp = 2e-12, Cgk = 6e-12, Cpk = 1.2e-11, 
    Vp = 250, remark = "RCA", err = 0.0860099933515835, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "remark", "err", 
"code"))
`t6F6T` <-
structure(list(G = 0.00030710831, muc = 5.8829755, alpha = 0.50441721, 
    Ego = 0.99999999, G.lim = 0.00057316283, Ig.ratio = 0.34482759, 
    Cgp = 7e-13, Ci = 9e-12, Co = 7.5e-12, Vp = 375, Pp = 11, 
    Pg2 = 3.75, remark = "RCA", ig = c(40, 0.095, 0.05), pentode.chara = c(250, 
    250, -16.5, 0.034, 0.0065, 80000), err = 0.0229727164751881, 
    code = 0L, g2.r = 0.15411336, Ea = -3830), .Names = c("G", 
"muc", "alpha", "Ego", "G.lim", "Ig.ratio", "Cgp", "Ci", "Co", 
"Vp", "Pp", "Pg2", "remark", "ig", "pentode.chara", "err", "code", 
"g2.r", "Ea"))
`t6FQ7` <-
structure(list(G = 0.00064328217, muc = 16.632597, alpha = 0.54497428, 
    Ego = 0.78479196, Cgp = 3.8e-12, Ci = 2.4e-12, Co = 3.4e-13, 
    Vp = 300, Pp = 2.6, Ik = 0.02, remark = "RCA?", err = 0.0551941400994865, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6GA4` <-
structure(list(G = 0.0030450256, muc = 8.1683638, alpha = 0.60197612, 
    Ego = 0.99999993, Cgp = 6.5e-12, Ci = 5e-12, Co = 1.2e-12, 
    Vp = 350, Pp = 13, remark = "Toshiba", err = 0.0507076184533383, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "remark", "err", "code"))
`t6GB5T` <-
structure(list(G = 0.0031020384, muc = 4.6206063, alpha = 0.56313336, 
    Ego = 0.84509256, Cgp = 1.75e-12, Ci = 2.3e-11, Co = 1.1e-11, 
    Vp = 250, Vg2 = 250, Pp = 22, Pg2 = 6, Ik = 0.25, remark = "Philips", 
    pentode.chara = c(190, 190, -10, 0.404, 0.02, 8000), err = 0.0372285274558126, 
    code = 0L, g2.r = 0.036396396, Ea = -4658), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6GB8T` <-
structure(list(G = 0.0037584671, muc = 11.901617, alpha = 0.51874132, 
    Ego = 0.18361766, Cgp = 1.8e-12, Ci = 2.4e-11, Co = 1.8e-11, 
    Vp = 800, Ik = 0.2, Pp = 35, Pg2 = 10, remark = "Toshiba", 
    pentode.chara = c(250, 250, -8, 0.14, 0.012, 15000), err = 0.0346245468394967, 
    code = 0L, g2.r = 0.071947132, Ea = -2900), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Ik", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t6GW8PT` <-
structure(list(G = 0.0025686773, muc = 19.311081, alpha = 0.46584391, 
    Ego = 0.84112562, Cgp = 4e-13, Ci = 1e-11, Co = 8e-12, Vp = 300, 
    Ik = 0.055, Pp = 9, Pg2 = 1.8, remark = "Philips", pentode.chara = c(250, 
    250, -7, 0.036, 0.006, 48000), err = 0.0125891816618603, 
    code = 0L, g2.r = 0.13634264, Ea = -2342), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Ik", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t6GY5T` <-
structure(list(G = 0.0037232771, muc = 3.4606724, alpha = 0.63641704, 
    Ego = 0.32801613, Cgp = 4.8e-13, Ci = 2.2e-11, Co = 9e-12, 
    Vp = 770, Vg2 = 220, Pp = 18, Pg2 = 3.5, Ik = 0.23, remark = "GE", 
    pentode.chara = c(130, 130, -20, 0.05, 0.00175, 35000), err = 0.0103353357209198, 
    code = 0L, g2.r = 0.015012935, Ea = -2495), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6J7T` <-
structure(list(G = 0.00053791349, muc = 20.595073, alpha = 0.41226813, 
    Ego = 0.75953915, Cgp = 5e-15, Ci = 7e-12, Co = 1.2e-11, 
    Vp = 250, remark = "RCA", pentode.chara = c(100, 100, -3, 
    0.002, 5e-04, 2500000), err = 0.0239343885108729, code = 0L, 
    g2.r = 0.17745391, Ea = -7400), .Names = c("G", "muc", "alpha", 
"Ego", "Cgp", "Ci", "Co", "Vp", "remark", "pentode.chara", "err", 
"code", "g2.r", "Ea"))
`t6JB5T` <-
structure(list(G = 0.0106492, muc = 4.0005552, alpha = 0.76350205, 
    Ego = 1, Cgp = 4.9e-13, Ci = 9.5e-12, Co = 6.5e-12, Vp = 350, 
    Vg2 = 300, Pp = 15, Pg2 = 2.75, Ik = 0.075, remark = "GE", 
    pentode.chara = c(250, 250, -20, 0.043, 0.0035, 60000), err = 0.0135689457055402, 
    code = 0L, g2.r = 0.068240623, Ea = -3620), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6JE6T` <-
structure(list(G = 0.0023385402, muc = 2.4633995, alpha = 0.58840561, 
    Ego = 1, Cgp = 5.6e-13, Ci = 2.2e-11, Co = 1.1e-11, Vp = 990, 
    Vg2 = 220, Pp = 30, Pg2 = 5, Ik = 0.35, remark = "GE", pentode.chara = c(175, 
    125, -25, 0.13, 0.0028, 5500), err = 0.0384641979171919, 
    code = 0L, g2.r = 0.0086254234, Ea = -947.5), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6JG6AT` <-
structure(list(G = 0.014050654, muc = 2.8537634, alpha = 0.72227126, 
    Ego = 0.99372841, Cgp = 7e-13, Ci = 2.2e-11, Co = 9e-12, 
    Vp = 350, Pp = 17, Pg2 = 3.5, Ik = 0.275, remark = "RCA", 
    pentode.chara = c(130, 125, -20, 0.08, 0.0025, 12000), err = 0.01908890099592, 
    code = 0L, g2.r = 0.011431164, Ea = -1315), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"Ik", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t6JR6T` <-
structure(list(G = 0.0074085952, muc = 3.7869273, alpha = 0.66970037, 
    Ego = 0.99994363, Cgp = 7e-13, Ci = 2.2e-11, Co = 9e-12, 
    Vp = 770, Vg2 = 220, Pp = 17, Pg2 = 3.5, Ik = 0.275, remark = "GE", 
    pentode.chara = c(130, 125, -20, 0.045, 0.0015, 30000), err = 0.0369230054292217, 
    code = 0L, g2.r = 0.013424246, Ea = -1900), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6JS6T` <-
structure(list(G = 0.0031522524, muc = 2.1823209, alpha = 0.65214489, 
    Ego = 0.9999936, Cgp = 7e-13, Ci = 2.4e-11, Co = 1e-11, Vp = 990, 
    Vg2 = 220, Pp = 30, Pg2 = 5.5, Ik = 0.35, remark = "GE", 
    pentode.chara = c(175, 125, -25, 0.13, 0.0028, 8000), err = 0.0299247826813265, 
    code = 0L, g2.r = 0.0086254234, Ea = -1435), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6K6T` <-
structure(list(G = 0.00030960116, muc = 5.3716382, alpha = 0.53133014, 
    Ego = 0.99999995, G.lim = 0.00055339859, Ig.ratio = 0.41428571, 
    Cgp = 5e-13, Ci = 5.5e-12, Co = 6e-12, Vp = 315, Pp = 8.5, 
    Vg2 = 285, Pg2 = 2.8, remark = "RCA", ig = c(40, 0.082, 0.058
    ), pentode.chara = c(250, 250, -18, 0.032, 0.0055, 90000), 
    err = 0.0375548148570356, code = 0L, g2.r = 0.14018111, Ea = -4070), .Names = c("G", 
"muc", "alpha", "Ego", "G.lim", "Ig.ratio", "Cgp", "Ci", "Co", 
"Vp", "Pp", "Vg2", "Pg2", "remark", "ig", "pentode.chara", "err", 
"code", "g2.r", "Ea"))
`t6K7T` <-
structure(list(G = 2.5180035e+51, muc = 0.40553339, alpha = 0.97512105, 
    Ego = -1, Cgp = 5e-15, Ci = 7e-12, Co = 1.2e-11, Vp = 300, 
    Vg2 = 125, Pp = 2.75, Pg2 = 0.35, remark = "GE", pentode.chara = c(100, 
    100, -1, 0.0095, 0.0027, 4e+05), err = 0.0951329576511938, 
    code = 1L, g2.r = 0.199366, Ea = -5600), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6KD6T` <-
structure(list(G = 0.0051832527, muc = 2.905521, alpha = 0.60599778, 
    Ego = 1, Cgp = 8e-13, Ci = 4e-11, Co = 1.6e-11, Vp = 450, 
    Pp = 33, Pg2 = 5, Ik = 0.4, remark = "GE", pentode.chara = c(150, 
    110, -22.5, 0.1, 0.002, 8000), err = 0.0229798364750274, 
    code = 0L, g2.r = 0.0040460629, Ea = -1090), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"Ik", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t6KM6T` <-
structure(list(G = 4.7534114, muc = 1.4863713, alpha = 0.85197107, 
    Ego = 0.57761874, Cgp = 1.2e-12, Ci = 2.2e-11, Co = 9e-12, 
    Vp = 770, Vg2 = 220, Pp = 20, Pg2 = 3.5, Ik = 0.275, remark = "RCA", 
    pentode.chara = c(140, 140, -24.5, 0.08, 0.0024, 10000), 
    err = 0.0341679570137456, code = 0L, g2.r = 0.012121607, 
    Ea = -1060), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Vg2", "Pp", "Pg2", "Ik", "remark", "pentode.chara", 
"err", "code", "g2.r", "Ea"))
`t6KV6T` <-
structure(list(G = 0.0050986757, muc = 2.9675026, alpha = 0.66763573, 
    Ego = 0.5805065, g2.r = 0.015910743, Ea = -1212.6074, Cgp = 6e-13, 
    Ci = 2.2e-11, Co = 9e-12, Vp = 450, Vg2 = 220, Pp = 28, Pg2 = 2, 
    Ik = 0.275, remark = "GE", pentode.chara = c(150, 110, -22.5, 
    0.1, 0.002, 8000), err = 0.0622856519401194, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "g2.r", "Ea", "Cgp", "Ci", "Co", "Vp", 
"Vg2", "Pp", "Pg2", "Ik", "remark", "pentode.chara", "err", "code"
))
`t6L6T` <-
structure(list(G = 0.0021948901, muc = 4.9999386, alpha = 0.6916982, 
    Ego = 0.91804059, G.lim = 0.0027828043, Ig.ratio = 0.79545455, 
    Cgp = 6e-13, Ci = 1e-11, Co = 6.5e-12, Vp = 450, Pp = 30, 
    Pg2 = 5, remark = "GE", pentode.chara = c(250, 250, -14, 
    0.072, 0.005, 22500), ig = c(10, 0.018, 0.07), err = 0.0396826638188084, 
    code = 0L, g2.r = 0.057828332, Ea = -2180), .Names = c("G", 
"muc", "alpha", "Ego", "G.lim", "Ig.ratio", "Cgp", "Ci", "Co", 
"Vp", "Pp", "Pg2", "remark", "pentode.chara", "ig", "err", "code", 
"g2.r", "Ea"))
`t6LB6T` <-
structure(list(G = 0.0088470322, muc = 2.3020886, alpha = 0.70144838, 
    Ego = 0.99700414, Cgp = 4.4e-13, Ci = 3.3e-11, Co = 1.8e-11, 
    Vp = 990, Vg2 = 200, Pp = 30, Pg2 = 5, Ik = 0.315, remark = "GE", 
    pentode.chara = c(150, 110, -20, 0.105, 0.002, 10000), err = 0.0155890061995859, 
    code = 0L, g2.r = 0.0031152648, Ea = -1465), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6LF6T` <-
structure(list(G = 0.05015216, muc = 1.987306, alpha = 0.76574439, 
    Ego = 0.95447628, Cgp = 2.5e-12, Ci = 3.7e-11, Co = 1.85e-11, 
    Vp = 495, Vg2 = 275, Pp = 40, Pg2 = 9, Ik = 0.5, remark = "GE", 
    pentode.chara = c(200, 190, -20, 0.7, 0.021, 2000), err = 0.0181705399115684, 
    code = 0L, g2.r = 0.01893161, Ea = -1910), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6LG6T` <-
structure(list(G = 0.003591442, muc = 3.3000807, alpha = 0.59223909, 
    Ego = 1, Cgp = 8e-13, Ci = 2.5e-11, Co = 1.3e-11, Vp = 900, 
    Vg2 = 200, Pp = 28, Pg2 = 5, Ik = 0.315, remark = "GE", pentode.chara = c(175, 
    125, -23, 0.09, 0.0017, 11000), err = 0.0182439185419603, 
    code = 0L, g2.r = 0.0060474005, Ea = -1360), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t6RA2` <-
structure(list(G = 0.0015501289, muc = 2.4822192, alpha = 0.59828852, 
    Ego = 0.99999998, Cgp = 5.2e-12, Cgk = 6.9e-12, Cpk = 5.4e-12, 
    Vp = 200, Ik = 0.12, Pp = 15, remark = "NEC", err = 0.0902780537314373, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Ik", "Pp", "remark", "err", "code"))
`t6RA3` <-
structure(list(G = 0.0025729671, muc = 2.4207966, alpha = 0.609045, 
    Ego = 0.99999995, Cgp = 5.2e-12, Cgk = 6.9e-12, Cpk = 5.4e-12, 
    Vp = 250, Ik = 0.125, Pp = 15, remark = "NEC", err = 0.11824994761151, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Ik", "Pp", "remark", "err", "code"))
`t6RA6` <-
structure(list(G = 0.0032180177, muc = 13.082645, alpha = 0.53207438, 
    Ego = -0.45045978, Cgp = 6.5e-12, Ci = 5e-12, Co = 1.2e-12, 
    Vp = 550, Pp = 10, remark = "Toshiba", err = 0.0531363852566635, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "remark", "err", "code"))
`t6RA8` <-
structure(list(G = 0.0039315365, muc = 8.4076149, alpha = 0.58057101, 
    Ego = 1, Cgp = 5.2e-12, Cgk = 6.9e-12, Cpk = 5.4e-12, Vp = 300, 
    Ik = 0.12, Pp = 14, remark = "NEC", err = 0.0313308701041693, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Ik", "Pp", "remark", "err", "code"))
`t6RB11T` <-
structure(list(G = 0.0092134348, muc = 5.4468766, alpha = 0.73641288, 
    Ego = 0.65537204, Cgp = 7e-13, Ci = 1e-11, Co = 7e-12, Vp = 315, 
    Vg2 = 285, Pp = 10, Pg2 = 2, remark = "Toshiba", pentode.chara = c(200, 
    200, -12.5, 0.045, 0.0025, 40000), err = 0.0212742918689431, 
    code = 0L, g2.r = 0.042683792, Ea = -2500), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6RP15T` <-
structure(list(G = 0.0019718712, muc = 14.040541, alpha = 0.46659386, 
    Ego = 0.81734398, Cgp = 5e-13, Ci = 1.08e-11, Co = 6.5e-12, 
    Vp = 315, Vg2 = 285, Pp = 10, Pg2 = 2, remark = "Toshiba", 
    pentode.chara = c(250, 250, -8, 0.054, 0.0068, 20000), err = 0.0324210819153131, 
    code = 0L, g2.r = 0.10509188, Ea = -1370), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6S4A` <-
structure(list(G = 0.0011797852, muc = 11.839319, alpha = 0.60392442, 
    Ego = 0.32778768, Cgp = 2.4e-12, Ci = 4.2e-12, Co = 6e-13, 
    Vp = 550, Pp = 8.5, Ik = 0.03, remark = "GE", err = 0.0229703999953134, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t6SC7` <-
structure(list(G = 0.00044535539, muc = 57.273385, alpha = 0.49716318, 
    Ego = 0.44106944, Cgp = 2e-12, Ci = 2e-12, Co = 3e-12, Vp = 250, 
    remark = "GE", err = 0.0425115951952568, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "remark", "err", 
"code"))
`t6SH7T` <-
structure(list(G = 0.0016073552, muc = 33.758141, alpha = 0.45480357, 
    Ego = 0.69566782, Cgp = 3e-15, Ci = 8.5e-12, Co = 7e-12, 
    Vp = 300, Vg2 = 150, Pp = 3, Pg2 = 0.7, remark = "RCA", pentode.chara = c(100, 
    100, -1, 0.0053, 0.0021, 7e+05), err = 0.051897793407438, 
    code = 0L, g2.r = 0.26359894, Ea = -5465), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6SJ7T` <-
structure(list(G = 0.00071703729, muc = 14.609049, alpha = 0.57317428, 
    Ego = 0.40161932, G.lim = 0.0011226828, Ig.ratio = 0.60606061, 
    Cgp = 5e-15, Ci = 6e-12, Co = 7e-12, Vp = 300, Pp = 2.5, 
    Pg2 = 0.7, Ik = 0.02, remark = "Sylvania", pentode.chara = c(100, 
    100, -3, 0.0029, 9e-04, 3e+06), ig = c(6, 0.0065, 0.01), 
    err = 0.0267287074464205, code = 0L, g2.r = 0.21533432, Ea = -12950), .Names = c("G", 
"muc", "alpha", "Ego", "G.lim", "Ig.ratio", "Cgp", "Ci", "Co", 
"Vp", "Pp", "Pg2", "Ik", "remark", "pentode.chara", "ig", "err", 
"code", "g2.r", "Ea"))
`t6SL7` <-
structure(list(G = 0.00061341966, muc = 65.496168, alpha = 0.3742804, 
    Ego = 0.34892993, Cgp = 2.8e-12, Ci = 3.4e-12, Co = 3.8e-12, 
    Vp = 300, Pp = 1, remark = "RCA", err = 0.0401690727986337, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "remark", "err", "code"))
`t6SN7` <-
structure(list(G = 0.00074417047, muc = 16.448024, alpha = 0.55806385, 
    Ego = 0.54900933, G.lim = 0.0010650161, Ig.ratio = 0.36, 
    Cgp = 4e-12, Ci = 3e-12, Co = 1.2e-12, Vp = 300, Pp = 3.5, 
    Ik = 0.02, remark = "Sylvania", ig = c(30, 0.112, 0.063), 
    err = 0.0490194885870337, code = 0L), .Names = c("G", "muc", 
"alpha", "Ego", "G.lim", "Ig.ratio", "Cgp", "Ci", "Co", "Vp", 
"Pp", "Ik", "remark", "ig", "err", "code"))
`t6SQ7` <-
structure(list(G = 0.00049502244, muc = 87.749749, alpha = 0.41735071, 
    Ego = 0.73774817, Cgp = 1.7e-12, Cgk = 1.7e-12, Cpk = 3.8e-12, 
    Vp = 300, Pp = 0.5, remark = "GE", err = 0.0439717886543505, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`t6U8PT` <-
structure(list(G = 0.018698107, muc = 14.091647, alpha = 0.76554283, 
    Ego = 0.65071871, Cgp = 7e-15, Ci = 5e-12, Co = 3.5e-12, 
    Vp = 330, Vg2 = 330, Pp = 3, Pg2 = 0.55, remark = "GE", pentode.chara = c(125, 
    110, -1, 0.0095, 0.0035, 450000), err = 0.00687894921530817, 
    code = 0L, g2.r = 0.25419504, Ea = -6302.5), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`t6U8T` <-
structure(list(G = 0.013182953, muc = 17.94587, alpha = 0.75424518, 
    Ego = 0.99995916, Cgp = 1.8e-12, Ci = 2.8e-12, Co = 2e-12, 
    Vp = 330, Pp = 2.5, remark = "GE", err = 0.0354108219889025, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "remark", "err", "code"))
`t6V6T` <-
structure(list(G = 0.00060166202, muc = 7.0192317, alpha = 0.55951773, 
    Ego = 0.99999998, G.lim = 0.0011292143, Ig.ratio = 0.45544554, 
    Cgp = 7e-13, Ci = 9e-12, Co = 7.5e-12, Vp = 315, Pp = 12, 
    Pg2 = 2, Ik = 0.035, remark = "RCA", pentode.chara = c(250, 
    250, -12.5, 0.045, 0.0045, 50000), ig = c(20, 0.055, 0.046
    ), err = 0.0289421129381627, code = 0L, g2.r = 0.083999767, 
    Ea = -3125), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", "Ik", "remark", 
"pentode.chara", "ig", "err", "code", "g2.r", "Ea"))
`t6W6T` <-
structure(list(G = 0.001349448, muc = 6.062537, alpha = 0.46445072, 
    Ego = 0.99999997, G.lim = 0.0024787093, Ig.ratio = 0.51388889, 
    Cgp = 8e-13, Ci = 1.5e-11, Co = 9e-12, Vp = 300, Pp = 10, 
    Vg2 = 150, Pg2 = 1.25, Ik = 0.06, remark = "GE", pentode.chara = c(110, 
    110, -7.5, 0.049, 0.004, 22000), ig = c(15, 0.07, 0.074), 
    err = 0.0542668623765958, code = 0L, g2.r = 0.052682788, 
    Ea = -1507), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Ci", "Co", "Vp", "Pp", "Vg2", "Pg2", "Ik", 
"remark", "pentode.chara", "ig", "err", "code", "g2.r", "Ea"))
`t71A` <-
structure(list(G = 0.00021307994, muc = 2.8256337, alpha = 0.44301601, 
    Ego = -0.99999999, Cgp = 7.5e-12, Cgk = 3.2e-12, Cpk = 2.9e-12, 
    Vp = 180, Pp = 3.6, remark = "RCA", err = 0.0449261308928081, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`t75` <-
structure(list(G = 0.00046981663, muc = 91.742588, alpha = 0.43109462, 
    Ego = 0.62861222, Cgp = 1.7e-12, Cgk = 1.7e-12, Cpk = 3.8e-12, 
    Vp = 250, remark = "RCA", err = 0.0583738294321695, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "remark", "err", 
"code"))
`t7591T` <-
structure(list(G = 0.0020351267, muc = 15.268483, alpha = 0.47273055, 
    Ego = 0.99926889, Cgp = 2.5e-13, Ci = 1e-11, Co = 5e-12, 
    Vp = 550, Vg2 = 440, Pp = 19, Pg2 = 3.3, Ik = 0.085, remark = "Sylvania", 
    pentode.chara = c(300, 300, -10, 0.06, 0.008, 35000), err = 0.00773131734896511, 
    code = 0L, g2.r = 0.11250516, Ea = -2850), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`t76` <-
structure(list(G = 0.00043487165, muc = 12.724092, alpha = 0.5130732, 
    Ego = 0.99999999, Cgp = 2.8e-12, Cgk = 3.5e-12, Cpk = 2.5e-12, 
    Vp = 250, Pp = 1.4, remark = "RCA", err = 0.0281552177811802, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`t77T` <-
structure(list(G = 0.00043219909, muc = 14.823231, alpha = 0.35, 
    Ego = -1, Cgp = 7e-15, Ci = 4.7e-12, Co = 1.1e-11, Vp = 250, 
    Vg2 = 100, remark = "RCA", pentode.chara = c(250, 100, -3, 
    0.0023, 5e-04, 1500000), err = 0.0523104884907316, code = 0L, 
    g2.r = 0.17232836, Ea = -5075), .Names = c("G", "muc", "alpha", 
"Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "remark", "pentode.chara", 
"err", "code", "g2.r", "Ea"))
`t801` <-
structure(list(G = 0.00020395304, muc = 8.027152, alpha = 0.36013066, 
    Ego = 0.99999971, G.lim = 0.000273, Ig.ratio = 0.17582418, 
    Cgp = 6e-12, Cgk = 4.5e-12, Cpk = 1.5e-12, Vp = 600, Pp = 20, 
    remark = "RCA", ig = c(100, 0.225, 0.048), err = 0.0204245725314211, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", "ig", 
"err", "code"))
`t8045G` <-
structure(list(G = 0.0099093555, muc = 3.3951672, alpha = 0.70125512, 
    Ego = 1, Cgp = 1.6e-11, Cgk = 2.4e-11, Cpk = 1.6e-11, Vp = 550, 
    Pp = 45, Ik = 0.3, remark = "NEC", err = 0.090844878069905, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`t829BT` <-
structure(list(G = 0.0013870937, muc = 7.3992794, alpha = 0.4865848, 
    Ego = -0.31275554, G.lim = 0.0030075114, Ig.ratio = 0.46096654, 
    Cgp = 1.2e-13, Ci = 1.45e-11, Co = 7e-12, Vp = 750, Vg2 = 225, 
    Pp = 30, Pg2 = 7, remark = "RCA", pentode.chara = c(600, 
    200, -18, 0.02, 0.003, 1e+05), ig = c(20, 0.145, 0.124), 
    err = 0.00428761932972068, code = 0L, g2.r = 0.12860576, 
    Ea = -2800), .Names = c("G", "muc", "alpha", "Ego", "G.lim", 
"Ig.ratio", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", "Pg2", "remark", 
"pentode.chara", "ig", "err", "code", "g2.r", "Ea"))
`t8417T` <-
structure(list(G = 0.0077318666, muc = 12.206043, alpha = 0.63317036, 
    Ego = 0.63054378, Cgp = 9e-13, Ci = 2.2e-11, Co = 9e-12, 
    Vp = 660, Pp = 35, Pg2 = 5, remark = "GE?", pentode.chara = c(300, 
    300, -12, 0.1, 0.0055, 16000), err = 0.0381198700972497, 
    code = 0L, g2.r = 0.046609022, Ea = -2100), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`t845` <-
structure(list(G = 0.00054613816, muc = 4.4359607, alpha = 0.62219826, 
    Ego = 1, Cgp = 1.35e-11, Cgk = 6e-12, Cpk = 6.5e-12, Vp = 1250, 
    Pp = 75, remark = "Amperex", err = 0.125556472632364, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", 
"err", "code"))
`t9002` <-
structure(list(G = 0.00057163937, muc = 20.255608, alpha = 0.52686676, 
    Ego = 0.90658712, Cgp = 1.4e-12, Cgk = 1.2e-12, Cpk = 1.1e-12, 
    Vp = 250, Pp = 1.6, remark = "RCA", err = 0.0537298125024556, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`tAD1` <-
structure(list(G = 0.00077502632, muc = 4.0019946, alpha = 0.42297713, 
    Ego = 0.99548209, Cgp = 2.3e-11, Cgk = 7.5e-12, Cpk = 5.5e-12, 
    Vp = 300, Pp = 15, remark = "Philips", err = 0.0723257590646026, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`tDA30` <-
structure(list(G = 0.00052412019, muc = 2.9947681, alpha = 0.48813691, 
    Ego = 1, Cgp = 1.3e-11, Cgk = 1e-11, Cpk = 6.5e-12, Vp = 500, 
    Pp = 35, remark = "Osram", err = 0.0731454740216629, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", 
"err", "code"))
`tE180CC` <-
structure(list(G = 0.0053104514, muc = 28.021736, alpha = 0.67928725, 
    Ego = 0.56698133, Cgp = 2.3e-12, Cgk = 3.5e-12, Cpk = 5e-13, 
    Vp = 250, Pp = 1.82, Ik = 18.2, remark = "Philips", err = 0.0375218149130622, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`tE182CC` <-
structure(list(G = 0.0041807778, muc = 17.776569, alpha = 0.5714995, 
    Ego = 0.56912497, Cgp = 4.1e-12, Cgk = 6e-12, Cpk = 1.1e-12, 
    Vp = 273, Ik = 0.0545, Pp = 3.63, remark = "Philips", err = 0.0361816625879134, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Ik", "Pp", "remark", "err", "code"))
`tE83FT` <-
structure(list(G = 0.0042425066, muc = 28.718446, alpha = 0.57150973, 
    Ego = 0.67775811, Cgp = 1.5e-14, Ci = 8e-12, Co = 3.5e-12, 
    Vp = 210, Vg2 = 210, Pp = 2.1, Pg2 = 0.35, remark = "Philips", 
    pentode.chara = c(150, 150, 0, 0.045, 0.0108, 150000), err = 0.0160064062953096, 
    code = 0L, g2.r = 0.18074757, Ea = -9975), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"
))
`tEC86` <-
structure(list(G = 0.0059140675, muc = 62.680543, alpha = 0.44244958, 
    Ego = 0.22760069, Cgp = 2.2e-12, Cgk = 3.5e-12, Cpk = 2.4e-13, 
    Vp = 220, Pp = 2.2, Ik = 0.02, remark = "Philips", err = 0.0476642739728505, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`tECC33` <-
structure(list(G = 0.00070978374, muc = 28.564106, alpha = 0.42033465, 
    Ego = 0.39854224, Cgp = 2.5e-12, Cgk = 3.5e-12, Cpk = 1.5e-12, 
    Vp = 300, Pp = 2.5, Ik = 0.02, remark = "Mullard", err = 0.139963442493658, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`tECC35` <-
structure(list(G = 0.00072725712, muc = 56.164356, alpha = 0.52130568, 
    Ego = 0.62544373, Cgp = 3e-12, Ci = 3e-12, Co = 1.3e-12, 
    Vp = 300, Pp = 1.5, Ik = 0.008, remark = "Mullard", err = 0.031733377146988, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`tECC84` <-
structure(list(G = 0.0021056179, muc = 15.38524, alpha = 0.62801306, 
    Ego = 0.84230976, Cgp = 2.3e-12, Cgk = 4.7e-12, Cpk = 4.5e-13, 
    Vp = 180, Pp = 2, Ik = 0.022, remark = "Philips", err = 0.0383417010079318, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`tECC86` <-
structure(list(G = 0.004712875, muc = 8.9483573, alpha = 0.67568123, 
    Ego = 0.38539466, Cgp = 1.3e-12, Ci = 3e-12, Co = 1.8e-12, 
    Vp = 30, Pp = 0.6, Ik = 0.02, remark = "Philips", err = 0.0471510447227189, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`tECC88` <-
structure(list(G = 0.0041180199, muc = 26.621288, alpha = 0.49915155, 
    Ego = 0.34001426, Cgp = 1.4e-12, Cgk = 3.3e-12, Cpk = 1.8e-12, 
    Vp = 130, Ik = 0.025, Pp = 1.8, remark = "Philips", err = 0.0354032137511224, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Ik", "Pp", "remark", "err", "code"))
`tEF39T` <-
structure(list(G = 4892774400, muc = 2.0652635, alpha = 0.93204211, 
    Ego = 0.0036430998, g2.r = 0.20040024, Ea = -14558.316, Cgp = 8e-13, 
    Ci = 4e-11, Co = 1.6e-11, Vp = 450, Pp = 33, Pg2 = 5, Ik = 0.4, 
    remark = "GE", pentode.chara = c(150, 110, -22.5, 0.1, 0.002, 
    8000), err = 0.127108993216948, code = 1L), .Names = c("G", 
"muc", "alpha", "Ego", "g2.r", "Ea", "Cgp", "Ci", "Co", "Vp", 
"Pp", "Pg2", "Ik", "remark", "pentode.chara", "err", "code"))
`tEL12T` <-
structure(list(G = 0.0025921537, muc = 15.499816, alpha = 0.48322939, 
    Ego = 0.99999993, Cgp = 6e-13, Ci = 1e-11, Co = 6.5e-12, 
    Vp = 350, Vg2 = 350, Pp = 18, Pg2 = 2.5, Ik = 0.09, remark = "Telefunken", 
    pentode.chara = c(250, 250, -7, 0.072, 0.008, 30000), err = 0.0149316052171514, 
    code = 0L, g2.r = 0.093159769, Ea = -2990), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`tEL156T` <-
structure(list(G = 0.0023436481, muc = 11.787288, alpha = 0.42565201, 
    Ego = 1, Cgp = 5e-13, Ci = 1.9e-11, Co = 7.5e-12, Vp = 800, 
    Vg2 = 450, Pp = 50, Pg2 = 8, Ik = 0.18, remark = "Telefunken", 
    pentode.chara = c(440, 350, -17.4, 0.1, 0.016, 25000), err = 0.0623375362532287, 
    code = 0L, g2.r = 0.13506577, Ea = -3400), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`tEL32T` <-
structure(list(G = 0.0020582453, muc = 4.5730334, alpha = 0.71354541, 
    Ego = 0.99999999, Cgp = 4e-12, Cgk = 4e-12, Cpk = 4e-12, 
    Vp = 250, Pp = 8, remark = "Mullard", pentode.chara = c(250, 
    250, -18, 0.032, 0.005, 70000), err = 0.0493295046401912, 
    code = 0L, g2.r = 0.12856194, Ea = -3110), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", 
"pentode.chara", "err", "code", "g2.r", "Ea"))
`tEL34T` <-
structure(list(G = 0.0019762451, muc = 8.2063559, alpha = 0.55218812, 
    Ego = 0.29360503, Cgp = 1.1e-12, Cgk = 1.52e-11, Cpk = 8.4e-12, 
    Vp = 500, Pp = 25, remark = "Mullard", pentode.chara = c(250, 
    250, -13.5, 0.1, 0.015, 10000), err = 0.0328690958975381, 
    code = 0L, g2.r = 0.12382586, Ea = -1250), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "remark", 
"pentode.chara", "err", "code", "g2.r", "Ea"))
`tEL95T` <-
structure(list(G = 0.0011570767, muc = 14.936032, alpha = 0.45892005, 
    Ego = 1, Cgp = 4e-13, Cgk = 5.3e-12, Cpk = 3.5e-12, Vp = 300, 
    Pp = 6, Pg2 = 1.25, Ik = 0.035, remark = "Philips", pentode.chara = c(250, 
    250, -9, 0.024, 0.0045, 80000), err = 0.0108131239577773, 
    code = 0L, g2.r = 0.15149452, Ea = -2630), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "Pp", "Pg2", 
"Ik", "remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`tKT33CT` <-
structure(list(G = 0.0020623072, muc = 6.8099498, alpha = 0.58344155, 
    Ego = 0.96267547, Cgp = 1.2e-12, Ci = 1.9e-11, Co = 1.2e-11, 
    Vp = 200, Vg2 = 200, Pp = 13, remark = "Marconi", pentode.chara = c(200, 
    200, -13.3, 0.06, 0.01, 15000), err = 0.0262859567122001, 
    code = 0L, g2.r = 0.13385676, Ea = -1150), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`tKT66T` <-
structure(list(G = 0.0010893248, muc = 6.5187433, alpha = 0.55882954, 
    Ego = 1, Cgp = 1.1e-12, Ci = 1.45e-11, Co = 1e-11, Vp = 500, 
    Pp = 25, Pg2 = 3.5, remark = "GEC", pentode.chara = c(250, 
    250, -15, 0.085, 0.0063, 20000), err = 0.0793389554898935, 
    code = 0L, g2.r = 0.061927472, Ea = -2300), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`tKT88T` <-
structure(list(G = 0.0029317575, muc = 5.0214944, alpha = 0.65984733, 
    Ego = 0.99999999, Cgp = 1.2e-12, Ci = 1.6e-11, Co = 1.2e-11, 
    Vp = 600, Ik = 0.175, Pp = 40, Pg2 = 6, remark = "British Industries", 
    pentode.chara = c(250, 250, -14.3, 0.14, 0.02, 10000), err = 0.0350384334873372, 
    code = 0L, g2.r = 0.11834978, Ea = -1850), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Ik", "Pp", "Pg2", 
"remark", "pentode.chara", "err", "code", "g2.r", "Ea"))
`tMH4` <-
structure(list(G = 0.010236064, muc = 37.243201, alpha = 0.47991381, 
    Ego = 0.58255619, Cgp = 5.7e-12, Ci = 7e-12, Co = 6.5e-12, 
    Vp = 200, remark = "Marconi", err = 0.034188919924736, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "remark", "err", 
"code"))
`tMH40` <-
structure(list(G = 0.00077021291, muc = 32.045617, alpha = 0.58589075, 
    Ego = 0.39906513, Cgp = 7.3e-12, Ci = 6e-12, Co = 4e-12, 
    Vp = 200, remark = "Marconi", err = 0.0378736003995823, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "remark", "err", 
"code"))
`tMH41` <-
structure(list(G = 0.0095426065, muc = 36.690206, alpha = 0.74289018, 
    Ego = 0.69037329, Cgp = 3.2e-12, Ci = 8.5e-12, Co = 4.1e-12, 
    Vp = 200, remark = "Marconi", err = 0.055500758882636, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "remark", "err", 
"code"))
`tMHL4` <-
structure(list(G = 0.00045482006, muc = 15.49754, alpha = 0.51598916, 
    Ego = 0.4016137, Cgp = 3.9e-12, Ci = 5.4e-12, Co = 4.5e-12, 
    Vp = 200, Pp = 4, remark = "Marconi", err = 0.0430190597670207, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "remark", "err", "code"))
`tML4` <-
structure(list(G = 0.0032670893, muc = 6.0239958, alpha = 0.73458788, 
    Ego = 1, Cgp = 4e-12, Ci = 4e-12, Co = 4e-12, Vp = 200, Pp = 5, 
    remark = "Marconi", err = 0.0685009267467383, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Pp", "remark", 
"err", "code"))
`tPX25` <-
structure(list(G = 0.0011671444, muc = 7.5306353, alpha = 0.54878562, 
    Ego = -1, Cgp = 1.48e-11, Cgk = 1.14e-11, Cpk = 8.3e-12, 
    Vp = 500, Pp = 30, Ik = 0.0625, remark = "Osram", err = 0.0634565110574157, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`tPX25A` <-
structure(list(G = 0.00076697829, muc = 2.944701, alpha = 0.53473436, 
    Ego = -0.75925792, Cgp = 1.48e-11, Cgk = 1.14e-11, Cpk = 8.3e-12, 
    Vp = 400, Pp = 25, remark = "Osram", err = 0.0897689145499903, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`tPX4` <-
structure(list(G = 0.000631487, muc = 4.6140976, alpha = 0.47819605, 
    Ego = -0.81287548, Cgp = 1.37e-11, Cgk = 7.7e-12, Cpk = 3.9e-12, 
    Vp = 300, Pp = 15, remark = "Marconi", err = 0.0512202315221673, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`tPen45T` <-
structure(list(G = 0.0019602521, muc = 15.078846, alpha = 0.46663537, 
    Ego = 0.77688676, Cgp = 8.5e-13, Ci = 2.275e-11, Co = 1.275e-11, 
    Vp = 250, Vg2 = 250, remark = "Mazda", pentode.chara = c(250, 
    250, -8.5, 0.04, 0.0075, 20000), err = 0.0184247406572207, 
    code = 0L, g2.r = 0.15149452, Ea = -950), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "remark", 
"pentode.chara", "err", "code", "g2.r", "Ea"))
`tR120` <-
structure(list(G = 0.002490592, muc = 4.203714, alpha = 0.63322238, 
    Ego = 0.99999998, Cgp = 1.65e-11, Cgk = 1.85e-11, Cpk = 1.55e-11, 
    Vp = 300, Pp = 15, Ik = 0.09, remark = "?", err = 0.0613706894243507, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`tRE604` <-
structure(list(G = 0.00028831412, muc = 3.5532613, alpha = 0.4065817, 
    Ego = 0.99997938, Cgp = 4e-12, Cgk = 4e-12, Cpk = 4e-12, 
    Vp = 250, Pp = 10, remark = "Telefunken", err = 0.0452494279387175, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "remark", "err", "code"))
`tWE104D` <-
structure(list(G = 9.1039243e-05, muc = 2.0204341, alpha = 0.50186717, 
    Ego = -0.56998685, Cgp = 4.9e-12, Cgk = 4.1e-12, Cpk = 3.4e-12, 
    Vp = 190, remark = "WE", err = 0.0142736804537616, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Cgk", "Cpk", "Vp", "remark", "err", 
"code"))
`tWE262B` <-
structure(list(G = 0.00018582795, muc = 13.498802, alpha = 0.48999596, 
    Ego = 0.88434569, Cgp = 1.9e-12, Ci = 2.4e-12, Co = 3.8e-12, 
    Vp = 180, remark = "WE", err = 0.0253979072057107, code = 0L), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "remark", "err", 
"code"))
`tWE310AT` <-
structure(list(G = 0.00046759791, muc = 17.269587, alpha = 0.45117982, 
    Ego = 0.54054476, Cgp = 1.6e-14, Ci = 6e-12, Co = 9e-12, 
    Vp = 250, Vg2 = 180, Pp = 2, Pg2 = 0.4, Ik = 10000, remark = "WE", 
    pentode.chara = c(135, 135, -3, 0.0054, 0.0012, 9e+05), err = 0.0165753654100257, 
    code = 0L, g2.r = 0.16672657, Ea = -7155), .Names = c("G", 
"muc", "alpha", "Ego", "Cgp", "Ci", "Co", "Vp", "Vg2", "Pp", 
"Pg2", "Ik", "remark", "pentode.chara", "err", "code", "g2.r", 
"Ea"))
`tWE396A` <-
structure(list(G = 0.0016842826, muc = 25.013793, alpha = 0.57936321, 
    Ego = 0.052879817, Cgp = 1.3e-12, Ci = 2.2e-12, Co = 1e-12, 
    Vp = 300, Pp = 1.5, Ik = 0.018, remark = "WE", err = 0.0616369622464967, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Ci", "Co", "Vp", "Pp", "Ik", "remark", "err", "code"))
`tWE421A` <-
structure(list(G = 0.010830172, muc = 3.5006467, alpha = 0.7076208, 
    Ego = 0.99947463, Cgp = 8.6e-12, Cgk = 6e-12, Cpk = 2.2e-12, 
    Vp = 250, Pp = 13, Ik = 0.125, remark = "WE", err = 0.0475256486430056, 
    code = 0L), .Names = c("G", "muc", "alpha", "Ego", "Cgp", 
"Cgk", "Cpk", "Vp", "Pp", "Ik", "remark", "err", "code"))
`targ` <-
function (A, f, base.freq) 
{
    if (is.matrix(A)) {
        a <- matrix(NA, nrow=nrow(A), ncol=ncol(A))
        for (i in 1:ncol(A)) {
            a[, i] <- targ(A[, i], f, base.freq)
        }
        return(a)
    }
    a <- Arg(A) * 180 / pi
    # print(a)
    n <- cumsum(round(c(0, diff(a)) / 360))
    # print(n)
    i <- near(f, base.freq)
    # print(i)
    n <- n - n[i]
    # print(n)
    z <- a - n * 360
    # print(z)
    z
}

`throughline` <-
function(x, y, b, ...) 
{
    abline(a=-b*x + y, b=b, ...)
}

`touter` <-
function(func, p, Ep, Eg, ...)
{
    # �v���[�g�d���ƃO���b�h�d���̑g�ݍ��킹�ɂ��āA�֐���K�p����
    # func: �K�p����֐�(Ip �Ȃ�)
    # p: �^��ǂ̃p�����[�^
    # Ep: �v���[�g�d��
    # Eg: �v���[�g�d��
    # ...: func �ɓn���ǉ��̈���

    z <- outer(Ep, Eg, function(x, y) func(p, x, y, ...))
    dimnames(z) <- list(Ep, Eg)
    z
}

`trans.cascode` <-
function(p1, ei, Ebb, Eg1, Eg2, RL, Rk=0, p2=p1)
{
    # �J�X�R�[�h�ڑ��̓`�B���������߂�
    # p1: V1�̃p�����[�^
    # p2: V2�̃p�����[�^
    # ei: ���͓d��
    # Ebb: �d���d��
    # Eg1: V1�O���b�h�d��(�΃A�[�X)
    # Eg2: V2�O���b�h�d��
    # RL: ���ג�R
    # Rk: V1�J�\�[�h��R
    # �Ԓl
    # $Ip: �v���[�g�d��
    # $Eo: �o�͓d��(�΃A�[�XV2�v���[�g�d��)
    # $Eg1: �΃J�\�[�hV1�O���b�h�d��
    # $Ep1: �΃J�\�[�hV1�v���[�g�d��
    # $Eg2: �΃J�\�[�hV2�O���b�h�d��
    # $Ep2: �΃J�\�[�hV2�v���[�g�d��

    get.ek2 <- function(ip) {
        # �v���[�g�d���� ip �ƂȂ�Ƃ���
        # V2�̑΃A�[�X�J�\�[�h�d�������߂�
        if (ip == 0)                # V2���J�b�g�I�t����ꍇ��
            return(Ek2max)          # ����ȏ�̃J�\�[�h�d���ɂȂ�Ȃ��͂�?
        ep2 <- Ebb - ip * RL        # �΃A�[�XV2�v���[�g�d��
        if (ep2 <= 0)
            return(0)
        uniroot(function(ek) Ip(p2, ep2-ek, Eg2-ek) - ip,
                c(0, Ek2max), tol=1e-8)$root
    }

    f <- function(ip) {
        ep1 <- get.ek2(ip)      # �΃A�[�XV1�v���[�g�d��
        ek1 <- ip * Rk          # �΃A�[�XV1�J�\�[�h�d��
        ip1 <- Ip(p1, ep1-ek1, eg-ek1)
        ip - ip1
    }

    # V2���J�b�g�I�t(Ip=1nA)����΃A�[�X�J�\�[�h�d�������߂�
    Ek2max <- uniroot(function(ek) Ip(p2, Ebb-ek, Eg2-ek) - 1e-9,
            c(Eg2, Ebb))$root
    cat("Ek2max=", Ek2max, "\n", sep="")
    Eg <- ei + Eg1
    ip <- ek2 <- rep(0, length(Eg))
    for (i in seq(along=Eg)) {
        eg <- Eg[i]
        cat(eg, "")
        ip[i] <- if(Ip(p1, Ek2max, eg) <= 1e-9) 0
                else uniroot(f, c(0, (Ebb-Eg2)/RL), tol=1e-8)$root
        ek2[i] <- get.ek2(ip[i])
    }
    cat("\n")
    eo <- Ebb - ip * RL
    ep2 <- eo - ek2
    eg2 <- Eg2 - ek2
    ep1 <- ek2 - ip * Rk
    eg1 <- Eg - ip * Rk
    list(Ip=ip, Eo=eo, Ep1=ep1, Eg1=eg1, Ep2=ep2, Eg2=eg2)
}

`trans.comg` <-
function(p, ei, Ebb, Eg0, Ek0, RL) {
    # �O���b�h�ڒn��H�̓`�B���������߂�
    # p: �^��ǂ̃p�����[�^
    # ei: ���͓d��
    # Ebb: �d���d��
    # Eg0: �O���b�h�d��
    # Ek0: �J�\�[�h�d��
    # RL: ���ג�R

    f <- function(ep) {
        # ep: �΃A�[�X�v���[�g�d��
        ip2 <- (Ebb - ep)/RL        # ���[�h���C���ɂ��d��
        ip1 <- Ip(p, ep-ek, Eg0-ek) # �v���[�g�d���ɑ΂���v���[�g�d��
        ip1 - ip2                   # ����0�ɂȂ�v���[�g�d�������߂�
    }
    Ek <- ei + Ek0                  # ���ۂ̃O���b�h�d��(�΃A�[�X)
    ep <- rep(0, length(Ek))
    for (i in seq(along=Ek)) {      # ���͓d���̊e�v�f�ɑ΂��ă��[�v
        ek <- Ek[i]
        ep[i] <- if (Ip(p, Ebb-ek, Eg0-ek) == 0) Ebb    # �J�b�g�I�t
                else uniroot(f, c(ek, Ebb))$root
    }
    ip <- (Ebb - ep)/RL             # �v���[�g�d��
    list(Ip=ip, Eo=ep, Ep=ep-Ek, Ip=ip, Ek=Ek)
}

`trans.diff` <-
function(p, ei1, ei2=0, Ebb, Eg0, RL1, RL2=RL1,
        aRL1=RL1, aRL2=RL2, Ik, Rk, op, verbose=FALSE)
{
    # ����������H�̓`�B����
    # p: �p�����[�^
    # ei1: V1���͓d��
    # ei2: V2���͓d��
    # Ebb: �d���d��
    # Eg0: �O���b�h�o�C�A�X�d��
    # RL1: V1���ג�R(DC)
    # RL2: V2���ג�R(DC)
    # aRL1: V1���ג�R(AC)
    # aRL2: V2���ג�R(AC)
    # Ik: ���ʃJ�\�[�h�d��
    # Rk: �J�\�[�h��R
    # op: ����_�̏��
    # verbose: �i�s�󋵂�\�����邩?

    # �K�v�ȃp�����[�^���w�肳��Ă��邩�`�F�b�N����
    if (missing(Ik) && missing(Rk))
        stop("Ik or Rk must be specified.")
    if (missing(Ik))
        mode <- 1       # mullard
    else
        mode <- 0       # diff

    # ���͓d���̒����𑵂���(ei2==0 �̏ꍇ����������)
    if (length(ei1) != length(ei2)) {
        ei1 <- ei1 + ei2 * 0
        ei2 <- ei2 + ei1 * 0
    }

    # ����_�̏��𓾂�
    if (missing(op)) {
        if (mode == 1)
            op <- op.diff(p, Ebb, Eg0, RL1, RL2, Rk=Rk)
        else
            op <- op.diff(p, Ebb, Eg0, RL1, RL2, Ik=Ik)
    }

    # eg, ek ����܂����Ƃ���(�𗬕��ׂɑ΂���)�΃A�[�X�v���[�g�d�������߂�
    get.ep.ac <- function(eg, ek, RL, Eo0, Ip0) {
        # eg: �΃A�[�X�O���b�h�d��
        # ek: �΃A�[�X�J�\�[�h�d��
        # RL: ���ג�R
        # Eo0: ����_�̑΃A�[�X�v���[�g�d��
        # Ip0: ����_�̃v���[�g�d��
        Eomax <- Eo0 + Ip0 * RL         # �΃A�[�X�v���[�g�d���̍ő�l
        ip <- Ip(p, Eomax-ek, eg-ek)    # �ő�v���[�g�d��
        if (ip <= 0 || RL <= 0)         # �J�b�g�I�t�܂��͕��ׂ��Ȃ��ꍇ��
            return(list(ep=Eomax, ip=ip, ik=ip)) # �v���[�g�d���͍ő�l�ɏ㏸
        ep <- uniroot(function(ep) {
            ip2 <- Ip0 + (Eo0 - ep)/RL  # ���[�h���C�����狁�߂��v���[�g�d��
            ip1 <- Ip(p, ep-ek, eg-ek)  # �^��ǂ̓����ɂ��v���[�g�d��
            ip1 - ip2                   # ���҂̍����Ȃ��Ȃ�悤�� ep �����߂�
        }, c(ek, Eomax))$root
        z <- Ip.sub(p, ep-ek, eg-ek)
        list(ep=ep, ip=z$ip, ik=z$ip+z$ig)
    }

    # ����J�\�[�h�d����^�����Ƃ���
    # V1, V2�̍��v�d���ƃJ�\�[�h�d���̐H���Ⴂ��Ԃ��֐�(�M�����͎��T���p)
    f.ac <- function(ek) {
        v1 <- get.ep.ac(Eg0+eg1, ek, aRL1, op$eo1, op$ip1)
        v2 <- get.ep.ac(Eg0+eg2, ek, aRL2, op$eo2, op$ip2)
        v1$ik + v2$ik - (if (mode == 1) ek/Rk else Ik)
    }

    # ���͐M���x�N�g���̒����ɍ��킹�Č��ʊi�[�̈��p�ӂ���
    ek <- ip1 <- ip2 <- eo1 <- eo2 <- rep(NA, length(ei1))
    # �e���͐M���ɑ΂��ēd���E�d�������߂�
    for (i in seq(along=ei1)) {
        if (verbose)
            cat(i, "")
        eg1 <- ei1[i]
        eg2 <- ei2[i]
        ek[i] <- uniroot(f.ac, c(min(c(eg1, eg2))+Eg0, op$ekmax), tol=1e-6)$root
        v1 <- get.ep.ac(Eg0+eg1, ek[i], aRL1, op$eo1, op$ip1)
        ip1[i] <- v1$ip
        eo1[i] <- v1$ep
        v2 <- get.ep.ac(Eg0+eg2, ek[i], aRL2, op$eo2, op$ip2)
        ip2[i] <- v2$ip
        eo2[i] <- v2$ep
    }
    if (verbose)
        cat("\n")
    list(ek=ek, eo1=eo1, eo2=eo2, ip1=ip1, ep1=eo1-ek, ip2=ip2, ep2=eo2-ek)
}

`trans.param.11` <-
function(r101, r201, E101, E201,
    dir="", data.name, model.name, data.mode="")
{
    # �g�����X�̃p�����[�^�����߂�
    # r101: 1��������R
    # r201: 2��������R
    # E101: 1���d��
    # E201: 2���d��
    # dir: �C���s�[�_���X���茋�ʂ̂���f�B���N�g��
    # data.name: �f�[�^�t�@�C����
    # model.name: SPICE���f����(�T�u�T�[�L�b�g��)
    # data.mode: FRA�ő��肵���l(�ΐ�)�Ȃ� "log" ���w��

    Paste <- function(...) paste(..., sep="")
    s6 <- function(x) signif(x, 6)
    s8 <- function(x) signif(x, 8)
    col <- c("red", "blue", "orange", "green", "pink", "brown", "yellow", "violet", "purple")

    n101 <- 1                                   # �ꎟ����
    n201 <- E201 / E101                         # �񎟊�����
    cat("2������ n201=", n201, "\n", sep="")

    z <- trans.param.open(dir, data.name, "101_o", data.mode, r101)
    L101 <- z$Lp
    L201 <- z$Lp * n201^2
    cat("�񎟃C���_�N�^���X Ls=", L201, "\n", sep="")
    Css <- (z$Cst  - z$Csp) / (n201 / n101)^2
    cat("2�����z�e�� Css=", Css, "\n", sep="")

    # �R��C���_�N�^���X�����߂�
    x <- trans.param.read(dir, data.name, "101_s201", data.mode)
    r <- r101 + r201 * (n101 / n201)^2
    K.101.201 <- find.Ll(x, r, L101, col[2], "Ll_101_201=", "K_101_201=")

    s <- NULL
    s[1] <- "*"
    s[2] <- Paste("*   ", model.name)
    s[3] <- Paste("*   ", Copyright)
    s[4] <- Paste(".SUBCKT ", model.name, " P1 P0 S1 S0")
    s[5] <- "* Primary Inductance"
    s[6] <- Paste("L101 11 P0 ", s6(L101), "H")
    s[7] <- "* Primary DC resistance"
    s[8] <- Paste("R101 P1 11 ", s6(r101))
    s[9] <- "* Primary stray capacitance"
    s[10] <- Paste("CP P1 P0 ", s6(z$Csp))
    s[11] <- "* Iron loss"
    s[12] <- Paste("RI P1 P0 ", s6(z$RI / 1e3), "k")
    s[13] <- "* Secondary inductances"
    s[14] <- Paste("L201 21 S0 ", s6(L201), "H")
    s[15] <- "* Secondary DC resistances"
    s[16] <- Paste("R201 S1 21 ", s6(r201))
    s[17] <- "* Secondary stray capacitances"
    s[18] <- Paste("CS S1 S0 ", s6(Css))
    s[19] <- "* Coupling factor"
    s[20] <- Paste("K1 L101 L201 ", s8(K.101.201))
    s[21] <- ".ENDS"
    model.fname <- Paste(dir, model.name, ".inc")
    cat("Writing", model.fname, "\n")
    write(s, file=model.fname)
}

`trans.param.12` <-
function(r101, r201, r202, E101, E201,
    dir="", data.name, model.name, data.mode="")
{
    # 2���Z���^�[�^�b�v�g�����X�̃p�����[�^�����߂�
    # r101: 1��������R
    # r201: 2������1��R
    # r202: 2������2��R
    # E101: 1���d��
    # E201: 2���d��
    # dir: �C���s�[�_���X���茋�ʂ̂���f�B���N�g��
    # data.name: �f�[�^�t�@�C����
    # model.name: SPICE���f����(�T�u�T�[�L�b�g��)
    # data.mode: FRA�ő��肵���l(�ΐ�)�Ȃ� "log" ���w��

    Paste <- function(...) paste(..., sep="")
    s6 <- function(x) signif(x, 6)
    s8 <- function(x) signif(x, 8)
    col <- c("red", "blue", "orange", "green", "pink", "brown", "yellow", "violet", "purple")

    n101 <- 1
    n201 <- n202 <- E201 / E101
    cat("2���Њ��� n201=", n201, "\n", sep="")

    z <- trans.param.open(dir, data.name, "101_o", data.mode, r101)
    L101 <- z$Lp
    L201 <- L202 <- z$Lp * n201^2
    cat("�Г񎟃C���_�N�^���X Ls=", L201, "\n", sep="")
    Css <- (z$Cst  - z$Csp) / (n201 * 2 / n101)^2 * 2
    cat("2���Е��z�e�� Css=", Css, "\n", sep="")

    # �R��C���_�N�^���X�����߂�
    x <- trans.param.read(dir, data.name, "101_s201", data.mode)
    r <- r101 + r201 * (n101 / n201)^2
    K.101.201 <- find.Ll(x, r, L101, col[2], "Ll_101_201=", "K_101_201=")

    x <- trans.param.read(dir, data.name, "101_s202", data.mode)
    r <- r101 + r202 * (n101 / n202)^2
    K.101.202 <- find.Ll(x, r, L101, col[3], "Ll_101_202=", "K_101_202=")

    x <- trans.param.read(dir, data.name, "201_s202", data.mode)
    r <- r201 + r202 * (n201 / n202)^2
    K.201.202 <- find.Ll(x, r, L201, col[5], "Ll_201_202=", "K_201_202=")

    s <- NULL
    s[1] <- "*"
    s[2] <- Paste("*   ", model.name)
    s[3] <- Paste("*   ", Copyright)
    s[4] <- Paste(".SUBCKT ", model.name, " P1 P0 S1 S0 S2")
    s[5] <- "* Primary Inductance"
    s[6] <- Paste("L101 11 P0 ", s6(L101), "H")
    s[7] <- "* Primary DC resistance"
    s[8] <- Paste("R101 P1 11 ", s6(r101))
    s[9] <- "* Primary stray capacitance"
    s[10] <- Paste("CP P1 P0 ", s6(z$Csp))
    s[11] <- "* Iron loss"
    s[12] <- Paste("RI P1 P0 ", s6(z$RI / 1e3), "k")
    s[13] <- "* Secondary inductances"
    s[14] <- Paste("L201 21 S0 ", s6(L201), "H")
    s[15] <- Paste("L202 S0 22 ", s6(L201), "H")
    s[16] <- "* Secondary DC resistances"
    s[17] <- Paste("R201 S1 21 ", s6(r201))
    s[18] <- Paste("R202 S2 22 ", s6(r202))
    s[19] <- "* Secondary stray capacitances"
    s[20] <- Paste("CS1 S1 S0 ", s6(Css))
    s[21] <- Paste("CS2 S2 S0 ", s6(Css))
    s[22] <- "* Coupling factor"
    s[23] <- Paste("K1 L101 L201 ", s8(K.101.201))
    s[24] <- Paste("K2 L101 L202 ", s8(K.101.202))
    s[25] <- Paste("K3 L201 L202 ", s8(K.201.202))
    s[26] <- ".ENDS"
    model.fname <- Paste(dir, model.name, ".inc")
    cat("Writing", model.fname, "\n")
    write(s, file=model.fname)
}

`trans.param.open` <-
function(dir, data.name, open.wn, data.mode, r) {
    # �g�����X�ꎟ�J���̃f�[�^����A
    # �S���A�ꎟ�C���_�N�^���X�A�����z�e�ʂ����߂�
    # dir: �C���s�[�_���X���茋�ʂ̂���f�B���N�g��
    # data.name: �f�[�^�t�@�C����
    # open.wn: ���茋�ʊ�����
    # data.mode: FRA�ő��肵���l(�ΐ�)�Ȃ� "log" ���w��
    # r: ������R

    x <- trans.param.read(dir, data.name, open.wn, data.mode)
    xZ <- trans.param.read(dir, data.name, "Zp", data.mode)
    xd <- cbind.irregular(x$f, xZ$f)
    yd <- cbind.irregular(x$z, xZ$z)
    logplot(xd, yd, type="l", col=c("red", "orange"), lty=1,
        xlab="Frequency (Hz)",
        ylab=expression(paste("Impedance (", Omega, ")")),
        ylim=c(1, 1e6))

    # �S�������߂�
    peak.idx <- which(x$z == max(x$z))[1]       # �C���s�[�_���X���ő�ƂȂ�Y��
    cat("f=", x$f[peak.idx], "\n", sep="")
    RI <- x$z[peak.idx]
    cat("�S�� RI=", RI, "\n", sep="")

    # 50Hz�ɂ�����C���s�[�_���X����ꎟ�C���_�N�^���X�����߂�
    i <- near(x$f, 50)
    points(log10(x$f[i]), log10(x$z[i]), col="red")
    throughline(log10(x$f[i]), log10(x$z[i]), 1)
    Lp <- sqrt(x$z[i]^2 - r^2)/(2 * pi * x$f[i])
    cat("�ꎟ�C���_�N�^���X=", Lp, "\n", sep="")

    # �����z�e�ʂ����߂�
    Zod <- diff(log10(x$z)) / diff(log10(x$f))
    # �J���C���s�[�_���X�̍ŏ��̃f�B�b�v��������
    dip.idx <- which(Zod[-length(Zod)] < 0 & Zod[-1] >= 0)[1] + 1
    if (is.na(dip.idx))                     # ������Ȃ��ꍇ��
        dip.idx <- length(Zod)              # �Ō�܂ł̃f�[�^���g��
    wn <- dip.idx - peak.idx    # �J���C���s�[�_���X���������Ă���f�[�^��
    idx <- (peak.idx + wn %/% 4):(dip.idx - wn %/% 4)   # �T���͈�
    err <- (Zod[idx] - -1)^2                # �X���� -1 �ɍł��߂�
    i <- idx[err == min(err)][1]            # �Y��
    cat("f=", x$f[i], "\n", sep="")
    points(log10(x$f[i]), log10(x$z[i]), col="red")
    throughline(log10(x$f[i]), log10(x$z[i]), -1)
    Cst <- 1/(2 * pi * x$f[i] * x$z[i])     # �����z�e��
    cat("�����z�e�� Cst=", Cst, "\n", sep="")
#   n <- length(x$f)
    n <- near(x$f, 500e3)
    Csp <- 1/(2 * pi * x$f[n] * x$z[n])
    cat("1�����z�e�� Csp=", Csp, "\n", sep="")
    list(RI=RI, Lp=Lp, Cst=Cst, Csp=Csp)
}

`trans.param.pp` <-
function(r101=r113+r103, r102=r124+r104, r202,
    r113, r103, r104, r124,
    E101, E103, E202, rUL,
    dir="", data.name, model.name, data.mode="")
{
    # �v�b�V���v���g�����X�̃p�����[�^�����߂�
    # r101: P1-B �Ԋ�����R
    # r102: B-P2 �Ԋ�����R
    # r113: P1-SG1 �Ԋ�����R
    # r103: SG1-B �Ԋ�����R
    # r104: B-SG2 �Ԋ�����R
    # r124: SG2-P2 �Ԋ�����R
    # r202: 2��������R(8���[�q)
    # E101: P1-B �ԓd��
    # E103: B-SG1 �ԓd��
    # E202: 2���d��
    # rUL: UL�^�b�v��
    # dir: �C���s�[�_���X���茋�ʂ̂���f�B���N�g��
    # data.name: �f�[�^�t�@�C����
    # model.name: SPICE���f����(�T�u�T�[�L�b�g��)
    # data.mode: FRA�ő��肵���l(�ΐ�)�Ȃ� "log" ���w��

    Paste <- function(...) paste(..., sep="")
    s6 <- function(x) signif(x, 6)
    s8 <- function(x) signif(x, 8)
    col <- c("red", "blue", "orange", "green", "pink", "brown", "yellow", "violet", "purple")

    if (!missing(rUL) || !missing(E103)) {
        UL <- TRUE
        if (missing(rUL))
            rUL <- E103 / E101
        if (missing(r113))
            r113 <- r101 * (1 - rUL)
        if (missing(r103))
            r103 <- r101 * rUL
        if (missing(r124))
            r124 <- r102 * (1 - rUL)
        if (missing(r104))
            r104 <- r102 * rUL
    } else
        UL <- FALSE

    n101 <- n102 <- 1
    n202 <- E202 / E101
    cat("1���Њ��� n101=", n101, "\n", sep="")
    cat("8�������� n202=", n202, "\n", sep="")

    z <- trans.param.open(dir, data.name, "101_o", data.mode, r101)
    RI1 <- z$RI * 2
    L101 <- L102 <- z$Lp
    L202 <- z$Lp * n202^2
    cat("�񎟃C���_�N�^���X Ls=", L202, "\n", sep="")
    Cp1 <- z$Cst / 2

    x <- trans.param.read(dir, data.name, "101_s102", data.mode)
    r <- r101 + r102 * (n101 / n102)^2
    K.101.102 <- find.Ll(x, r, L101, col[2], "Ll_101_102=", "K_101_102=")

    x <- trans.param.read(dir, data.name, "101_s202", data.mode)
    r <- r101 + r202 * (n101 / n202)^2
    K.101.202 <- find.Ll(x, r, L101, col[3], "Ll_101_202=", "K_101_202=")

    x <- trans.param.read(dir, data.name, "102_s202", data.mode)
    r <- r102 + r202 * (n102 / n202)^2
    K.102.202 <- find.Ll(x, r, L102, col[5], "Ll_102_202=", "K_102_202=")

    s <- NULL
    s[1] <- "*"
    s[2] <- Paste("*   ", model.name)
    s[3] <- Paste("*   ", Copyright)
    s[4] <- Paste(".SUBCKT ", model.name, " P1 B P2 S8 S0")
    s[5] <- "* Primary Inductance"
    s[6] <- Paste("L101 11 B   ", s6(L101), "H")
    s[7] <- Paste("L102 B  12  ", s6(L102), "H")
    s[8] <- "* Primary DC resistance"
    s[9] <- Paste("R101 P1 11  ", s6(r101))
    s[10] <- Paste("R102 12 P2  ", s6(r102))
    s[11] <- "* Primary stray capacitance"
    s[12] <- Paste("CP1 P1 B  ", s6(Cp1))
    s[13] <- Paste("CP2 B  P2 ", s6(Cp1))
    s[14] <- "* Iron loss"
    s[15] <- Paste("RI1 P1 B  ", s6(RI1 / 1e3), "k")
    s[16] <- Paste("RI2 P2 B  ", s6(RI1 / 1e3), "k")
    s[17] <- "* Secondary inductance"
    s[18] <- Paste("L202 S8 22 ", s6(L202), "H")
    s[19] <- "* Secondary DC resistance"
    s[20] <- Paste("R202 22 S0  ", s6(r202))
    s[21] <- "* Coupling factor"
    s[22] <- Paste("K1  L101 L102 ", s8(K.101.102))
    s[23] <- Paste("K2  L101 L202 ", s8(K.101.202))
    s[24] <- Paste("K3  L102 L202 ", s8(K.102.202))
    s[25] <- ".ENDS"
    model.fname <- Paste(dir, model.name, ".inc")
    cat("Writing", model.fname, "\n")
    write(s, file=model.fname)

    if (UL) {
        n103 <- n104 <- rUL
        n113 <- n124 <- 1 - rUL
        cat("SG�^�b�v������ n103=", n103, "\n", sep="")
        cat("SG-P������ n113=", n113, "\n", sep="")

        L113 <- z$Lp * n113^2
        L103 <- z$Lp * n103^2
        L104 <- z$Lp * n104^2
        L124 <- z$Lp * n124^2
        cat("L113=", L113, "\n", sep="")
        cat("L103=", L103, "\n", sep="")
        cat("L104=", L104, "\n", sep="")
        cat("L124=", L124, "\n", sep="")

        s <- NULL
        s[1] <- "*"
        s[2] <- Paste("*   ", model.name, "_UL")
        s[3] <- "*   Copyright 2007--2010, Ayumi Nakabayashi.  All rights reserved."
        s[4] <- Paste(".SUBCKT ", model.name, "_UL P1 SG1 B SG2 P2 S8 S0")
        s[5] <- "* Primary Inductance"
        s[6] <- Paste("L113 11 SG1 ", s6(L113), "H")
        s[7] <- Paste("L103 13 B   ", s6(L103), "H")
        s[8] <- Paste("L104 B  14  ", s6(L104), "H")
        s[9] <- Paste("L124 SG2 12 ", s6(L124), "H")
        s[10] <- "* Primary DC resistance"
        s[11] <- Paste("R113 P1 11  ", s6(r113))
        s[12] <- Paste("R103 SG1 13 ", s6(r103))
        s[13] <- Paste("R104 14 SG2 ", s6(r104))
        s[14] <- Paste("R124 12 P2  ", s6(r124))
        s[15] <- "* Primary stray capacitance"
        s[16] <- Paste("CP1 P1 B  ", s6(Cp1))
        s[17] <- Paste("CP2 B  P2 ", s6(Cp1))
        s[18] <- "* Iron loss"
        s[19] <- Paste("RI1 P1 B  ", s6(RI1 / 1e3), "k")
        s[20] <- Paste("RI2 P2 B  ", s6(RI1 / 1e3), "k")
        s[21] <- "* Secondary inductance"
        s[22] <- Paste("L202 S8 22 ", s6(L202), "H")
        s[23] <- "* Secondary DC resistance"
        s[24] <- Paste("R202 22 S0  ", s6(r202))
        s[25] <- "* Coupling factor"
        s[26] <- "K1  L113 L103 1"
        s[27] <- Paste("K2  L113 L104 ", s8(K.101.102))
        s[28] <- Paste("K3  L113 L124 ", s8(K.101.102))
        s[29] <- Paste("K4  L113 L202 ", s8(K.101.202))
        s[30] <- Paste("K5  L103 L104 ", s8(K.101.102))
        s[31] <- Paste("K6  L103 L124 ", s8(K.101.102))
        s[32] <- Paste("K7  L103 L202 ", s8(K.101.202))
        s[33] <- "K8  L104 L124 1"
        s[34] <- Paste("K9  L104 L202 ", s8(K.102.202))
        s[35] <- Paste("K10 L124 L202 ", s8(K.102.202))
        s[36] <- ".ENDS"
        model.fname <- Paste(dir, model.name, "_UL.inc")
        cat("Writing", model.fname, "\n")
        write(s, file=model.fname)
    }
}

`trans.param.pp.KF` <-
function(r101=r113+r103, r102=r124+r104,
    r113, r103, r104, r124, r201, r203,
    E101, E103, E201, E203, rUL,
    dir="", data.name, model.name, data.mode="")
{
    # �J�\�[�h�A�Ҋ����t��
    # �v�b�V���v���g�����X�̃p�����[�^�����߂�
    # r101: P1-B �Ԋ�����R
    # r102: B-P2 �Ԋ�����R
    # r113: P1-SG1 �Ԋ�����R
    # r103: SG1-B �Ԋ�����R
    # r104: B-SG2 �Ԋ�����R
    # r124: SG2-P2 �Ԋ�����R
    # r201: 0-4���Ԃ̊�����R
    # r203: 0-16���Ԃ̊�����R
    # E101: P1-B �ԓd��
    # E103: SG1-B �ԓd��
    # E201: 0-4���Ԃ̓d��
    # E203: 0-16���Ԃ̓d��
    # data.fname: �f�[�^�t�@�C����
    # model.name: SPICE���f����(�T�u�T�[�L�b�g��)
    # data.mode: FRA�ő��肵���l(�ΐ�)�Ȃ� "log" ���w��

    Paste <- function(...) paste(..., sep="")
    s6 <- function(x) signif(x, 6)
    s8 <- function(x) signif(x, 8)
    col <- c("red", "blue", "orange", "green", "pink", "brown", "yellow", "violet", "purple")

    if (!missing(rUL) || !missing(E103)) {
        UL <- TRUE
        if (missing(rUL))
            rUL <- E103 / E101
        if (missing(r113))
            r113 <- r101 * (1 - rUL)
        if (missing(r103))
            r103 <- r101 * rUL
        if (missing(r124))
            r124 <- r102 * (1 - rUL)
        if (missing(r104))
            r104 <- r102 * rUL
    } else
        UL <- FALSE

    r213 <- r203 - r201
    n101 <- n102 <- 1
    n201 <- E201 / E101
    n203 <- E203 / E101
    n213 <- (E203 - E201) / E101
    cat("1���Њ��� n101=", n101, "\n", sep="")
    cat("4�������� n201=", n201, "\n", sep="")
    cat("4-16�������� n213=", n213, "\n", sep="")

    z <- trans.param.open(dir, data.name, "101_o", data.mode, r101)
    RI1 <- z$RI * 2
    L101 <- L102 <- z$Lp
    cat("���񎟃C���_�N�^���X Ls=", z$Lp*n203^2, "\n", sep="")
    L201 <- z$Lp * n201^2
    L213 <- z$Lp * n213^2
    cat("L201=", L201, "\n", sep="")
    cat("L213=", L213, "\n", sep="")
    Cp1 <- z$Cst / 2

    x <- trans.param.read(dir, data.name, "101_s102", data.mode)
    r <- r101 + r102 * (n101 / n102)^2
    K.101.102 <- find.Ll(x, r, L101, col[2], "Ll_101_102=", "K_101_102=")

    x <- trans.param.read(dir, data.name, "101_s201", data.mode)
    r <- r101 + r201 * (n101 / n201)^2
    K.101.201 <- find.Ll(x, r, L101, col[3], "Ll_101_201=", "K_101_201=")

    x <- trans.param.read(dir, data.name, "101_s213", data.mode)
    r <- r101 + r213 * (n101 / n213)^2
    K.101.213 <- find.Ll(x, r, L101, col[4], "Ll_101_213=", "K_101_213=")

    x <- trans.param.read(dir, data.name, "102_s201", data.mode)
    r <- r102 + r201 * (n102 / n201)^2
    K.102.201 <- find.Ll(x, r, L102, col[5], "Ll_102_201=", "K_102_201=")

    x <- trans.param.read(dir, data.name, "102_s213", data.mode)
    r <- r102 + r213 * (n102 / n213)^2
    K.102.213 <- find.Ll(x, r, L102, col[6], "Ll_102_213=", "K_102_213=")

    if (file.exists(paste(dir, data.name, "_201_s213.csv", sep=""))) {
        x <- trans.param.read(dir, data.name, "201_s213", data.mode)
        r <- r201 + r213 * (n201 / n213)^2
        K.201.213 <- find.Ll(x, r, L201, col[7], "Ll_201_213=", "K_201_213=")
    } else {
        K.201.213 <- 0.9999
    }

    s <- NULL
    s[1] <- "*"
    s[2] <- Paste("*   ", model.name)
    s[3] <- Paste("*   ", Copyright)
    s[4] <- Paste(".SUBCKT ", model.name, " P1 B P2 S16 S4 S0")
    s[5] <- "* Primary Inductance"
    s[6] <- Paste("L101 11 B   ", s6(L101), "H")
    s[7] <- Paste("L102 B  12  ", s6(L102), "H")
    s[8] <- "* Primary DC resistance"
    s[9] <- Paste("R101 P1 11  ", s6(r101))
    s[10] <- Paste("R102 12 P2  ", s6(r102))
    s[11] <- "* Primary stray capacitance"
    s[12] <- Paste("CP1 P1 B  ", s6(Cp1))
    s[13] <- Paste("CP2 B  P2 ", s6(Cp1))
    s[14] <- "* Iron loss"
    s[15] <- Paste("RI1 P1 B  ", s6(RI1 / 1e3), "k")
    s[16] <- Paste("RI2 P2 B  ", s6(RI1 / 1e3), "k")
    s[17] <- "* Secondary inductance"
    s[18] <- Paste("L213 23 S4 ", s6(L213), "H")
    s[19] <- Paste("L201 S4 21 ", s6(L201), "H")
    s[20] <- "* Secondary DC resistance"
    s[21] <- Paste("R213 23 S16 ", s6(r213))
    s[22] <- Paste("R201 21 S0  ", s6(r201))
    s[23] <- "* Coupling factor"
    s[24] <- Paste("K1  L101 L102 ", s8(K.101.102))
    s[25] <- Paste("K2  L101 L213 ", s8(K.101.213))
    s[26] <- Paste("K3  L101 L201 ", s8(K.101.201))
    s[27] <- Paste("K4  L102 L213 ", s8(K.102.213))
    s[28] <- Paste("K5  L102 L201 ", s8(K.102.201))
    s[29] <- Paste("K6  L213 L201 ", s8(K.201.213))
    s[30] <- ".ENDS"
    model.fname <- Paste(dir, model.name, ".inc")
    cat("Writing", model.fname, "\n")
    write(s, file=model.fname)

    if (UL) {
        ul.model.name <- paste(substr(model.name, 1, nchar(model.name)-3), "_ULKF", sep="")
        n103 <- n104 <- rUL
        n113 <- n124 <- 1 - rUL
        cat("SG�^�b�v������ n103=", n103, "\n", sep="")
        cat("SG-P������ n113=", n113, "\n", sep="")

        L113 <- z$Lp * n113^2
        L103 <- z$Lp * n103^2
        L104 <- z$Lp * n104^2
        L124 <- z$Lp * n124^2
        cat("L113=", L113, "\n", sep="")
        cat("L103=", L103, "\n", sep="")
        cat("L104=", L104, "\n", sep="")
        cat("L124=", L124, "\n", sep="")

        s <- NULL
        s[1] <- "*"
        s[2] <- Paste("*   ", ul.model.name)
        s[3] <- "*   Copyright 2007--2008, Ayumi Nakabayashi.  All rights reserved."
        s[4] <- Paste(".SUBCKT ", ul.model.name, " P1 SG1 B SG2 P2 S16 S4 S0")
        s[5] <- "* Primary Inductance"
        s[6] <- Paste("L113 11 SG1 ", s6(L113), "H")
        s[7] <- Paste("L103 13 B   ", s6(L103), "H")
        s[8] <- Paste("L104 B  14  ", s6(L104), "H")
        s[9] <- Paste("L124 SG2 12 ", s6(L124), "H")
        s[10] <- "* Primary DC resistance"
        s[11] <- Paste("R113 P1 11  ", s6(r113))
        s[12] <- Paste("R103 SG1 13 ", s6(r103))
        s[13] <- Paste("R104 14 SG2 ", s6(r104))
        s[14] <- Paste("R124 12 P2  ", s6(r124))
        s[15] <- "* Primary stray capacitance"
        s[16] <- Paste("CP1 P1 B  ", s6(Cp1))
        s[17] <- Paste("CP2 B  P2 ", s6(Cp1))
        s[18] <- "* Iron loss"
        s[19] <- Paste("RI1 P1 B  ", s6(RI1 / 1e3), "k")
        s[20] <- Paste("RI2 P2 B  ", s6(RI1 / 1e3), "k")
        s[21] <- "* Secondary inductance"
        s[22] <- Paste("L213 23 S4 ", s6(L213), "H")
        s[23] <- Paste("L201 S4 21 ", s6(L201), "H")
        s[24] <- "* Secondary DC resistance"
        s[25] <- Paste("R213 23 S16 ", s6(r213))
        s[26] <- Paste("R201 21 S0  ", s6(r201))
        s[27] <- "* Coupling factor"
        s[28] <- "K1  L113 L103 1"
        s[29] <- Paste("K2  L113 L104 ", s8(K.101.102))
        s[30] <- Paste("K3  L113 L124 ", s8(K.101.102))
        s[31] <- Paste("K4  L113 L213 ", s8(K.101.213))
        s[32] <- Paste("K5  L113 L201 ", s8(K.101.201))
        s[33] <- Paste("K6  L103 L104 ", s8(K.101.102))
        s[34] <- Paste("K7  L103 L124 ", s8(K.101.102))
        s[35] <- Paste("K8  L103 L213 ", s8(K.101.213))
        s[36] <- Paste("K9  L103 L201 ", s8(K.101.201))
        s[37] <- "K10 L104 L124 1"
        s[38] <- Paste("K11 L104 L213 ", s8(K.102.213))
        s[39] <- Paste("K12 L104 L201 ", s8(K.102.201))
        s[40] <- Paste("K13 L124 L213 ", s8(K.102.213))
        s[41] <- Paste("K14 L124 L201 ", s8(K.102.201))
        s[42] <- Paste("K15 L213 L201 ", s8(K.201.213))
        s[43] <- ".ENDS"
        model.fname <- Paste(dir, ul.model.name, ".inc")
        cat("Writing", model.fname, "\n")
        write(s, file=model.fname)
    }
}

`trans.param.read` <-
function(dir, dat.name, wn, mode) {
    # �g�����X�̃C���s�[�_���X���茋�ʂ�ǂݍ���.
    # �t�@�C���̌`���́A2��ڂɎ��g�����A5��ڂɃC���s�[�_���X��
    # �����Ă�����̂Ƃ���.
    # dir: �f�B���N�g��
    # dat.name: �t�@�C�����̊�{����
    # wn: ������
    # mode: FRA�ő��肵���l(�ΐ�)�Ȃ� "log" ���w��
    # �Ԓl:
    #   $f: ������g���̃x�N�g��
    #   $z: �C���s�[�_���X�̃x�N�g��

    fn <- paste(dir, dat.name, "_", wn, ".csv", sep="")
    x <- matscan(fn, sep=",")
    f <- x[, 1]
    z <- x[, 4]
    if (mode == "log")
        z <- 10^(z/20)
    list(f=f, z=z)
}

`trans.param.se` <-
function(r101=r113+r103, r201, r113, r103,
    E101, E103, E201, rUL,
    dir="", data.name, model.name, data.mode="")
{
    # �V���O���o�̓g�����X�̃p�����[�^�����߂�
    # r101: 1��������R
    # r201: 2��������R
    # r113: P-SG�Ԋ�����R
    # r103: SG-B�Ԋ�����R
    # E101: ��1���d��
    # E103: SG-B�ԓd��
    # E201: 2���d��
    # rUL UL�^�b�v��
    # dir: �C���s�[�_���X���茋�ʂ̂���f�B���N�g��
    # data.name: �f�[�^�t�@�C����
    # model.name: SPICE���f����(�T�u�T�[�L�b�g��)
    # data.mode: FRA�ő��肵���l(�ΐ�)�Ȃ� "log" ���w��

    Paste <- function(...) paste(..., sep="")
    s6 <- function(x) signif(x, 6)
    s8 <- function(x) signif(x, 8)
    col <- c("red", "blue", "orange", "green", "pink", "brown", "yellow", "violet", "purple")

    if (!missing(rUL) || !missing(E103)) {
        UL <- TRUE
        if (missing(rUL))
            rUL <- E103 / E101
        if (missing(r113))
            r113 <- r101 * (1 - rUL)
        if (missing(r103))
            r103 <- r101 * rUL
    } else
        UL <- FALSE

    n101 <- 1                                   # �ꎟ����
    n201 <- E201 / E101                         # �񎟊�����
    cat("2������ n201=", n201, "\n", sep="")

    z <- trans.param.open(dir, data.name, "101_o", data.mode, r101)
    L101 <- z$Lp
    L201 <- z$Lp * n201^2
    cat("2���C���_�N�^���X Ls=", L201, "\n", sep="")
    Css <- (z$Cst - z$Csp) / (n201 / n101)^2
    cat("2�����z�e�� Css=", Css, "\n", sep="")

    # �R��C���_�N�^���X�����߂�
    x <- trans.param.read(dir, data.name, "101_s201", data.mode)
    r <- r101 + r201 * (n101 / n201)^2
    K.101.201 <- find.Ll(x, r, L101, col[2], "Ll_101_201=", "K_101_201=")

    s <- NULL
    s[1] <- "*"
    s[2] <- Paste("*   ", model.name)
    s[3] <- Paste("*   ", Copyright)
    s[4] <- Paste(".SUBCKT ", model.name, " P B S1 S0")
    s[5] <- "* Primary inductance"
    s[6] <- Paste("L101 11 B ", s6(L101), "H")
    s[7] <- "* Primary DC resistance"
    s[8] <- Paste("R101 P 11 ", s6(r101))
    s[9] <- "* Primary stray capacitance"
    s[10] <- Paste("CP P B ", s6(z$Csp))
    s[11] <- "* Iron loss"
    s[12] <- Paste("RI P B ", s6(z$RI / 1e3), "k")
    s[13] <- "* Secondary inductance"
    s[14] <- Paste("L201 21 S0 ", s6(L201), "H")
    s[15] <- "* Secondary DC resistance"
    s[16] <- Paste("R201 S1 21 ", s6(r201))
    s[17] <- "* Secondary stray capacitance"
    s[18] <- Paste("CS S1 S0 ", s6(Css))
    s[19] <- "* Coupling factor"
    s[20] <- Paste("K1 L101 L201 ", s8(K.101.201))
    s[21] <- ".ENDS"
    model.fname <- Paste(dir, model.name, ".inc")
    cat("Writing", model.fname, "\n")
    write(s, file=model.fname)

    if (UL) {
        n101 <- 1
        n103 <- rUL
        n113 <- 1 - rUL
        cat("SG�^�b�v������ n103=", n103, "\n", sep="")
        cat("SG-P������ n113=", n103, "\n", sep="")

        L113 <- z$Lp * n113^2
        L103 <- z$Lp * n103^2
        cat("L113=", L113, "\n", sep="")
        cat("L103=", L103, "\n", sep="")

        s <- NULL
        s[1] <- "*"
        s[2] <- Paste("*   ", model.name, "_UL")
        s[3] <- "*   Copyright 2007--2010, Ayumi Nakabayashi.  All rights reserved."
        s[4] <- Paste(".SUBCKT ", model.name, "_UL P SG B S1 S0")
        s[5] <- "* Primary inductance"
        s[6] <- Paste("L113 11 SG ", s6(L113), "H")
        s[7] <- Paste("L103 13 B  ", s6(L103), "H")
        s[8] <- "* Primary DC resistance"
        s[9] <- Paste("R113 P 11 ", s6(r113))
        s[10] <- Paste("R103 SG 13 ", s6(r103))
        s[11] <- "* Primary stray capacitance"
        s[12] <- Paste("CP P B ", s6(z$Csp))
        s[13] <- "* Iron loss"
        s[14] <- Paste("RI P B ", s6(z$RI / 1e3), "k")
        s[15] <- "* Secondary inductance"
        s[16] <- Paste("L201 21 S0 ", s6(L201), "H")
        s[17] <- "* Secondary DC resistance"
        s[18] <- Paste("R201 S1 21 ", s6(r201))
        s[19] <- "* Secondary stray capacitance"
        s[20] <- Paste("CS S1 S0 ", s6(Css))
        s[21] <- "* Coupling factor"
        s[22] <- "K1 L113 L103 1"
        s[23] <- Paste("K2 L113 L201 ", s8(K.101.201))
        s[24] <- Paste("K3 L103 L201 ", s8(K.101.201))
        s[25] <- ".ENDS"
        model.fname <- Paste(dir, model.name, "_UL.inc")
        cat("Writing", model.fname, "\n")
        write(s, file=model.fname)
    }
}

`trans.pp` <-
function(p, eg, Ebb, Eg0, RL, ig=FALSE)
{
    # �v�b�V���v���o�͒i�̓`�B����
    # p: �p�����[�^
    # eg: ���͓d��
    # Ebb: �d���d��
    # Eg0: �o�C�A�X�d��
    # RL: ���׃C���s�[�_���X

    eRL <- RL/4
    f <- function(ep1) {
        ip <- Ip.pp(p, ep1, egi1, Ebb, Eg0)
        irl <- Ebb/eRL - ep1/eRL        # ���[�h���C���ɂ��d��
        ip - irl
    }
    ep <- ip1 <- ip2 <- rep(NA, length(eg))
    ig1 <- ig2 <- rep(0, length(eg))
    for (i in seq(along=eg)) {
        egi1 <- eg[i] + Eg0
        ep[i] <- uniroot(f, c(0, 2*Ebb))$root
        ip1[i] <- Ip(p, ep[i], egi1)
        ip2[i] <- -Ip(p, 2*Ebb-ep[i], 2*Eg0-egi1)
        if (ig) {
            ig1[i] <- Ig(p, ep[i], egi1)
            ig2[i] <- -Ig(p, 2*Ebb-ep[i], 2*Eg0-egi1)
        }
    }
    list(ep=ep, ip1=ip1, ip2=ip2, ig1=ig1, ig2=ig2)
}

`trans.ppp` <-
function(p, eg, Ebb, Eg0, RL, Eg2=Ebb, rUL=0)
{
    # �v�b�V���v���o�͒i�̓`�B����
    # p: �p�����[�^
    # eg: ���͓d��
    # Ebb: �d���d��
    # Eg0: �o�C�A�X�d��
    # RL: ���׃C���s�[�_���X

    eRL <- RL/4
    f <- function(ep1) {
        ip <- Ipp.pp(p, ep1, egi1, Ebb, Eg0, Eg2, rUL)
        irl <- Ebb/eRL - ep1/eRL        # ���[�h���C���ɂ��d��
        ip - irl
    }
    ep <- ip1 <- ip2 <- ig21 <- ig22 <- rep(NA, length(eg))
    for (i in seq(along=eg)) {
        egi1 <- eg[i] + Eg0
        ep[i] <- uniroot(f, c(0, 2*Ebb))$root
        eg21 <- Eg2 + (ep[i] - Ebb)*rUL
        eg22 <- Eg2 - (ep[i] - Ebb)*rUL
        z <- Ipp.sub(p, ep[i], egi1, eg21)
        ip1[i] <- z$ip
        ig21[i] <- z$ig2
        z <- Ipp.sub(p, 2*Ebb-ep[i], 2*Eg0-egi1, eg22)
        ip2[i] <- -z$ip
        ig22[i] <- -z$ig2
    }
    list(ep=ep, ip1=ip1, ip2=ip2, ig21=ig21, ig22=ig22)
}

`trans.se` <-
function(p, ei, Ep0, Eg0, RL, Eg2, rUL, rKF=0, MaxEp)
{
    # �V���O���o�͒i�̓`�B����
    # p: �p�����[�^
    # ei: ���͓d��
    # Ep0: �Î~���v���[�g�d��
    # Eg0: �o�C�A�X�d��
    # RL: ���׃C���s�[�_���X
    # Eg2: �X�N���[���O���b�h�d��
    # rUL: UL�^�b�v�䗦(�J�\�[�h-�v���[�g�Ԃ�1�Ƃ���)
    # rKF: KNF�^�b�v�䗦(�J�\�[�h-�v���[�g�Ԃ�1�Ƃ���)
    # MaxEp: �T������ő�v���[�g�d��

    triode <- (missing(rUL) & missing(Eg2))
    if (triode) {
        ip0 <- Ip(p, Ep0, Eg0)
        f <- function(ep) {
            ek <- (Ep0 - ep) * rKF
            ip <- Ip(p, ep, eii-ek)
            irl <- ip0 + (Ep0 - ep)/RL
            ip - irl
        }
    } else {
        if (missing(Eg2))
            Eg2 <- Ep0
        if (missing(rUL))
            rUL <- 0
        z <- Ipp.sub(p, Ep0, Eg0, Eg2)
        ip0 <- z$ip + z$ig2 * rUL
        f <- function(ep) {
            ek <- (Ep0 - ep) * rKF
            eg2 <- Eg2 - (Ep0 - ep) * rUL
            z <- Ipp.sub(p, ep, eii - ek, eg2)
            #cat("ep=", ep, ", ei=", ei, ", eg2=", eg2, "\n", sep="")
            #print(z)
            ip <- z$ip + z$ig2 * rUL
            irl <- ip0 + (Ep0 - ep)/RL
            ip - irl
        }
    }
    if (missing(MaxEp))
        MaxEp <- (Ep0 + ip0 * RL) * 1.1
    ig <- ek <- ep <- ip <- rep(NA, length(ei))
    if (!triode)
        ig2 <- ip
    for (i in seq(along=ei)) {
        eii <- Eg0 + ei[i]
        ep[i] <- uniroot(f, c(1, MaxEp))$root
        ek[i] <- (Ep0 - ep[i])*rKF
        if (triode) {
            z <- Ip.sub(p, ep[i], eii-ek[i])
            ip[i] <- z$ip
            ig[i] <- z$ig
        } else {
            eg2 <- Eg2 - (Ep0 - ep[i]) * rUL
            z <- Ipp.sub(p, ep[i], eii-ek[i], eg2)
            ip[i] <- z$ip
            ig[i] <- z$ig
            ig2[i] <- z$ig2
        }
    }
    if (triode)
        list(ep=ep, ip=ip, ig=ig, ek=ek)
    else
        list(ep=ep, ip=ip, ig=ig, ek=ek, ig2=ig2)
}

`trans.srpp` <-
function(p1=t12AU7, ei=c(-1, 1), Ebb=240-4.554085, Eg1=-4.554085, Rk1=0, Rk2=1.5e3, p2=p1, RL=50e3, verbose=FALSE)
{
    # SRPP�̓`�B���������߂�
    # p1: V1�̃p�����[�^
    # p2: V2�̃p�����[�^
    # ei: ���͓d��
    # Ebb: �d���d��
    # Eg1: V1�O���b�h�d��(�΃A�[�X)
    # Rk1: V1�J�\�[�h��R
    # Rk2: V2�J�\�[�h��R
    # RL: ���ג�R
    # �Ԓl
    # $Ip: �v���[�g�d��
    # $Eg1: �΃J�\�[�hV1�O���b�h�d��
    # $Ep1: �΃J�\�[�hV1�v���[�g�d��
    # $Eg2: �΃J�\�[�hV2�O���b�h�d��
    # $Ep2: �΃J�\�[�hV2�v���[�g�d��
    # $Eo: �o�͓d��(�΃A�[�XV2�J�\�[�h�d��)

    # �㑤�̕��S�d�� eu ���� V2 �� Ep �����߂�
    EuEp2.dc <- function(eu) {
        ep2 <- uniroot(function(ep) {
            eg2 <- ep - eu
            I1 <- -eg2 / Rk2
            I2 <- Ip(p2, ep, eg2)
            # cat("ep=", ep, ", eu=", eu, ", eg2=", eg2, ", I1=", I1, ", I2=", I2, "\n", sep="")
            I1 - I2
        }, c(0, eu))$root
        eg2 <- ep2 - eu
        ip <- -eg2 / Rk2
        list(ep2=ep2, eg2=eg2, ip=ip)
    }

    # ����_�̏㑤�̕��S�d�������߂�
    Eu0 <- uniroot(function(eu) {
        z <- EuEp2.dc(eu)
        z$ip - Ip(p1, Ebb - eu - z$ip * Rk1, Eg1 - z$ip * Rk1)
    }, c(0.2*Ebb, 0.8*Ebb))$root
    z <- EuEp2.dc(Eu0)
    Ip0 <- z$ip
    Ep20 <- z$ep2
    Eg20 <- z$eg2
    Ep10 <- Ebb - Eu0 - Ip0 * Rk1
    Eg10 <- Eg1 - Ip0 * Rk1
    Eo0 <- Ebb - Ep20
    # cat("Ip0=", Ip0, ", Ep10=", Ep10, ", Eg10=", Eg10, ", Ep20=", Ep20, ", Eg20=", Eg20, ", Eo0=", Eo0, "\n", sep="")

    # upper Epmin
    Ep2min <- if (RL == Inf) 0 else
        uniroot(function(Ep) Ip(p2, Ep, 0) - (Ep20 - Ep)/RL, c(0, Ep20))$root
    # cat("Ep2min=", Ep2min, "\n", sep="")

    # �㑤�̕��S�d�� eu ���� V2 �� Ep �����߂�
    EuEp2 <- function(eu) {
        if (eu <= Ep2min)
            return(list(ep2=eu, eg2=0, ip=0))
        ep2 <- uniroot(function(ep) {
            eg2 <- ep - eu
            deg2 <- Eg20 - eg2
            I1 <- Ip0 + deg2 / Rk2 - (ep - Ep20) / RL
            I2 <- Ip(p2, ep, eg2)
            if (verbose)
                cat("ep=", ep, ", eg2=", eg2, ", deg2=", deg2, ", I1=", I1, ", I2=", I2, "\n", sep="")
            I1 - I2
        }, c(Ep2min, Ebb))$root
        eg2 <- ep2 - eu
        ip <- Ip0 + (Eg20 - eg2) / Rk2
        ip2 <- ip - (ep2 - Ep20) / RL
        list(ep2=ep2, eg2=eg2, ip=ip, ip2=ip2)
    }

    Eg <- Eg1 + ei
    Ep1 <- Ep2 <- Ip1 <- Ip2 <- rep(NA, length(Eg))
    for (i in seq(along=Eg)) {
        eg <- Eg[i]
        if (verbose)
            cat(eg, "")
        eu <- uniroot(function(eu) {
            z <- EuEp2(eu)
            z$ip - Ip(p1, Ebb - eu - z$ip * Rk1, eg - z$ip * Rk1)
        }, c(Ep2min, Ebb))$root
        z <- EuEp2(eu)
        Ep2[i] <- z$ep2
        Ip1[i] <- z$ip
        Ip2[i] <- z$ip2
        Ep1[i] <- Ebb - eu - z$ip * Rk1
    }
    if (verbose)
        cat("\n")
    Eg2 <- - Ip1 * Rk2
    Eg1 <- Eg - Ip1 * Rk1
    Eo <- Ebb - Ep2
    list(Ep1=Ep1, Eg1=Eg1, Ip1=Ip1, Ep2=Ep2, Eg2=Eg2, Ip2=Ip2, Eo=Eo)
}

`trans.srpp2` <-
function(p1=t12AU7, ei=0, Ebb=196.4884, Eg1=0, Rk1=1.2e3, Rk2=1.2e3, p2=p1)
{
    # SRPP�̓`�B�֐������߂�
    # p1: V1�̃p�����[�^
    # p2: V2�̃p�����[�^
    # ei: ���͓d��
    # Ebb: �d���d��
    # Eg1: V1�O���b�h�d��(�΃A�[�X)
    # Rk1: V1�J�\�[�h��R
    # Rk2: V2�J�\�[�h��R
    # �Ԓl
    # $Ip: �v���[�g�d��
    # $Eg1: �΃J�\�[�hV1�O���b�h�d��
    # $Ep1: �΃J�\�[�hV1�v���[�g�d��
    # $Eg2: �΃J�\�[�hV2�O���b�h�d��
    # $Ep2: �΃J�\�[�hV2�v���[�g�d��
    # $Eo: �o�͓d��(�΃A�[�XV2�J�\�[�h�d��)

    get.ep2 <- function(ip) {
        # �v���[�g�d�� ip �ɑ΂���V2�̃v���[�g�d�������߂�
        if (ip == 0)            # �J�b�g�I�t�̏ꍇ
            return(0)
        eg2 <- -ip * Rk2
        uniroot(function(ep2) Ip(p2, ep2, eg2) - ip, c(0, Ebb))$root
    }

    f <- function(ip) {
        ep2 <- get.ep2(ip)          # V2�����S����d��
        eg1 <- eg - ip * Rk1        # ���ۂ�V1�̃O���b�h�d��
        ep1 <- Ebb - ip * (Rk1 + Rk2) - ep2
        ip1 <- Ip(p1, ep1, eg1)
        ip - ip1
    }

    # V2�������l���A���ꂤ��ő�̓d�������߂�
    Ipmax <- uniroot(function(ip) Ip(p2, Ebb-ip*(Rk1+Rk2), -ip*Rk2) - ip,
            c(0, Ip(p2, Ebb, 0)))$root

    Eg <- ei + Eg1
    ip <- ep2 <- rep(0, length(Eg))
    for (i in seq(along=Eg)) {
        eg <- Eg[i]
        cat(eg, "")
        ip[i] <- if (Ip(p1, Ebb, eg) == 0) 0
                else uniroot(f, c(0, Ipmax*0.99), tol=1e-8)$root
        ep2[i] <- get.ep2(ip[i])            # �΃J�\�[�h�v���[�g�d��
    }
    cat("\n")
    eg2 <- -ip * Rk2                        # �΃J�\�[�h�O���b�h�d��
    eg1 <- Eg - ip * Rk1                    # �΃J�\�[�h�O���b�h�d��
    ep1 <- Ebb - ip * (Rk1 + Rk2) - ep2     # �΃J�\�[�h�v���[�g�d��
    eo <- ip * (Rk1 + Rk2) + ep1            # �΃A�[�XV2�J�\�[�h�d��
    list(Ip=ip, Eo=eo, Eg1=eg1, Ep1=ep1, Eg2=eg2, Ep2=ep2)
}

`trans.vol` <-
function(p, ei, Ebb, Eg0, Rp, Rk=0, aRp=Rp, aRk=Rk)
{
    # �d�������̓`�B���������߂�
    # p: �^��ǂ̃p�����[�^
    # ei: ���͓d��
    # Ebb: �d���d��
    # Eg0: �O���b�h�d��
    # Rp: �v���[�g�����ג�R(DC)
    # Rk: �J�\�[�h�����ג�R(DC)
    # aRp: �v���[�g�����ג�R(AC)
    # aRk: �J�\�[�h�����ג�R(AC)

    RL <- Rp + Rk                   # ���ג�R
    op <- op.vol(p, Ebb, Eg0, Rp, Rk)

    aRL <- aRp + aRk
    f <- function(ep) {
        # ep: �΃J�\�[�h�v���[�g�d��
        ip2 <- (op$ep - ep) / aRL + op$ip   # ���[�h���C���ɂ��d��
        ek <- (ip2 - op$ip) * aRk + op$ek   # �J�\�[�h�d��
        ip1 <- Ip(p, ep, eg-ek)     # �v���[�g�d���ɑ΂���v���[�g�d��
        ip1 - ip2                   # ����0�ɂȂ�v���[�g�d�������߂�
    }
    Eg <- ei + Eg0                  # ���ۂ̃O���b�h�d��(�΃A�[�X)
    ep <- rep(0, length(Eg))
    for (i in seq(along=Eg)) {      # ���͓d���̊e�v�f�ɑ΂��ă��[�v
        eg <- Eg[i]
        ep[i] <- if (Ip(p, Ebb, eg) == 0) Ebb   # �J�b�g�I�t
                else uniroot(f, c(0, Ebb))$root
    }
    ip <- (op$ep - ep) / aRL + op$ip        # �v���[�g�d��
    ek <- (ip - op$ip) * aRk + op$ek        # �J�\�[�h�d��
    eo <- ep + ek
    list(ip=ip, eo=eo, ep=ep, ek=ek, eg=Eg)
}

`trans.will` <-
function(p=tKT66T, ei=c(-20, 0, 20), Ebb=442.1875, Eg0=3.125, RL=10e3, Rk=327.5786, verbose=FALSE)
{
    # Williamson�o�͒i�̓`�B����
    # p: �p�����[�^
    # ei: V1���͓d��
    # Ebb: �d���d��
    # Eg0: �O���b�h�o�C�A�X�d��
    # RL: ���׃C���s�[�_���X(p-p��)
    # Rk: �J�\�[�h��R
    # verbose: �i�s�󋵂�\�����邩?

    eRL <- RL/4     # �������׃C���s�[�_���X

    # �E�B���A���\���o�͒i�̍����v���[�g�d��
    Ip.will <- function(p, ep1, ei, Ebb, Eg0, ek) {
        # p: �p�����[�^
        # ep1: V1 �̃v���[�g�d��
        # ei: �Б��̓��͓d��
        # Ebb: �d���d��
        # Eg0: �O���b�h�o�C�A�X
        # ek: �J�\�[�h�d��

        eg1 <- ei + Eg0 - ek
        eg2 <- -ei + Eg0 - ek
        eo1 <- ep1 + ek
        eo2 <- 2 * Ebb - eo1
        ep2 <- eo2 - ek
        i1 <- Ip.sub(p, ep1, eg1)
        i2 <- Ip.sub(p, ep2, eg2)
        z <- i1$ip - i2$ip
        attr(z, "V1") <- list(ep=ep1, eg=eg1, i=i1)
        attr(z, "V2") <- list(ep=ep2, eg=eg2, i=i2)
        z
    }

    # ���� ek �Ɠ��͂̉��ŁA�Б��̃v���[�g�d�� ep1 �ɑ΂��āA
    # �����v���[�g�����ɂ��d���ƁA
    # ���[�h���C���ɂ��d���̍���Ԃ�.
    ip.diff <- function(ep1, ek, ei) {
        ip <- Ip.will(p, ep1, ei, Ebb, Eg0, ek) # �����v���[�g�����ɂ��d��
        eo1 <- ep1 + ek                 # �΃A�[�X�v���[�g�d��
        irl <- (Ebb - eo1) / eRL        # ���[�h���C���ɂ��d��
        # cat("f: ep1=", ep1, ", ip=", ip, ", ek=", ek,
        #   ", ip=", ip, ", irl=", irl, "\n", sep="")
        z <- ip - irl
        attr(z, "V1") <- attr(ip, "V1")
        attr(z, "V2") <- attr(ip, "V2")
        z
    }

    # ���� ek �Ɠ��͂�^�����Ƃ��ɁA
    # �����v���[�g(+�J�\�[�h)�d���� Rk �ɂ��J�\�[�h�d�ʂ�
    # ek �Ƃ̍���Ԃ�.
    ek.diff <- function(ek, ei) {
        # ek: �΃A�[�X�J�\�[�h�d��
        # ei: �΃A�[�X���͓d��

        # �����v���[�g�����ƃ��[�h���C���̌�_
        ep1 <- uniroot(ip.diff, c(0, 2*(Ebb-ek)), ek=ek, ei=ei)$root
        z <- ip.diff(ep1, ek, ei)
        v1 <- attr(z, "V1")
        v2 <- attr(z, "V2")
        ik <- (v1$i$ip+v1$i$ig + v2$i$ip+v2$i$ig)   # �J�\�[�h�d��
        z <- ek - ik * Rk
        attr(z, "V1") <- v1
        attr(z, "V2") <- v2
        z
    }

    ep1 <- ep2 <- ip1 <- ip2 <- ek <- rep(NA, length(ei))
    for (i in seq(along=ei)) {
        if (verbose)
            cat(i, "")
        ek[i] <- uniroot(ek.diff, c(0, Ebb/2), ei=ei[i])$root
        z <- ek.diff(ek[i], ei[i])
        v1 <- attr(z, "V1")
        v2 <- attr(z, "V2")
        ep1[i] <- v1$ep
        ip1[i] <- v1$i$ip
        ep2[i] <- v2$ep
        ip2[i] <- v2$i$ip
    }
    if (verbose)
        cat("\n")
    list(eo1=ep1+ek, eo2=ep2+ek, ep1=ep1, ep2=ep2, ip1=ip1, ip2=ip2, ek=ek)
}

`tri` <-
function(A3, A2, A1, A0)
{
    spow <- function(x, y) {
        ifelse(x >= 0, 1, -1) * abs(x)^y
    }

    A2 <- A2 / A3
    A1 <- A1 / A3
    A0 <- A0 / A3
    p <- -A2^2/3 + A1
    q <- 2 * A2^3/27 - A1 * A2 / 3 + A0
    D <- q^2 / 4 + p^3 / 27
    if (D >= 0) {
        u <- spow(-q/2 + sqrt(D), 1/3)
        v <- spow(-q/2 - sqrt(D), 1/3)
    } else {
        u <- (-q/2 + sqrt(-D)*(0+1i))^(1/3)
        v <- (-q/2 - sqrt(-D)*(0+1i))^(1/3)
    }
    w <- (-1 + sqrt(3)*(0+1i)) / 2
    w1 <- c(1, w, w^2)
    w2 <- c(1, w^2, w)
    w1 * u + w2 * v - A2 / 3
}

